"""Проверки: PBKDF2, миграция паролей, защита от SQL-инъекций, CSRF.

Запуск:  python test_app.py
Тесты работают на временной копии базы, исходный файл не трогают.
"""
import hashlib
import os
import re
import shutil
import sqlite3
import tempfile
import unittest

import db
import migrate_passwords
import security
from app import create_app

SOURCE_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "aitucooking.sqlite")
PLAIN = {"240101@astanait.edu.kz": "qwertyuiop", "240102@astanait.edu.kz": "123456789", "240103@astanait.edu.kz": "aa1234bb"}


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.path = os.path.join(self.tmp, "test.sqlite")
        shutil.copy(SOURCE_DB, self.path)
        # приводим базу к «исходному» виду: пароли в открытом виде, затем мигрируем
        con = sqlite3.connect(self.path)
        with con:
            for email, pw in PLAIN.items():
                con.execute("UPDATE users SET password = ? WHERE email = ?", (pw, email))
        con.close()
        migrate_passwords.migrate(self.path)
        self.app = create_app(self.path)
        self.client = self.app.test_client()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # --- помощники
    def token(self, url="/login"):
        html = self.client.get(url).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)

    def post(self, url, data, form_page="/login"):
        data = dict(data, csrf_token=self.token(form_page))
        return self.client.post(url, data=data)

    def login(self, email="240101@astanait.edu.kz", password="qwertyuiop"):
        return self.post("/login", {"email": email, "password": password})

    def rows(self, sql, params=()):
        con = sqlite3.connect(self.path)
        try:
            return con.execute(sql, params).fetchall()
        finally:
            con.close()

    def assert_schema_intact(self):
        tables = {r[0] for r in self.rows("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({"users", "sessions", "subjects", "groups", "group_members"} <= tables)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM users")[0][0] >= 3, True)


class PasswordTests(Base):
    def test_migration_hashes_everything_with_200k(self):
        for _id, pw in self.rows("SELECT id, password FROM users"):
            algo, iters, salt, digest = pw.split("$")
            self.assertEqual((algo, iters), ("pbkdf2_sha256", "200000"))
            self.assertEqual(len(bytes.fromhex(salt)), 16)
            self.assertEqual(len(bytes.fromhex(digest)), 32)  # SHA-256 → 32 байта

    def test_hash_matches_reference_pbkdf2(self):
        stored = self.rows("SELECT password FROM users WHERE email = '240101@astanait.edu.kz'")[0][0]
        _, iters, salt, digest = stored.split("$")
        reference = hashlib.pbkdf2_hmac("sha256", b"qwertyuiop", bytes.fromhex(salt), int(iters))
        self.assertEqual(reference.hex(), digest)

    def test_migration_is_idempotent(self):
        before = self.rows("SELECT password FROM users ORDER BY id")
        self.assertEqual(migrate_passwords.migrate(self.path), 0)
        self.assertEqual(before, self.rows("SELECT password FROM users ORDER BY id"))

    def test_salts_differ(self):
        self.assertNotEqual(security.hash_password("x" * 8), security.hash_password("x" * 8))

    def test_verify(self):
        stored = security.hash_password("correct horse")
        self.assertTrue(security.verify_password("correct horse", stored))
        self.assertFalse(security.verify_password("wrong", stored))
        self.assertFalse(security.verify_password("qwertyuiop", "qwertyuiop"))  # открытый текст не принимается
        self.assertFalse(security.verify_password("x", "pbkdf2_sha256$bad"))

    def test_old_hash_is_upgraded_on_login(self):
        weak = security.hash_password("qwertyuiop", iterations=1000)
        con = sqlite3.connect(self.path)
        with con:
            con.execute("UPDATE users SET password = ? WHERE email = '240101@astanait.edu.kz'", (weak,))
        con.close()
        self.login()
        new = self.rows("SELECT password FROM users WHERE email = '240101@astanait.edu.kz'")[0][0]
        self.assertTrue(new.startswith("pbkdf2_sha256$200000$"))


class AuthTests(Base):
    def test_login_ok_and_dashboard(self):
        r = self.login()
        self.assertEqual(r.status_code, 302)
        page = self.client.get("/dashboard")
        self.assertEqual(page.status_code, 200)
        self.assertIn("Nurik Shurik", page.get_data(as_text=True))

    def test_wrong_password(self):
        r = self.login(password="nope-nope")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_anonymous_redirected(self):
        for url in ("/dashboard", "/leaderboard", "/subjects", "/groups"):
            self.assertEqual(self.client.get(url).status_code, 302, url)

    def test_register_and_login(self):
        email = "250999@astanait.edu.kz"
        r = self.post("/register", {"email": email, "nickname": "Tester", "password": "longenough1"}, "/register")
        self.assertEqual(r.status_code, 302)
        stored = self.rows("SELECT password FROM users WHERE email = ?", (email,))[0][0]
        self.assertTrue(stored.startswith("pbkdf2_sha256$200000$"))
        self.assertNotIn("longenough1", stored)
        self.assertEqual(self.login(email, "longenough1").status_code, 302)

    def test_register_validation(self):
        bad = [
            {"email": "a@gmail.com", "nickname": "Nick", "password": "longenough1"},
            {"email": "250998@astanait.edu.kz", "nickname": "x", "password": "longenough1"},
            {"email": "250998@astanait.edu.kz", "nickname": "Nick", "password": "short"},
            {"email": "240101@astanait.edu.kz", "nickname": "Dup", "password": "longenough1"},  # дубликат
            {"email": "x'; DROP TABLE users;--@astanait.edu.kz", "nickname": "Nick", "password": "longenough1"},
        ]
        for data in bad:
            r = self.post("/register", data, "/register")
            self.assertEqual(r.status_code, 200, data)  # осталась на форме
        self.assertEqual(self.rows("SELECT COUNT(*) FROM users")[0][0], 3)
        self.assert_schema_intact()

    def test_csrf_required(self):
        r = self.client.post("/login", data={"email": "240101@astanait.edu.kz", "password": "qwertyuiop"})
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/login", data={"email": "x", "password": "y", "csrf_token": ""})
        self.assertEqual(r.status_code, 400)


class InjectionTests(Base):
    PAYLOADS = ["' OR '1'='1", "' OR 1=1 --", "admin'--", "'; DROP TABLE users; --",
                "\" OR \"\"=\"", "1; DELETE FROM sessions", "' UNION SELECT password FROM users --"]

    def test_login_injection(self):
        for p in self.PAYLOADS:
            for email, password in ((p, p), ("240101@astanait.edu.kz" + p, "x"), ("240101@astanait.edu.kz", p)):
                self.login(email, password)
                self.assertEqual(self.client.get("/dashboard").status_code, 302, (email, password))
        self.assert_schema_intact()

    def test_parameterized_queries_neutralize_payloads(self):
        """Проверяем сам слой БД, в обход валидации: payload — просто строка."""
        with self.app.app_context():
            for p in self.PAYLOADS:
                self.assertIsNone(db.query_one("SELECT id FROM users WHERE email = ?", (p,)))
                self.assertEqual(db.query_all("SELECT id FROM subjects WHERE name = ?", (p,)), [])
        self.assert_schema_intact()
        self.assertEqual(self.rows("SELECT COUNT(*) FROM sessions")[0][0], 100)

    def test_params_must_not_be_plain_string(self):
        with self.app.app_context():
            with self.assertRaises(TypeError):
                db.query_one("SELECT id FROM users WHERE email = ?", "abc")

    def test_stacked_queries_are_refused_by_driver(self):
        with self.app.app_context():
            with self.assertRaises(sqlite3.ProgrammingError):
                db.get_db().execute("SELECT 1; DROP TABLE users")
        self.assert_schema_intact()

    def test_order_by_whitelist(self):
        self.login()
        for sort in ("xp", "streak", "xp; DROP TABLE users--", "total_xp DESC, (SELECT password FROM users)", "", "%00"):
            r = self.client.get("/leaderboard", query_string={"sort": sort})
            self.assertEqual(r.status_code, 200, sort)
        # неизвестное значение → сортировка по умолчанию (по XP)
        html = self.client.get("/leaderboard", query_string={"sort": "x; DROP TABLE users"}).get_data(as_text=True)
        self.assertLess(html.index("Beknur senpai"), html.index("Elzhanium"))  # 600 XP выше 320 XP
        self.assert_schema_intact()

    def test_search_like_and_injection(self):
        self.login()
        everything = self.client.get("/subjects").get_data(as_text=True)
        self.assertIn("Calculus", everything)
        for q in ("%", "_", "' OR 1=1 --", "'; DROP TABLE subjects; --"):
            html = self.client.get("/subjects", query_string={"q": q}).get_data(as_text=True)
            self.assertNotIn("Calculus", html, q)  # '%' больше не «любой текст»
        self.assertIn("Physics", self.client.get("/subjects", query_string={"q": "phys"}).get_data(as_text=True))
        self.assert_schema_intact()

    def test_xss_is_escaped(self):
        self.login()
        html = self.client.get("/subjects", query_string={"q": '"><script>alert(1)</script>'}).get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)


class FeatureTests(Base):
    def test_add_session_awards_xp(self):
        self.login()
        before = self.rows("SELECT total_xp FROM users WHERE id = 1")[0][0]
        r = self.post("/sessions", {"subject_id": "1", "duration_min": "50"}, "/dashboard")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.rows("SELECT total_xp FROM users WHERE id = 1")[0][0], before + 10)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM sessions WHERE user_id = 1")[0][0], 34)

    def test_add_session_rejects_bad_input(self):
        self.login()
        for subject, minutes in (("1", "0"), ("1", "721"), ("1", "-5"), ("1", "abc"), ("999", "30"),
                                 ("1 OR 1=1", "30"), ("", "")):
            self.post("/sessions", {"subject_id": subject, "duration_min": minutes}, "/dashboard")
        self.assertEqual(self.rows("SELECT COUNT(*) FROM sessions")[0][0], 100)

    def test_join_group(self):
        self.login("240102@astanait.edu.kz", "123456789")  # уже в группах 1 и 2
        self.post("/groups/join", {"invite_code": "ict2026"}, "/groups")  # повторное вступление — без ошибки
        self.assertEqual(self.rows("SELECT COUNT(*) FROM group_members WHERE group_id = 1")[0][0], 3)
        self.post("/groups/join", {"invite_code": "' OR 1=1 --"}, "/groups")
        self.assertEqual(self.rows("SELECT COUNT(*) FROM group_members")[0][0], 5)

    def test_password_not_exposed(self):
        self.login()
        for url in ("/dashboard", "/leaderboard", "/groups", "/subjects"):
            self.assertNotIn("pbkdf2", self.client.get(url).get_data(as_text=True), url)


if __name__ == "__main__":
    unittest.main(verbosity=2)
