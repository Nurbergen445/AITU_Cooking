"""Одноразовая миграция: превращает пароли в открытом виде в PBKDF2-хеши.

Запуск:
    python migrate_passwords.py                      # aitucooking.sqlite рядом со скриптом
    python migrate_passwords.py --db путь/к/базе.sqlite

Скрипт можно запускать повторно: уже захешированные пароли он пропускает.
Перед изменением рекомендуется сделать копию файла базы.
"""
import argparse
import os
import sqlite3

import security


def migrate(db_path: str) -> int:
    con = sqlite3.connect(db_path)
    try:
        rows = con.execute("SELECT id, password FROM users").fetchall()
        changed = 0
        with con:  # одна транзакция
            for user_id, stored in rows:
                if security.is_hashed(stored):
                    continue
                con.execute(
                    "UPDATE users SET password = ? WHERE id = ?",
                    (security.hash_password(stored), user_id),
                )
                changed += 1
        return changed
    finally:
        con.close()


if __name__ == "__main__":
    default_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "aitucooking.sqlite")
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--db", default=default_db)
    args = parser.parse_args()
    print(f"Захешировано паролей: {migrate(args.db)}")
