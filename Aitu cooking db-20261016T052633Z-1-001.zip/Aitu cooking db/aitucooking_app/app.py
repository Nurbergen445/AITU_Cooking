"""AITU Cooking — веб-приложение для учёта учебных сессий (Flask + SQLite).

Запуск:
    pip install -r requirements.txt
    python migrate_passwords.py      # один раз: захешировать пароли в базе
    export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
    python app.py
"""
import hmac
import os
import secrets
import sqlite3
from functools import wraps

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for

import db
import security

XP_PER_MINUTES = 5  # 1 XP за каждые 5 минут сессии

# ORDER BY нельзя параметризовать через `?`, поэтому имя колонки берётся
# только из этого белого списка, а не из запроса пользователя.
LEADERBOARD_SORT = {"xp": "total_xp", "streak": "streak_days"}


def create_app(database: str | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(
        DATABASE=database or os.environ.get("DATABASE_PATH") or os.path.join(app.root_path, "aitucooking.sqlite"),
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",  # включить за HTTPS
        MAX_CONTENT_LENGTH=16 * 1024,
    )
    app.teardown_appcontext(db.close_db)

    # ----------------------------------------------------------------- CSRF
    def csrf_token() -> str:
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(16)
        return session["csrf"]

    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.before_request
    def protect_post():
        if request.method == "POST":
            expected = session.get("csrf")
            sent = request.form.get("csrf_token", "")
            if not expected or not hmac.compare_digest(sent.encode(), expected.encode()):
                abort(400, "Неверный CSRF-токен")

    # ------------------------------------------------------- текущий пользователь
    @app.before_request
    def load_user():
        g.user = None
        user_id = session.get("user_id")
        if user_id is not None:
            # пароль в g.user намеренно не попадает
            g.user = db.query_one(
                "SELECT id, email, nickname, total_xp, streak_days, role FROM users WHERE id = ?",
                (user_id,),
            )

    def login_required(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("login"))
            return view(*args, **kwargs)
        return wrapper

    # ------------------------------------------------------------ аутентификация
    @app.get("/")
    def index():
        return redirect(url_for("dashboard" if g.user else "login"))

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            email = security.normalize_email(request.form.get("email"))
            nickname = (request.form.get("nickname") or "").strip()
            password = request.form.get("password") or ""

            error = None
            if not security.valid_email(email):
                error = "Нужна почта вида имя@astanait.edu.kz"
            elif not security.valid_nickname(nickname):
                error = "Никнейм: 2–32 символа (буквы, цифры, пробел, _ . -)"
            elif not security.valid_password(password):
                error = f"Пароль: от {security.PASSWORD_MIN} до {security.PASSWORD_MAX} символов"

            if error is None:
                try:
                    db.execute(
                        "INSERT INTO users (email, password, nickname) VALUES (?, ?, ?)",
                        (email, security.hash_password(password), nickname),
                    )
                except sqlite3.IntegrityError:
                    error = "Пользователь с такой почтой уже существует"
            if error:
                flash(error)
            else:
                flash("Аккаунт создан, теперь войдите")
                return redirect(url_for("login"))
        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = security.normalize_email(request.form.get("email"))
            password = (request.form.get("password") or "")[: security.PASSWORD_MAX]

            user = None
            if security.valid_email(email):
                user = db.query_one("SELECT id, password FROM users WHERE email = ?", (email,))

            # Если пользователя нет — всё равно считаем PBKDF2 (одинаковое время ответа).
            stored = user["password"] if user else security.DUMMY_HASH
            ok = security.verify_password(password, stored) and user is not None

            if ok:
                if security.needs_rehash(stored):  # подтянуть старые хеши до 200k итераций
                    db.execute("UPDATE users SET password = ? WHERE id = ?",
                               (security.hash_password(password), user["id"]))
                session.clear()  # новая сессия после входа (против session fixation)
                session["user_id"] = user["id"]
                return redirect(url_for("dashboard"))
            flash("Неверная почта или пароль")  # одно и то же сообщение для обоих случаев
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    # --------------------------------------------------------------- страницы
    @app.get("/dashboard")
    @login_required
    def dashboard():
        recent = db.query_all(
            """SELECT s.started_at, s.duration_min, s.status, sub.name AS subject
               FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
               WHERE s.user_id = ?
               ORDER BY s.started_at DESC, s.id DESC LIMIT 10""",
            (g.user["id"],),
        )
        totals = db.query_all(
            """SELECT sub.name AS subject, SUM(s.duration_min) AS minutes
               FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
               WHERE s.user_id = ? AND s.status = 'completed'
               GROUP BY sub.id ORDER BY minutes DESC""",
            (g.user["id"],),
        )
        subjects = db.query_all("SELECT id, name, code FROM subjects ORDER BY name")
        return render_template("dashboard.html", recent=recent, totals=totals, subjects=subjects)

    @app.post("/sessions")
    @login_required
    def add_session():
        subject_id = security.parse_int(request.form.get("subject_id"), 1, 2**31)
        duration = security.parse_int(request.form.get("duration_min"), 1, 720)  # как CHECK в таблице
        if subject_id is None or duration is None:
            flash("Выберите предмет и укажите длительность от 1 до 720 минут")
        elif db.query_one("SELECT 1 FROM subjects WHERE id = ?", (subject_id,)) is None:
            flash("Такого предмета нет")
        else:
            with db.transaction() as con:  # сессия и XP — одной транзакцией
                con.execute(
                    "INSERT INTO sessions (user_id, subject_id, duration_min) VALUES (?, ?, ?)",
                    (g.user["id"], subject_id, duration),
                )
                con.execute(
                    "UPDATE users SET total_xp = total_xp + ? WHERE id = ?",
                    (duration // XP_PER_MINUTES, g.user["id"]),
                )
            flash(f"Сессия записана: +{duration // XP_PER_MINUTES} XP")
        return redirect(url_for("dashboard"))

    @app.get("/leaderboard")
    @login_required
    def leaderboard():
        sort = request.args.get("sort", "xp")
        column = LEADERBOARD_SORT.get(sort, LEADERBOARD_SORT["xp"])  # неизвестное значение → по умолчанию
        sort = sort if sort in LEADERBOARD_SORT else "xp"
        # f-строка безопасна: `column` — одна из констант выше, а не ввод пользователя
        rows = db.query_all(
            f"SELECT nickname, total_xp, streak_days FROM users ORDER BY {column} DESC, id LIMIT 20"
        )
        return render_template("leaderboard.html", rows=rows, sort=sort)

    @app.get("/subjects")
    @login_required
    def subjects():
        q = request.args.get("q", "").strip()[:50]
        pattern = "%" + security.like_escape(q) + "%"
        rows = db.query_all(
            """SELECT name, code FROM subjects
               WHERE name LIKE ? ESCAPE '\\' OR code LIKE ? ESCAPE '\\'
               ORDER BY name""",
            (pattern, pattern),
        )
        return render_template("subjects.html", rows=rows, q=q)

    @app.get("/groups")
    @login_required
    def groups():
        rows = db.query_all(
            """SELECT g.name, g.invite_code,
                      (SELECT COUNT(*) FROM group_members m2 WHERE m2.group_id = g.id) AS members
               FROM groups g JOIN group_members m ON m.group_id = g.id
               WHERE m.user_id = ? ORDER BY g.name""",
            (g.user["id"],),
        )
        return render_template("groups.html", rows=rows)

    @app.post("/groups/join")
    @login_required
    def join_group():
        code = (request.form.get("invite_code") or "").strip().upper()
        group = db.query_one("SELECT id, name FROM groups WHERE invite_code = ?", (code,)) \
            if security.valid_invite_code(code) else None
        if group is None:
            flash("Неверный код приглашения")
        else:
            db.execute(
                "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)",
                (group["id"], g.user["id"]),
            )
            flash(f"Вы в группе «{group['name']}»")
        return redirect(url_for("groups"))

    return app


if __name__ == "__main__":
    # debug=False: интерактивный отладчик Werkzeug нельзя выставлять наружу
    create_app().run(host="127.0.0.1", port=5000, debug=False)
