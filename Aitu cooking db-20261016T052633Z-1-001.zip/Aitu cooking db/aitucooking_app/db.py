"""Подключение к SQLite для Flask.

Главное правило защиты от SQL-инъекций: SQL — это всегда константная строка,
а все значения от пользователя передаются отдельно, через `?`-плейсхолдеры.
Драйвер sqlite3 никогда не подставляет их в текст запроса, поэтому
`' OR '1'='1` остаётся просто строкой.
"""
import sqlite3
from contextlib import contextmanager

from flask import current_app, g


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        con = sqlite3.connect(current_app.config["DATABASE"])
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")  # в SQLite внешние ключи по умолчанию выключены
        g.db = con
    return g.db


def close_db(_exc=None) -> None:
    con = g.pop("db", None)
    if con is not None:
        con.close()


def _check_params(params) -> None:
    # Строка вместо кортежа — типичная ошибка: ("abc") это str, а не кортеж.
    if not isinstance(params, (tuple, list, dict)):
        raise TypeError("params must be a tuple, list or dict, not " + type(params).__name__)


def query_all(sql: str, params=()):
    _check_params(params)
    return get_db().execute(sql, params).fetchall()


def query_one(sql: str, params=()):
    _check_params(params)
    return get_db().execute(sql, params).fetchone()


def execute(sql: str, params=()):
    _check_params(params)
    con = get_db()
    cur = con.execute(sql, params)
    con.commit()
    return cur


@contextmanager
def transaction():
    """Несколько запросов как одна операция: либо все выполнятся, либо ни один."""
    con = get_db()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
