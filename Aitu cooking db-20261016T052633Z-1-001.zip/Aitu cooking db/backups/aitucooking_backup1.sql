BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "group_members" (
	"group_id"	INTEGER NOT NULL,
	"user_id"	INTEGER NOT NULL,
	"joined_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY("group_id","user_id"),
	FOREIGN KEY("group_id") REFERENCES "groups"("id") ON DELETE CASCADE,
	FOREIGN KEY("user_id") REFERENCES "users"("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "groups" (
	"id"	INTEGER,
	"name"	TEXT NOT NULL,
	"invite_code"	TEXT NOT NULL UNIQUE,
	"created_by"	INTEGER NOT NULL,
	"created_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("created_by") REFERENCES "users"("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "sessions" (
	"id"	INTEGER,
	"user_id"	INTEGER NOT NULL,
	"subject_id"	INTEGER NOT NULL,
	"duration_min"	INTEGER NOT NULL CHECK("duration_min" > 0 AND "duration_min" <= 720),
	"started_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	"status"	TEXT NOT NULL DEFAULT 'completed' CHECK("status" IN ('active', 'completed', 'cancelled')),
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("subject_id") REFERENCES "subjects"("id") ON DELETE RESTRICT,
	FOREIGN KEY("user_id") REFERENCES "users"("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "subjects" (
	"id"	INTEGER,
	"name"	TEXT NOT NULL UNIQUE,
	"code"	TEXT NOT NULL UNIQUE,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "users" (
	"id"	INTEGER,
	"email"	TEXT NOT NULL CHECK("email" LIKE '%@astanait.edu.kz') UNIQUE,
	"password"	TEXT NOT NULL,
	"nickname"	TEXT NOT NULL,
	"total_xp"	INTEGER NOT NULL DEFAULT 0 CHECK("total_xp" >= 0),
	"streak_days"	INTEGER NOT NULL DEFAULT 0 CHECK("streak_days" >= 0),
	"role"	TEXT NOT NULL DEFAULT 'student' CHECK("role" IN ('student', 'admin')),
	"created_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY("id" AUTOINCREMENT)
);
INSERT INTO "group_members" VALUES (1,1,'2026-10-12 18:33:52');
INSERT INTO "group_members" VALUES (1,2,'2026-10-12 18:33:52');
INSERT INTO "group_members" VALUES (1,3,'2026-10-12 18:33:52');
INSERT INTO "group_members" VALUES (2,2,'2026-10-12 18:33:52');
INSERT INTO "group_members" VALUES (2,3,'2026-10-12 18:33:52');
INSERT INTO "groups" VALUES (1,'ICT Study Group','ICT2026',1,'2026-10-12 18:33:51');
INSERT INTO "groups" VALUES (2,'Dev Team AITU','DEV999',3,'2026-10-12 18:33:51');
INSERT INTO "sessions" VALUES (1,2,2,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (2,3,3,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (3,1,4,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (4,2,1,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (5,3,2,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (6,1,3,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (7,2,4,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (8,3,1,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (9,1,2,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (10,2,3,85,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (11,3,4,92,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (12,1,1,99,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (13,2,2,106,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (14,3,3,113,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (15,1,4,15,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (16,2,1,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (17,3,2,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (18,1,3,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (19,2,4,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (20,3,1,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (21,1,2,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (22,2,3,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (23,3,4,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (24,1,1,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (25,2,2,85,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (26,3,3,92,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (27,1,4,99,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (28,2,1,106,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (29,3,2,113,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (30,1,3,15,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (31,2,4,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (32,3,1,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (33,1,2,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (34,2,3,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (35,3,4,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (36,1,1,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (37,2,2,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (38,3,3,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (39,1,4,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (40,2,1,85,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (41,3,2,92,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (42,1,3,99,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (43,2,4,106,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (44,3,1,113,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (45,1,2,15,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (46,2,3,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (47,3,4,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (48,1,1,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (49,2,2,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (50,3,3,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (51,1,4,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (52,2,1,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (53,3,2,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (54,1,3,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (55,2,4,85,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (56,3,1,92,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (57,1,2,99,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (58,2,3,106,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (59,3,4,113,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (60,1,1,15,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (61,2,2,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (62,3,3,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (63,1,4,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (64,2,1,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (65,3,2,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (66,1,3,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (67,2,4,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (68,3,1,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (69,1,2,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (70,2,3,85,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (71,3,4,92,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (72,1,1,99,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (73,2,2,106,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (74,3,3,113,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (75,1,4,15,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (76,2,1,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (77,3,2,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (78,1,3,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (79,2,4,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (80,3,1,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (81,1,2,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (82,2,3,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (83,3,4,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (84,1,1,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (85,2,2,85,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (86,3,3,92,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (87,1,4,99,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (88,2,1,106,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (89,3,2,113,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (90,1,3,15,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (91,2,4,22,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (92,3,1,29,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (93,1,2,36,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (94,2,3,43,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (95,3,4,50,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (96,1,1,57,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (97,2,2,64,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (98,3,3,71,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (99,1,4,78,'2026-10-12 18:33:52','completed');
INSERT INTO "sessions" VALUES (100,2,1,85,'2026-10-12 18:33:52','completed');
INSERT INTO "subjects" VALUES (1,'Calculus','CAL101');
INSERT INTO "subjects" VALUES (2,'ICT','ICT102');
INSERT INTO "subjects" VALUES (3,'Introduction to Programming','ITP103');
INSERT INTO "subjects" VALUES (4,'Physics','PHYS101');
INSERT INTO "users" VALUES (1,'240101@astanait.edu.kz','qwertyuiop','Nurik Shurik',450,5,'student','2026-10-12 18:33:51');
INSERT INTO "users" VALUES (2,'240102@astanait.edu.kz','123456789','Elzhanium',320,3,'student','2026-10-12 18:33:51');
INSERT INTO "users" VALUES (3,'240103@astanait.edu.kz','aa1234bb','Beknur senpai',600,7,'admin','2026-10-12 18:33:51');
COMMIT;
