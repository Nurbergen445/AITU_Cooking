"""Проверки новых маршрутов и JSON-ответа /sessions (экраны таймера и групп).

Запуск:  python test_frontend.py
Как и test_app.py, работает на временной копии базы. Числа считаются относительно текущего
состояния базы, а не «зашиты» в тесты.
"""
import json
import re
import sqlite3
import unittest

import presence
from test_app import Base


class FrontendTests(Base):
    def fetch_json(self, url, **kw):
        return self.client.get(url, **kw).get_json()

    def post_session(self, subject_id, minutes, page="/dashboard"):
        data = {"subject_id": subject_id, "duration_min": minutes, "csrf_token": self.token(page)}
        return self.client.post("/sessions", data=data, headers={"X-Requested-With": "fetch"})

    def setUp(self):
        super().setUp()
        presence._last_seen.clear()
        self.login()

    # ----------------------------------------------------------------- главный экран
    def test_dashboard_lists_every_subject_with_timer_controls(self):
        html = self.client.get("/dashboard").get_data(as_text=True)
        names = [r[0] for r in self.rows("SELECT name FROM subjects")]
        self.assertGreaterEqual(len(names), 1)
        self.assertEqual(html.count('class="play-btn"'), len(names))
        for name in names:
            self.assertIn(f'data-subject-name="{name}"', html)
        self.assertIn('id="total-timer"', html)
        self.assertIn("Nurik Shurik", html)

    def test_dashboard_today_seconds_come_from_sessions(self):
        before = int(re.search(r'data-subject-id="1"[^>]*data-today-sec="(\d+)"', self.client.get("/dashboard").get_data(as_text=True)).group(1))
        self.assertEqual(self.post_session("1", "7").status_code, 200)
        html = self.client.get("/dashboard").get_data(as_text=True)
        after = int(re.search(r'data-subject-id="1"[^>]*data-today-sec="(\d+)"', html).group(1))
        self.assertEqual(after - before, 7 * 60)

    def test_yesterdays_sessions_are_not_today(self):
        con = sqlite3.connect(self.path)
        with con:
            con.execute("INSERT INTO sessions (user_id, subject_id, duration_min, started_at) VALUES (1, 4, 30, datetime('now','-2 days'))")
        con.close()
        html = self.client.get("/dashboard").get_data(as_text=True)
        physics = re.search(r'data-subject-id="4"[^>]*data-today-sec="(\d+)"', html).group(1)
        self.assertEqual(physics, "0")

    def test_tz_cookie_is_validated(self):
        for bad in ("abc", "999999", "1; DROP TABLE users", "' OR 1=1 --", ""):
            self.client.set_cookie("tzoff", bad)
            self.assertEqual(self.client.get("/dashboard").status_code, 200, bad)
        self.client.set_cookie("tzoff", "300")
        html = self.client.get("/dashboard").get_data(as_text=True)
        self.assertIn('data-tz-used="300"', html)
        self.assert_schema_intact()

    # ----------------------------------------------------------------- сохранение таймера
    def test_json_save_returns_json_and_awards_xp(self):
        xp = self.rows("SELECT total_xp FROM users WHERE id = 1")[0][0]
        r = self.post_session("2", "25")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json(), {"ok": True, "minutes": 25, "xp": 5})
        self.assertEqual(self.rows("SELECT total_xp FROM users WHERE id = 1")[0][0], xp + 5)

    def test_json_save_does_not_leave_a_flash_message(self):
        self.post_session("2", "10")
        self.assertNotIn("Session saved", self.client.get("/profile").get_data(as_text=True))

    def test_json_save_rejects_bad_input_with_400(self):
        count = self.rows("SELECT COUNT(*) FROM sessions")[0][0]
        for subject, minutes in (("1", "0"), ("1", "721"), ("1", "-1"), ("x", "5"), ("999", "5"), ("1 OR 1=1", "5")):
            r = self.post_session(subject, minutes)
            self.assertEqual(r.status_code, 400, (subject, minutes))
            self.assertFalse(r.get_json()["ok"])
        self.assertEqual(self.rows("SELECT COUNT(*) FROM sessions")[0][0], count)

    def test_json_save_requires_csrf_and_login(self):
        r = self.client.post("/sessions", data={"subject_id": "1", "duration_min": "5"}, headers={"X-Requested-With": "fetch"})
        self.assertEqual(r.status_code, 400)
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        r = self.client.post("/sessions", data={"subject_id": "1", "duration_min": "5", "csrf_token": self.token("/login")},
                             headers={"X-Requested-With": "fetch"})
        self.assertEqual(r.status_code, 302)  # неавторизованного — на /login, а не в базу

    def test_plain_form_still_redirects_with_flash(self):
        r = self.post("/sessions", {"subject_id": "1", "duration_min": "10"}, "/profile")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/profile", r.headers["Location"])
        self.assertIn("Session saved", self.client.get("/profile").get_data(as_text=True))

    # ----------------------------------------------------------------- профиль, то-ду, настройки
    def test_profile_keeps_old_dashboard_content(self):
        html = self.client.get("/profile").get_data(as_text=True)
        for text in ("Log a session manually", "Time by subject", "Recent sessions", "XP"):
            self.assertIn(text, html)
        self.assertNotIn("pbkdf2", html)

    def test_new_pages_render_and_require_login(self):
        for url in ("/profile", "/todo", "/settings", "/groups/1", "/groups/1/live"):
            self.assertEqual(self.client.get(url).status_code, 200, url)
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        for url in ("/profile", "/todo", "/settings", "/groups/1", "/groups/1/live"):
            self.assertEqual(self.client.get(url).status_code, 302, url)

    def test_nav_marks_active_page(self):
        self.assertRegex(self.client.get("/todo").get_data(as_text=True), r'class="dock-item active" href="/todo"')
        self.assertRegex(self.client.get("/groups/1").get_data(as_text=True), r'class="dock-item active" href="/groups"')

    # ----------------------------------------------------------------- группы и присутствие
    def test_group_page_embeds_real_members(self):
        html = self.client.get("/groups/1").get_data(as_text=True)
        payload = json.loads(re.search(r'id="group-data">(.*?)</script>', html, re.S).group(1))
        expected = {r[0] for r in self.rows("SELECT u.nickname FROM group_members m JOIN users u ON u.id=m.user_id WHERE m.group_id=1")}
        self.assertEqual({m["name"] for m in payload["members"]}, expected)
        self.assertEqual(sum(m["you"] for m in payload["members"]), 1)
        self.assertNotIn("password", html.lower().replace('type="password"', ""))

    def test_group_membership_is_enforced(self):
        # пользователь 1 не состоит в группе 2
        self.assertEqual(self.client.get("/groups/2").status_code, 404)
        self.assertEqual(self.client.get("/groups/2/live").status_code, 404)
        self.assertEqual(self.client.get("/groups/999").status_code, 404)

    def test_group_period_totals(self):
        def seconds_of(data, user):
            return next(m["seconds"] for m in data["members"] if m["name"] == user)
        today_before = seconds_of(self.fetch_json("/groups/1/live"), "Elzhanium")
        all_before = seconds_of(self.fetch_json("/groups/1/live?period=all"), "Elzhanium")
        con = sqlite3.connect(self.path)
        with con:  # старая сессия: в «all» попадает, в «today» — нет
            con.execute("INSERT INTO sessions (user_id, subject_id, duration_min, started_at) VALUES (2, 1, 100, datetime('now','-3 days'))")
        con.close()
        self.assertEqual(seconds_of(self.fetch_json("/groups/1/live"), "Elzhanium"), today_before)
        everything = self.fetch_json("/groups/1/live?period=all")
        self.assertEqual(everything["period"], "all")
        self.assertEqual(seconds_of(everything, "Elzhanium") - all_before, 100 * 60)
        self.assertEqual(self.fetch_json("/groups/1/live?period=%27%3B+DROP")["period"], "today")  # неизвестное → today

    def test_presence_flow(self):
        def studying_names():
            return {m["name"] for m in self.fetch_json("/groups/1/live")["members"] if m["studying"]}
        self.assertEqual(studying_names(), set())
        self.assertEqual(self.post("/presence", {"state": "on"}, "/dashboard").status_code, 204)
        self.assertEqual(studying_names(), {"Nurik Shurik"})
        self.assertEqual(self.fetch_json("/groups/1/live")["studying"], 1)
        self.post("/presence", {"state": "off"}, "/dashboard")
        self.assertEqual(studying_names(), set())

    def test_presence_expires(self):
        self.post("/presence", {"state": "on"}, "/dashboard")
        presence._last_seen[1] -= presence.TTL_SECONDS + 1
        self.assertEqual(self.fetch_json("/groups/1/live")["studying"], 0)

    def test_presence_requires_csrf(self):
        self.assertEqual(self.client.post("/presence", data={"state": "on"}).status_code, 400)

    def test_leaderboard_marks_current_user(self):
        html = self.client.get("/leaderboard").get_data(as_text=True)
        self.assertIn('class="me"', html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
