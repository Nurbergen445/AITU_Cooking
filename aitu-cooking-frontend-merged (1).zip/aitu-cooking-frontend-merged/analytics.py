"""SQL для страницы /admin/stats — те же три запроса, что в отчёте (Part C).

В запросах нет пользовательского ввода (только константные строки), поэтому
SQL-инъекции через них невозможны.
"""

# Q1 — какие предметы занимают больше всего времени и какова средняя сессия
Q1_BY_SUBJECT = """
SELECT sub.name AS subject, COUNT(s.id) AS sessions,
       SUM(s.duration_min) AS total_min, ROUND(AVG(s.duration_min), 1) AS avg_min
FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
WHERE s.status = 'completed'
GROUP BY sub.id ORDER BY total_min DESC
"""

# Q2 — сколько сессий коротких и сколько длинных
Q2_SESSION_LENGTH = """
SELECT CASE WHEN duration_min < 30 THEN '1. under 30 min'
            WHEN duration_min < 60 THEN '2. 30-59 min'
            WHEN duration_min < 90 THEN '3. 60-89 min'
            ELSE '4. 90+ min' END AS length_band,
       COUNT(*) AS sessions
FROM sessions
WHERE status = 'completed'
GROUP BY length_band ORDER BY length_band
"""

# Q3 — кто реально пользуется таймером; условие по status стоит в ON,
# поэтому аккаунты без сессий остаются в результате
Q3_PER_ACCOUNT = """
SELECT u.id AS user_id, COUNT(s.id) AS sessions,
       COALESCE(SUM(s.duration_min), 0) AS total_min
FROM users u
LEFT JOIN sessions s ON s.user_id = u.id AND s.status = 'completed'
GROUP BY u.id ORDER BY total_min DESC
"""

_LENGTH_LABELS = {  # убираем «1. » из подписи — номер нужен только для сортировки
    "1. under 30 min": "under 30 min",
    "2. 30-59 min": "30-59 min",
    "3. 60-89 min": "60-89 min",
    "4. 90+ min": "90+ min",
}


def get_stats(con) -> dict:
    """Все данные страницы одним словарём (con — sqlite3.Connection с row_factory=Row)."""
    subjects = [dict(r) for r in con.execute(Q1_BY_SUBJECT).fetchall()]
    bands = {r["length_band"]: r["sessions"] for r in con.execute(Q2_SESSION_LENGTH).fetchall()}
    lengths = [{"label": label, "sessions": bands.get(key, 0)} for key, label in _LENGTH_LABELS.items()]
    accounts = [dict(r) for r in con.execute(Q3_PER_ACCOUNT).fetchall()]

    def with_pct(rows, key):
        top = max((r[key] for r in rows), default=0)
        for r in rows:
            r["pct"] = round(r[key] * 100 / top, 1) if top else 0
        return top

    max_subject_min = with_pct(subjects, "total_min")
    max_length_sessions = with_pct(lengths, "sessions")
    with_pct(accounts, "total_min")
    return {
        "subjects": subjects,
        "lengths": lengths,
        "accounts": accounts,
        "completed_sessions": sum(s["sessions"] for s in subjects),
        "accounts_total": len(accounts),
        "accounts_active": sum(1 for a in accounts if a["sessions"] > 0),
        "max_subject_min": max_subject_min,
        "max_length_sessions": max_length_sessions,
    }
