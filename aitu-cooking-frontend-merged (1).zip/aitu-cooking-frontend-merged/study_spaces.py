"""Persistence, validation, and status calculation for Smart Study Space."""
from __future__ import annotations

import hashlib
import hmac
import math
import re
from datetime import datetime, timedelta, timezone


DEFAULT_LOCATIONS = (
    {"id": "library", "name": "Library", "location_type": "library", "capacity": 60},
    {"id": "open-space", "name": "Open Space", "location_type": "open_space", "capacity": 50},
    {"id": "room-301", "name": "Room 301", "location_type": "classroom", "capacity": 25},
    {"id": "room-302", "name": "Room 302", "location_type": "classroom", "capacity": 30},
    {"id": "room-303", "name": "Room 303", "location_type": "classroom", "capacity": 25},
)

DEFAULT_THRESHOLDS = {
    "occupancy_moderate": 40,
    "occupancy_high": 70,
    "wifi_excellent": -50,
    "wifi_good": -60,
    "wifi_average": -75,
}

SENSOR_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
ROOM_ID_RE = re.compile(r"^[a-z0-9-]{1,64}$")
_INVALID_TOKEN_HASH = hashlib.sha256(b"invalid-study-space-token").hexdigest()


def initialize(con, locations=DEFAULT_LOCATIONS):
    """Create additive feature tables and seed locations without changing capacities."""
    if not isinstance(locations, (list, tuple)):
        raise ValueError("STUDY_SPACE_LOCATIONS must be an array")
    for location in locations:
        _validate_location(location)
    if len({location["id"] for location in locations}) != len(locations):
        raise ValueError("Study space location IDs must be unique")

    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS study_spaces (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            location_type TEXT NOT NULL CHECK (location_type IN ('library', 'open_space', 'classroom')),
            capacity INTEGER NOT NULL CHECK (capacity > 0),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS study_sensors (
            sensor_id TEXT PRIMARY KEY,
            room_id TEXT NOT NULL,
            token_hash TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (room_id) REFERENCES study_spaces(id) ON DELETE RESTRICT
        );
        CREATE TABLE IF NOT EXISTS occupancy_readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id TEXT NOT NULL,
            occupancy_count INTEGER NOT NULL CHECK (occupancy_count >= 0),
            sensor_id TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'real' CHECK (source IN ('real', 'simulated')),
            FOREIGN KEY (room_id) REFERENCES study_spaces(id) ON DELETE RESTRICT
        );
        CREATE TABLE IF NOT EXISTS wifi_readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id TEXT NOT NULL,
            wifi_signal_dbm INTEGER NOT NULL CHECK (wifi_signal_dbm BETWEEN -120 AND 0),
            download_speed_mbps REAL NOT NULL CHECK (download_speed_mbps BETWEEN 0 AND 10000),
            sensor_id TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'real' CHECK (source IN ('real', 'simulated')),
            FOREIGN KEY (room_id) REFERENCES study_spaces(id) ON DELETE RESTRICT
        );
        CREATE INDEX IF NOT EXISTS idx_occupancy_room_time
            ON occupancy_readings (room_id, observed_at DESC, id DESC);
        CREATE INDEX IF NOT EXISTS idx_wifi_room_time
            ON wifi_readings (room_id, observed_at DESC, id DESC);
        """
    )
    for location in locations:
        con.execute(
            """INSERT OR IGNORE INTO study_spaces (id, name, location_type, capacity)
               VALUES (?, ?, ?, ?)""",
            (location["id"], location["name"], location["location_type"], location["capacity"]),
        )
    con.commit()


def _validate_location(location):
    if not isinstance(location, dict):
        raise ValueError("Each study space location must be an object")
    location_id = location.get("id")
    name = location.get("name")
    kind = location.get("location_type")
    capacity = location.get("capacity")
    if (not isinstance(location_id, str) or not ROOM_ID_RE.fullmatch(location_id)
            or not isinstance(name, str) or not name.strip() or len(name) > 100
            or kind not in {"library", "open_space", "classroom"}
            or isinstance(capacity, bool) or not isinstance(capacity, int) or capacity < 1):
        raise ValueError("Invalid study space location configuration")


def parse_timestamp(value, future_tolerance_seconds=300):
    if not isinstance(value, str) or not value or len(value) > 40:
        raise ValueError("timestamp must be an ISO 8601 timestamp with a timezone")
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)
    except ValueError as exc:
        raise ValueError("timestamp must be a valid ISO 8601 timestamp") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("timestamp must include a timezone")
    parsed = parsed.astimezone(timezone.utc)
    if parsed > datetime.now(timezone.utc) + timedelta(seconds=future_tolerance_seconds):
        raise ValueError("timestamp cannot be in the future")
    return parsed.isoformat(timespec="seconds").replace("+00:00", "Z")


def _sensor_id(sensor_id):
    if not isinstance(sensor_id, str) or not SENSOR_ID_RE.fullmatch(sensor_id):
        raise ValueError("sensor_id must contain 1-64 letters, numbers, dots, underscores, or hyphens")
    return sensor_id


def authenticate_sensor(con, sensor_id, token):
    if not isinstance(sensor_id, str) or not SENSOR_ID_RE.fullmatch(sensor_id):
        return None
    row = con.execute(
        "SELECT room_id, token_hash, enabled FROM study_sensors WHERE sensor_id = ?",
        (sensor_id,),
    ).fetchone()
    provided_hash = hashlib.sha256(token.encode("utf-8")).hexdigest() if isinstance(token, str) else _INVALID_TOKEN_HASH
    expected_hash = row["token_hash"] if row is not None else _INVALID_TOKEN_HASH
    authorized = hmac.compare_digest(provided_hash, expected_hash)
    if row is None or not authorized or not row["enabled"]:
        return None
    return row["room_id"]


def register_sensor(con, sensor_id, room_id, token_hash):
    _sensor_id(sensor_id)
    if not isinstance(room_id, str) or not ROOM_ID_RE.fullmatch(room_id):
        raise ValueError("room_id is invalid")
    if con.execute("SELECT 1 FROM study_spaces WHERE id = ?", (room_id,)).fetchone() is None:
        raise ValueError("room_id does not identify a study space")
    con.execute(
        "INSERT INTO study_sensors (sensor_id, room_id, token_hash) VALUES (?, ?, ?)",
        (sensor_id, room_id, token_hash),
    )


def record_occupancy(con, room_id, occupancy_count, sensor_id, timestamp, source="real", future_tolerance_seconds=300):
    _sensor_id(sensor_id)
    if not isinstance(room_id, str) or not ROOM_ID_RE.fullmatch(room_id):
        raise ValueError("room_id is invalid")
    if isinstance(occupancy_count, bool) or not isinstance(occupancy_count, int) or occupancy_count < 0:
        raise ValueError("occupancy_count must be a non-negative integer")
    if source not in {"real", "simulated"}:
        raise ValueError("source is invalid")
    observed_at = parse_timestamp(timestamp, future_tolerance_seconds)
    space = con.execute("SELECT capacity FROM study_spaces WHERE id = ?", (room_id,)).fetchone()
    if space is None:
        raise ValueError("room_id does not identify a study space")
    if occupancy_count > space["capacity"]:
        raise ValueError("occupancy_count exceeds the configured capacity")
    con.execute(
        """INSERT INTO occupancy_readings
           (room_id, occupancy_count, sensor_id, observed_at, source)
           VALUES (?, ?, ?, ?, ?)""",
        (room_id, occupancy_count, sensor_id, observed_at, source),
    )


def record_wifi(con, room_id, wifi_signal_dbm, download_speed_mbps, sensor_id, timestamp,
                source="real", future_tolerance_seconds=300):
    _sensor_id(sensor_id)
    if not isinstance(room_id, str) or not ROOM_ID_RE.fullmatch(room_id):
        raise ValueError("room_id is invalid")
    if isinstance(wifi_signal_dbm, bool) or not isinstance(wifi_signal_dbm, int) or not -120 <= wifi_signal_dbm <= 0:
        raise ValueError("wifi_signal_dbm must be an integer from -120 to 0")
    if (isinstance(download_speed_mbps, bool) or not isinstance(download_speed_mbps, (int, float))
            or not 0 <= download_speed_mbps <= 10000 or not math.isfinite(download_speed_mbps)):
        raise ValueError("download_speed_mbps must be a finite number from 0 to 10000")
    if source not in {"real", "simulated"}:
        raise ValueError("source is invalid")
    observed_at = parse_timestamp(timestamp, future_tolerance_seconds)
    if con.execute("SELECT 1 FROM study_spaces WHERE id = ?", (room_id,)).fetchone() is None:
        raise ValueError("room_id does not identify a study space")
    con.execute(
        """INSERT INTO wifi_readings
           (room_id, wifi_signal_dbm, download_speed_mbps, sensor_id, observed_at, source)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (room_id, wifi_signal_dbm, float(download_speed_mbps), sensor_id, observed_at, source),
    )


def _occupancy_status(percent, thresholds):
    if percent >= 100:
        return "Full"
    if percent <= thresholds["occupancy_moderate"]:
        return "Low"
    if percent <= thresholds["occupancy_high"]:
        return "Moderate"
    return "High"


def _wifi_status(signal_dbm, thresholds):
    if signal_dbm >= thresholds["wifi_excellent"]:
        return "Excellent"
    if signal_dbm >= thresholds["wifi_good"]:
        return "Good"
    if signal_dbm >= thresholds["wifi_average"]:
        return "Average"
    return "Poor"


def get_overview(con, max_age_seconds=300, thresholds=None):
    thresholds = thresholds or DEFAULT_THRESHOLDS
    spaces = con.execute(
        """SELECT sp.id, sp.name, sp.location_type, sp.capacity,
                  o.occupancy_count, o.observed_at AS occupancy_at, o.source AS occupancy_source,
                  w.wifi_signal_dbm, w.download_speed_mbps, w.observed_at AS wifi_at, w.source AS wifi_source
           FROM study_spaces sp
           LEFT JOIN occupancy_readings o ON o.id = (
               SELECT id FROM occupancy_readings WHERE room_id = sp.id ORDER BY observed_at DESC, id DESC LIMIT 1
           )
           LEFT JOIN wifi_readings w ON w.id = (
               SELECT id FROM wifi_readings WHERE room_id = sp.id ORDER BY observed_at DESC, id DESC LIMIT 1
           )
           ORDER BY CASE sp.location_type WHEN 'library' THEN 0 WHEN 'open_space' THEN 1 ELSE 2 END, sp.name"""
    ).fetchall()
    now = datetime.now(timezone.utc)
    result = []
    latest_update = None
    has_simulated = False
    for row in spaces:
        occupancy = None
        if row["occupancy_at"] is not None:
            stamp = _parse_stored_timestamp(row["occupancy_at"])
            stale = (now - stamp).total_seconds() > max_age_seconds
            percent = round(row["occupancy_count"] * 100 / row["capacity"])
            occupancy = {
                "count": row["occupancy_count"],
                "capacity": row["capacity"],
                "percent": min(100, percent),
                "status": "Data unavailable" if stale else _occupancy_status(percent, thresholds),
                "available": not stale,
                "last_updated_at": row["occupancy_at"],
                "stale": stale,
                "source": row["occupancy_source"],
            }
            latest_update = _later_timestamp(latest_update, row["occupancy_at"])
            has_simulated = has_simulated or row["occupancy_source"] == "simulated"

        wifi = None
        if row["wifi_at"] is not None:
            stamp = _parse_stored_timestamp(row["wifi_at"])
            stale = (now - stamp).total_seconds() > max_age_seconds
            wifi = {
                "signal_dbm": row["wifi_signal_dbm"],
                "download_speed_mbps": round(row["download_speed_mbps"], 1),
                "status": "Data unavailable" if stale else _wifi_status(row["wifi_signal_dbm"], thresholds),
                "available": not stale,
                "last_updated_at": row["wifi_at"],
                "stale": stale,
                "source": row["wifi_source"],
            }
            latest_update = _later_timestamp(latest_update, row["wifi_at"])
            has_simulated = has_simulated or row["wifi_source"] == "simulated"
        result.append({
            "id": row["id"],
            "name": row["name"],
            "location_type": row["location_type"],
            "capacity": row["capacity"],
            "occupancy": occupancy,
            "wifi": wifi,
        })
    return {"spaces": result, "updated_at": latest_update, "has_simulated_data": has_simulated}


def _parse_stored_timestamp(value):
    parsed = datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _later_timestamp(first, second):
    return second if first is None or _parse_stored_timestamp(second) > _parse_stored_timestamp(first) else first
