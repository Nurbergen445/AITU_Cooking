"""Ограничение частоты неудачных попыток (например, неверных кодов приглашения).

Хранится в памяти процесса — для локального запуска этого достаточно. При запуске
в нескольких процессах счётчики были бы раздельными, тогда нужно общее хранилище.
"""
import threading
import time
from collections import deque


class Throttle:
    def __init__(self, limit: int, window_seconds: int):
        self.limit = limit
        self.window = window_seconds
        self._hits: dict = {}
        self._lock = threading.Lock()

    def _prune(self, key, now):
        hits = self._hits.get(key)
        while hits and now - hits[0] > self.window:
            hits.popleft()
        if hits is not None and not hits:
            del self._hits[key]

    def blocked(self, key) -> bool:
        now = time.monotonic()
        with self._lock:
            self._prune(key, now)
            return len(self._hits.get(key, ())) >= self.limit

    def fail(self, key) -> None:
        now = time.monotonic()
        with self._lock:
            self._prune(key, now)
            self._hits.setdefault(key, deque()).append(now)

    def reset(self, key) -> None:
        with self._lock:
            self._hits.pop(key, None)
