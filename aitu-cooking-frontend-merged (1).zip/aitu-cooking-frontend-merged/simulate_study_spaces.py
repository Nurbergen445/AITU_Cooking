"""Development-only Smart Study Space simulation.

Run once with:
    python simulate_study_spaces.py --enable-simulation --once
Or repeat at a chosen interval:
    python simulate_study_spaces.py --enable-simulation --interval 30
"""
import argparse
import os
import random
import time
from datetime import datetime, timezone

import db
import study_spaces
from app import create_app


def generate_readings(con):
    observed_at = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    spaces = con.execute("SELECT id, capacity FROM study_spaces ORDER BY id").fetchall()
    for space in spaces:
        occupancy = random.randint(0, space["capacity"])
        signal = random.randint(-78, -38)
        speed = round(random.uniform(8, 180), 1)
        with db.transaction() as transaction:
            study_spaces.record_occupancy(
                transaction, space["id"], occupancy, "simulation", observed_at, source="simulated"
            )
            study_spaces.record_wifi(
                transaction, space["id"], signal, speed, "simulation", observed_at, source="simulated"
            )


def main():
    parser = argparse.ArgumentParser(description="Generate clearly marked Smart Study Space demo readings.")
    parser.add_argument("--enable-simulation", action="store_true", help="Explicitly opt in to simulated readings.")
    parser.add_argument("--once", action="store_true", help="Write one batch and exit.")
    parser.add_argument("--interval", type=int, default=30, help="Seconds between batches (minimum 10).")
    parser.add_argument("--database", help="SQLite database path; defaults to the application's configured database.")
    args = parser.parse_args()
    if not args.enable_simulation:
        parser.error("simulation is off by default; pass --enable-simulation to proceed")
    if args.interval < 10:
        parser.error("--interval must be at least 10 seconds")
    if os.environ.get("APP_ENV", "").lower() == "production":
        parser.error("simulation is disabled when APP_ENV=production")

    app = create_app(args.database)
    with app.app_context():
        while True:
            generate_readings(db.get_db())
            print("Stored simulated study-space readings.", flush=True)
            if args.once:
                break
            time.sleep(args.interval)


if __name__ == "__main__":
    main()
