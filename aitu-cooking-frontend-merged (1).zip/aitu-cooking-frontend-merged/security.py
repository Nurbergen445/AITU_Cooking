"""Пароли (PBKDF2-HMAC-SHA256, 200 000 итераций) и валидация ввода.

Формат хранения в users.password:
    pbkdf2_sha256$<итерации>$<соль в hex>$<хеш в hex>
"""
import hashlib
import hmac
import re
import secrets
from datetime import date

ALGORITHM = "pbkdf2_sha256"
ITERATIONS = 200_000
SALT_BYTES = 16


# --------------------------------------------------------------------------- #
# Пароли
# --------------------------------------------------------------------------- #
def hash_password(password: str, iterations: int = ITERATIONS) -> str:
    """Хеш с новой случайной солью."""
    salt = secrets.token_bytes(SALT_BYTES)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"{ALGORITHM}${iterations}${salt.hex()}${digest.hex()}"


def is_hashed(stored: str) -> bool:
    return isinstance(stored, str) and stored.startswith(ALGORITHM + "$")


def _parse(stored: str):
    """Возвращает (iterations, salt, digest) или None, если формат неверный."""
    try:
        algo, iters, salt_hex, digest_hex = stored.split("$")
        if algo != ALGORITHM:
            return None
        return int(iters), bytes.fromhex(salt_hex), bytes.fromhex(digest_hex)
    except (ValueError, AttributeError):
        return None


def verify_password(password: str, stored: str) -> bool:
    parsed = _parse(stored)
    if parsed is None:
        return False
    iterations, salt, expected = parsed
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return hmac.compare_digest(actual, expected)  # сравнение за константное время


def needs_rehash(stored: str) -> bool:
    """True, если хеш создан с меньшим числом итераций, чем сейчас требуется."""
    parsed = _parse(stored)
    return parsed is None or parsed[0] < ITERATIONS


# Фиктивный хеш: при логине с несуществующим email мы всё равно считаем PBKDF2,
# чтобы по времени ответа нельзя было понять, есть ли такой пользователь.
DUMMY_HASH = hash_password("dummy-password-for-timing")


# --------------------------------------------------------------------------- #
# Валидация ввода (белые списки — вторая линия обороны после параметризации)
# --------------------------------------------------------------------------- #
EMAIL_RE = re.compile(r"^[a-z0-9._%+\-]{1,64}@astanait\.edu\.kz$")
NICKNAME_RE = re.compile(r"^[\w .\-]{2,32}$")
# Текст правила для подсказки под полем и для сообщения об ошибке — один и тот же везде.
NICKNAME_HINT = "2–32 characters: letters, digits, space, _ . -"
# То же правило для атрибута pattern в HTML (браузер проверяет символы до отправки формы).
# \p{L}\p{N} вместо \w: в JavaScript \w знает только латиницу, а сервер принимает и кириллицу.
NICKNAME_HTML_PATTERN = r"[\p{L}\p{N}_ .\-]{2,32}"
ROLES = ("student", "admin")
INVITE_RE = re.compile(r"^[A-Za-z0-9]{4,16}$")
PASSWORD_MIN, PASSWORD_MAX = 8, 128

# Группы: то же правило символов, что у никнейма, но длиннее.
GROUP_NAME_RE = re.compile(r"^[\w .\-]{2,40}$")
GROUP_NAME_HINT = "2–40 characters: letters, digits, space, _ . -"
GROUP_NAME_HTML_PATTERN = r"[\p{L}\p{N}_ .\-]{2,40}"
# Код приглашения: 8 знаков без похожих (0/O, 1/I/L): 31^8 ≈ 8·10^11 вариантов — перебором не угадать.
INVITE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
INVITE_LENGTH = 8
# После входа можно вернуть пользователя только на страницу приглашения (защита от open redirect).
NEXT_RE = re.compile(r"^/join/[A-Za-z0-9]{4,16}$")
# Задания (R7)
ASSIGNMENT_STATUSES = ("todo", "doing", "done")
ASSIGNMENT_TITLE_MAX = 120


def normalize_email(value: str) -> str:
    return (value or "").strip().lower()


def valid_email(value: str) -> bool:
    return bool(EMAIL_RE.fullmatch(value))


def valid_nickname(value: str) -> bool:
    return bool(NICKNAME_RE.fullmatch(value))


def valid_password(value: str) -> bool:
    return PASSWORD_MIN <= len(value) <= PASSWORD_MAX


def valid_invite_code(value: str) -> bool:
    return bool(INVITE_RE.fullmatch(value))


def valid_group_name(value: str) -> bool:
    return bool(GROUP_NAME_RE.fullmatch(value))


def generate_invite_code() -> str:
    """Случайный код из криптостойкого генератора (secrets), а не из random."""
    return "".join(secrets.choice(INVITE_ALPHABET) for _ in range(INVITE_LENGTH))


def safe_next(value) -> str | None:
    """Адрес для возврата после входа или None, если он не выглядит как /join/<код>."""
    return value if isinstance(value, str) and NEXT_RE.fullmatch(value) else None


def valid_assignment_title(value: str) -> bool:
    return 1 <= len(value) <= ASSIGNMENT_TITLE_MAX and value.isprintable()


def parse_iso_date(value):
    """'YYYY-MM-DD' → date или None (год 2000–2100, чтобы не принимать мусор)."""
    try:
        parsed = date.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    return parsed if 2000 <= parsed.year <= 2100 else None


def parse_int(value, lo: int, hi: int):
    """int из формы в диапазоне [lo, hi] или None."""
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if lo <= number <= hi else None


def like_escape(value: str) -> str:
    """Экранирует % и _ для LIKE ... ESCAPE '\\'."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
