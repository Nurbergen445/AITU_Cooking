"""Проверки: создание групп, коды и ссылки приглашения, управление группой лидером,
недельные рейтинги, значки и задания (R2, R4, R5, R6, R7, R10).

Запуск:  python test_groups.py
Как и остальные тесты, работает на временной копии базы.
"""
import datetime
import re
import sqlite3
import unittest

import badges
import security
import throttle
from app import MAX_ASSIGNMENTS, MAX_GROUPS_CREATED, due_label, week_start_utc
from test_app import Base

U1 = ("240101@astanait.edu.kz", "qwertyuiop")   # id 1, лидер группы 1 (ICT2026)
U2 = ("240102@astanait.edu.kz", "123456789")    # id 2, участник групп 1 и 2
U3 = ("240103@astanait.edu.kz", "aa1234bb")     # id 3, лидер группы 2 (DEV999), админ


class SocialBase(Base):
    def new_user(self, n, nickname=None):
        """Новый студент с известным паролем; возвращает (id, email, password)."""
        email, password = f"26{n:04d}@astanait.edu.kz", "longenough1"
        con = sqlite3.connect(self.path)
        with con:
            cur = con.execute("INSERT INTO users (email, password, nickname) VALUES (?, ?, ?)",
                              (email, security.hash_password(password), nickname or f"Tester{n}"))
        con.close()
        return cur.lastrowid, email, password

    def csrf(self, client, page="/groups"):
        html = client.get(page).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)

    def session_for(self, email, password):
        client = self.app.test_client()
        r = client.post("/login", data={"email": email, "password": password, "csrf_token": self.csrf(client, "/login")})
        self.assertEqual(r.status_code, 302)
        return client

    def send(self, client, url, data=None, page="/groups"):
        return client.post(url, data=dict(data or {}, csrf_token=self.csrf(client, page)))

    def flashes(self, client, url="/groups"):
        html = client.get(url).get_data(as_text=True)
        return " | ".join(re.findall(r'<div class="flash">(.*?)</div>', html, re.S))

    def sql(self, sql, params=()):
        con = sqlite3.connect(self.path)
        try:
            with con:
                return con.execute(sql, params).fetchall()
        finally:
            con.close()

    def group_row(self, group_id):
        rows = self.rows("SELECT id, name, invite_code, created_by FROM groups WHERE id = ?", (group_id,))
        return rows[0] if rows else None

    def member_ids(self, group_id):
        return sorted(r[0] for r in self.rows("SELECT user_id FROM group_members WHERE group_id = ?", (group_id,)))


class CreateGroupTests(SocialBase):
    def test_creator_becomes_leader_and_first_member(self):
        client = self.session_for(*U2)
        before = self.rows("SELECT COUNT(*) FROM groups")[0][0]
        r = self.send(client, "/groups", {"name": "Calc Crew"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM groups")[0][0], before + 1)
        gid, name, code, created_by = self.rows("SELECT id, name, invite_code, created_by FROM groups ORDER BY id DESC LIMIT 1")[0]
        self.assertEqual((name, created_by), ("Calc Crew", 2))
        self.assertEqual(self.member_ids(gid), [2])
        self.assertTrue(r.headers["Location"].endswith(f"/groups/{gid}"))
        self.assertIn(code, self.flashes(client, f"/groups/{gid}"))
        page = client.get(f"/groups/{gid}").get_data(as_text=True)
        self.assertIn("Manage group", page)
        self.assertIn(f"/join/{code}", page)  # ссылка-приглашение показана лидеру

    def test_code_format_and_uniqueness(self):
        for _ in range(500):
            code = security.generate_invite_code()
            self.assertRegex(code, r"^[A-HJ-NP-Z2-9]{8}$")  # без 0, 1, I, L, O
            self.assertTrue(security.valid_invite_code(code))
        self.assertEqual(len({security.generate_invite_code() for _ in range(2000)}), 2000)
        client = self.session_for(*U2)
        for i in range(3):
            self.send(client, "/groups", {"name": f"Crew {i}"})
        codes = [r[0] for r in self.rows("SELECT invite_code FROM groups")]
        self.assertEqual(len(codes), len(set(codes)))

    def test_name_whitespace_is_collapsed(self):
        client = self.session_for(*U2)
        self.send(client, "/groups", {"name": "  Calc     Crew  "})
        self.assertEqual(self.rows("SELECT name FROM groups ORDER BY id DESC LIMIT 1")[0][0], "Calc Crew")

    def test_invalid_names_are_rejected(self):
        client = self.session_for(*U2)
        before = self.rows("SELECT COUNT(*) FROM groups")[0][0]
        for bad in ("", " ", "x", "x" * 41, "<script>alert(1)</script>", "a;b", "a/b", "a'b",
                    "'; DROP TABLE groups; --", "a\nb\tc\x00d"):
            r = self.send(client, "/groups", {"name": bad})
            self.assertEqual(r.status_code, 302, repr(bad))
            self.assertTrue(r.headers["Location"].endswith("/groups"), repr(bad))
        self.assertEqual(self.rows("SELECT COUNT(*) FROM groups")[0][0], before)
        self.assertIn("Group name", self.flashes(client))
        self.assert_schema_intact()

    def test_name_rule_matches_html_pattern(self):
        ok = ["Ab", "ICT 2026", "a_b.c-d", "Группа 1", "x" * 40]
        bad = ["x", "x" * 41, "a;b", "a<b>", ""]
        for value in ok:
            self.assertTrue(security.valid_group_name(value), value)
        for value in bad:
            self.assertFalse(security.valid_group_name(value), value)
        html = self.session_for(*U2).get("/groups").get_data(as_text=True)
        self.assertIn('pattern="[\\p{L}\\p{N}_ .\\-]{2,40}"', html)
        self.assertIn(security.GROUP_NAME_HINT, html)

    def test_hostile_group_name_in_database_is_escaped(self):
        """Даже если строка с тегами попала в базу в обход формы, страницы её экранируют."""
        evil = '<img src=x onerror=alert(1)>'
        self.sql("UPDATE groups SET name = ? WHERE id = 1", (evil,))
        client = self.session_for(*U1)
        for url in ("/groups", "/groups/1"):
            html = client.get(url).get_data(as_text=True)
            self.assertNotIn(evil, html, url)
            self.assertIn("&lt;img src=x onerror=alert(1)&gt;", html, url)

    def test_creation_limit(self):
        for i in range(MAX_GROUPS_CREATED):
            self.sql("INSERT INTO groups (name, invite_code, created_by) VALUES (?, ?, 2)", (f"G{i}", f"LIMIT{i:03d}"))
        client = self.session_for(*U2)
        before = self.rows("SELECT COUNT(*) FROM groups")[0][0]
        self.send(client, "/groups", {"name": "One too many"})
        self.assertEqual(self.rows("SELECT COUNT(*) FROM groups")[0][0], before)
        self.assertIn("up to", self.flashes(client))

    def test_requires_login_and_csrf(self):
        anon = self.app.test_client()
        before = self.rows("SELECT COUNT(*) FROM groups")[0][0]
        self.assertEqual(anon.post("/groups", data={"name": "Sneaky"}).status_code, 400)  # CSRF раньше логина
        client = self.session_for(*U2)
        self.assertEqual(client.post("/groups", data={"name": "Sneaky"}).status_code, 400)
        self.assertEqual(client.post("/groups", data={"name": "Sneaky", "csrf_token": "x"}).status_code, 400)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM groups")[0][0], before)
        token = self.csrf(anon, "/login")
        r = anon.post("/groups", data={"name": "Sneaky", "csrf_token": token})
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])
        self.assertEqual(self.rows("SELECT COUNT(*) FROM groups")[0][0], before)


class JoinTests(SocialBase):
    def test_join_by_code_case_insensitive_goes_to_group_page(self):
        uid, email, pw = self.new_user(1)
        client = self.session_for(email, pw)
        r = self.send(client, "/groups/join", {"invite_code": " ict2026 "})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/groups/1"))
        self.assertIn(uid, self.member_ids(1))
        self.assertIn("You joined the group", self.flashes(client, "/groups/1"))
        self.assertEqual(client.get("/groups/1").status_code, 200)

    def test_joining_twice_is_harmless(self):
        client = self.session_for(*U2)
        before = self.member_ids(1)
        self.send(client, "/groups/join", {"invite_code": "ICT2026"})
        self.assertEqual(self.member_ids(1), before)
        self.assertIn("already in", self.flashes(client, "/groups/1"))

    def test_invalid_codes(self):
        uid, email, pw = self.new_user(2)
        client = self.session_for(email, pw)
        before = self.rows("SELECT COUNT(*) FROM group_members")[0][0]
        for bad in ("", "NOPE", "ICT2025", "' OR 1=1 --", "ICT2026' --", "x" * 40, "%", "ICT 2026"):
            r = self.send(client, "/groups/join", {"invite_code": bad})
            self.assertTrue(r.headers["Location"].endswith("/groups"), repr(bad))
        self.assertEqual(self.rows("SELECT COUNT(*) FROM group_members")[0][0], before)
        self.assert_schema_intact()

    def test_wrong_codes_are_throttled_per_user(self):
        uid, email, pw = self.new_user(3)
        client = self.session_for(email, pw)
        for i in range(10):
            self.send(client, "/groups/join", {"invite_code": f"WRONG{i}"})
        self.send(client, "/groups/join", {"invite_code": "ICT2026"})  # верный, но попытки исчерпаны
        self.assertNotIn(uid, self.member_ids(1))
        self.assertIn("Too many", self.flashes(client))
        # другой пользователь не затронут
        uid2, email2, pw2 = self.new_user(4)
        other = self.session_for(email2, pw2)
        self.send(other, "/groups/join", {"invite_code": "ICT2026"})
        self.assertIn(uid2, self.member_ids(1))

    def test_throttle_unit(self):
        t = throttle.Throttle(2, 60)
        self.assertFalse(t.blocked("a"))
        t.fail("a"); t.fail("a")
        self.assertTrue(t.blocked("a"))
        self.assertFalse(t.blocked("b"))
        t.reset("a")
        self.assertFalse(t.blocked("a"))

    # ------------------------------------------------------------------ ссылка-приглашение
    def test_invite_link_flow_for_logged_out_visitor(self):
        uid, email, pw = self.new_user(5)
        anon = self.app.test_client()
        r = anon.get("/join/ict2026")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/login?next=/join/ICT2026"), r.headers["Location"])
        login_page = anon.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn('name="next" value="/join/ICT2026"', login_page)
        self.assertIn("Log in to join", login_page)
        self.assertIn("register?next=", login_page)
        token = re.search(r'name="csrf_token" value="([0-9a-f]+)"', login_page).group(1)
        r = anon.post("/login", data={"email": email, "password": pw, "csrf_token": token, "next": "/join/ICT2026"})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/join/ICT2026"))
        page = anon.get("/join/ICT2026").get_data(as_text=True)
        self.assertIn("ICT Study Group", page)
        self.assertIn('action="/groups/join"', page)
        self.assertNotIn(uid, self.member_ids(1))   # GET ничего не меняет
        r = self.send(anon, "/groups/join", {"invite_code": "ICT2026"}, "/join/ICT2026")
        self.assertTrue(r.headers["Location"].endswith("/groups/1"))
        self.assertIn(uid, self.member_ids(1))

    def test_register_keeps_next(self):
        anon = self.app.test_client()
        html = anon.get("/register?next=/join/ICT2026").get_data(as_text=True)
        self.assertIn('name="next" value="/join/ICT2026"', html)
        token = re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)
        r = anon.post("/register", data={"email": "260777@astanait.edu.kz", "nickname": "Newbie",
                                         "password": "longenough1", "csrf_token": token, "next": "/join/ICT2026"})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/login?next=/join/ICT2026"), r.headers["Location"])

    def test_next_cannot_redirect_away_from_the_site(self):
        for evil in ("//evil.example", "https://evil.example", "/dashboard", "/join/../x", "/join/ICT2026/extra",
                     "javascript:alert(1)", "/join/", "/join/ab"):
            self.assertIsNone(security.safe_next(evil), evil)
            anon = self.app.test_client()
            r = anon.post("/login", data={"email": U1[0], "password": U1[1], "next": evil,
                                          "csrf_token": self.csrf(anon, "/login")})
            self.assertTrue(r.headers["Location"].endswith("/dashboard"), (evil, r.headers["Location"]))
        html = self.app.test_client().get("/login?next=//evil.example").get_data(as_text=True)
        self.assertNotIn("evil.example", html)

    def test_unknown_invite_link(self):
        client = self.session_for(*U2)
        r = client.get("/join/ZZZZ9999")
        self.assertEqual(r.status_code, 404)
        self.assertIn("Invite not found", r.get_data(as_text=True))
        self.assertEqual(client.get("/join/%27%20OR%201=1").status_code, 404)
        anon = self.app.test_client().get("/join/%27%20OR%201=1")
        self.assertTrue(anon.headers["Location"].endswith("/login"))  # мусор не попадает в next

    def test_link_for_existing_member_goes_to_group(self):
        client = self.session_for(*U2)
        r = client.get("/join/ICT2026")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/groups/1"))


class LeaderTests(SocialBase):
    def test_regenerate_code_replaces_old_code_and_link(self):
        leader = self.session_for(*U1)
        old = self.group_row(1)[2]
        r = self.send(leader, "/groups/1/regenerate-code", page="/groups/1")
        self.assertEqual(r.status_code, 302)
        new = self.group_row(1)[2]
        self.assertNotEqual(old, new)
        self.assertRegex(new, r"^[A-HJ-NP-Z2-9]{8}$")
        uid, email, pw = self.new_user(6)
        newbie = self.session_for(email, pw)
        self.assertEqual(newbie.get(f"/join/{old}").status_code, 404)
        self.send(newbie, "/groups/join", {"invite_code": old})
        self.assertNotIn(uid, self.member_ids(1))
        self.send(newbie, "/groups/join", {"invite_code": new})
        self.assertIn(uid, self.member_ids(1))

    def test_only_the_leader_manages(self):
        member = self.session_for(*U2)       # участник, не лидер
        uid, email, pw = self.new_user(7)
        outsider = self.session_for(email, pw)
        before = self.group_row(1)
        members_before = self.member_ids(1)
        actions = ("/groups/1/regenerate-code", "/groups/1/members/3/remove", "/groups/1/delete")
        for url in actions:
            self.assertEqual(self.send(member, url, page="/groups/1").status_code, 403, url)
            self.assertEqual(self.send(outsider, url, page="/groups").status_code, 404, url)
        self.assertEqual(self.group_row(1), before)
        self.assertEqual(self.member_ids(1), members_before)
        page = member.get("/groups/1").get_data(as_text=True)
        self.assertNotIn("Manage group", page)
        self.assertIn("Leave group", page)
        self.assertEqual(outsider.get("/groups/1").status_code, 404)

    def test_remove_member(self):
        leader = self.session_for(*U1)
        r = self.send(leader, "/groups/1/members/2/remove", page="/groups/1")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.member_ids(1), [1, 3])
        self.assertIn("removed", self.flashes(leader, "/groups/1"))
        removed = self.session_for(*U2)
        self.assertEqual(removed.get("/groups/1").status_code, 404)      # группа больше не видна
        self.assertEqual(removed.get("/groups/1/live").status_code, 404)
        self.assertEqual(self.send(leader, "/groups/1/members/2/remove", page="/groups/1").status_code, 404)

    def test_leader_cannot_remove_self_or_leave(self):
        leader = self.session_for(*U1)
        self.send(leader, "/groups/1/members/1/remove", page="/groups/1")
        self.assertIn(1, self.member_ids(1))
        self.send(leader, "/groups/1/leave", page="/groups/1")
        self.assertIn(1, self.member_ids(1))
        self.assertIn("Delete", self.flashes(leader, "/groups/1"))

    def test_member_can_leave(self):
        member = self.session_for(*U2)
        r = self.send(member, "/groups/1/leave", page="/groups/1")
        self.assertTrue(r.headers["Location"].endswith("/groups"))
        self.assertNotIn(2, self.member_ids(1))
        self.assertIsNotNone(self.group_row(1))            # группа осталась
        self.assertIn(2, self.member_ids(2))               # другие группы не тронуты

    def test_delete_group_removes_members_but_not_study_data(self):
        sessions_before = self.rows("SELECT COUNT(*) FROM sessions")[0][0]
        users_before = self.rows("SELECT COUNT(*) FROM users")[0][0]
        leader = self.session_for(*U1)
        r = self.send(leader, "/groups/1/delete", page="/groups/1")
        self.assertTrue(r.headers["Location"].endswith("/groups"))
        self.assertIsNone(self.group_row(1))
        self.assertEqual(self.member_ids(1), [])
        self.assertEqual(self.rows("SELECT COUNT(*) FROM sessions")[0][0], sessions_before)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM users")[0][0], users_before)
        self.assertEqual(leader.get("/groups/1").status_code, 404)

    def test_manage_actions_need_csrf(self):
        leader = self.session_for(*U1)
        for url in ("/groups/1/regenerate-code", "/groups/1/members/2/remove", "/groups/1/delete", "/groups/1/leave"):
            self.assertEqual(leader.post(url).status_code, 400, url)
        self.assertEqual(self.member_ids(1), [1, 2, 3])

    def test_group_page_marks_leader_and_lists_leader_in_payload(self):
        import json
        html = self.session_for(*U2).get("/groups/1").get_data(as_text=True)
        payload = json.loads(re.search(r'id="group-data">(.*?)</script>', html, re.S).group(1))
        leaders = [m["name"] for m in payload["members"] if m["leader"]]
        self.assertEqual(leaders, ["Nurik Shurik"])
        self.assertIn('id="copy-link"', html)

    def test_groups_list_shows_leader_badge_only_on_own_groups(self):
        html = self.session_for(*U1).get("/groups").get_data(as_text=True)
        self.assertEqual(html.count('class="badge">leader'), 1)   # лидер ICT Study Group; Dev Team у него нет


class WeeklyTests(SocialBase):
    def test_week_start_is_monday_midnight_in_users_timezone(self):
        for tz in (0, 300, -420, 840, -840):
            start = datetime.datetime.strptime(week_start_utc(tz), "%Y-%m-%d %H:%M:%S")
            local = start + datetime.timedelta(minutes=tz)
            self.assertEqual((local.weekday(), local.hour, local.minute, local.second), (0, 0, 0, 0), tz)
            now_local = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None) + datetime.timedelta(minutes=tz)
            self.assertLessEqual(local, now_local)
            self.assertGreater(local + datetime.timedelta(days=7), now_local)

    def seconds(self, client, name, period):
        data = client.get(f"/groups/1/live?period={period}").get_json()
        return next(m["seconds"] for m in data["members"] if m["name"] == name)

    def test_group_periods_today_week_all(self):
        self.sql("INSERT INTO sessions (user_id, subject_id, duration_min) VALUES (2, 1, 30)")
        self.sql("INSERT INTO sessions (user_id, subject_id, duration_min, started_at) VALUES (2, 1, 100, datetime('now', '-10 days'))")
        client = self.session_for(*U2)
        base = {p: self.seconds(client, "Elzhanium", p) for p in ("today", "week", "all")}
        # «до»: всё, что было в базе; считаем разницу с тем, что добавили выше
        self.sql("DELETE FROM sessions WHERE duration_min IN (30, 100) AND user_id = 2 AND subject_id = 1 "
                 "AND started_at >= datetime('now', '-11 days')")
        clean = {p: self.seconds(client, "Elzhanium", p) for p in ("today", "week", "all")}
        self.assertEqual(base["today"] - clean["today"], 30 * 60)
        self.assertEqual(base["week"] - clean["week"], 30 * 60)           # сессия 10-дневной давности — не в этой неделе
        self.assertEqual(base["all"] - clean["all"], 130 * 60)

    def test_group_page_has_week_tab_and_unknown_period_falls_back(self):
        client = self.session_for(*U2)
        html = client.get("/groups/1?period=week").get_data(as_text=True)
        self.assertIn('data-period="week"', html)
        self.assertRegex(html, r'class="on" aria-current="true">This week')
        for bad in ("'; DROP TABLE sessions; --", "WEEK", "", "all%00"):
            self.assertEqual(client.get("/groups/1/live", query_string={"period": bad}).get_json()["period"], "today")
        self.assert_schema_intact()

    def test_global_weekly_leaderboard(self):
        uid, email, pw = self.new_user(8, nickname="WeeklyHero")
        self.sql("INSERT INTO sessions (user_id, subject_id, duration_min) VALUES (?, 1, 95)", (uid,))
        self.sql("INSERT INTO sessions (user_id, subject_id, duration_min, started_at) VALUES (2, 1, 500, datetime('now', '-12 days'))")
        client = self.session_for(email, pw)
        html = client.get("/leaderboard?sort=week").get_data(as_text=True)
        self.assertLess(html.index("WeeklyHero"), html.index("Elzhanium"))   # 500 минут 12 дней назад не считаются
        self.assertIn("1h 35m", html)
        self.assertIn("This week", html)
        self.assertEqual(client.get("/leaderboard?sort=xp").status_code, 200)


class BadgeTests(SocialBase):
    def stats(self, **kw):
        base = dict(sessions=0, total_min=0, longest_min=0, streak_days=0, total_xp=0, groups=0)
        return dict(base, **kw)

    def earned(self, **kw):
        return {b["id"] for b in badges.compute_badges(self.stats(**kw)) if b["earned"]}

    def test_thresholds(self):
        self.assertEqual(self.earned(), set())
        self.assertEqual(self.earned(sessions=1), {"first-session"})
        self.assertNotIn("one-hour", self.earned(total_min=59))
        self.assertIn("one-hour", self.earned(total_min=60))
        self.assertIn("ten-hours", self.earned(total_min=600))
        self.assertNotIn("deep-focus", self.earned(longest_min=89))
        self.assertIn("deep-focus", self.earned(longest_min=90))
        self.assertEqual(self.earned(streak_days=3), {"streak-3"})
        self.assertEqual(self.earned(streak_days=7), {"streak-3", "streak-7"})
        self.assertEqual(self.earned(total_xp=500), {"xp-100", "xp-500"})
        self.assertEqual(self.earned(groups=1), {"team-player"})

    def test_profile_shows_badges_from_real_data(self):
        html = self.session_for(*U3).get("/profile").get_data(as_text=True)   # 600 XP, серия 7, в группах
        for name in ("Week streak", "500 XP", "Team player"):
            self.assertRegex(html, r'badge-tile earned" title="[^"]*">\s*<span class="badge-medal"[^>]*>.*?</span>\s*<strong>' + name, name)
        uid, email, pw = self.new_user(9)
        fresh = self.session_for(email, pw).get("/profile").get_data(as_text=True)
        self.assertNotIn("badge-tile earned", fresh)
        self.assertIn(f"0 of {len(badges.BADGES)}", fresh)

    def test_joining_and_studying_earns_badges(self):
        uid, email, pw = self.new_user(10)
        client = self.session_for(email, pw)
        self.send(client, "/groups/join", {"invite_code": "ICT2026"})
        self.send(client, "/sessions", {"subject_id": "1", "duration_min": "95"}, "/profile")
        html = client.get("/profile").get_data(as_text=True)
        self.assertEqual(html.count("badge-tile earned"), 4)   # first step, one hour, deep focus, team player


class AssignmentTests(SocialBase):
    def add(self, client, title, deadline, subject=""):
        return self.send(client, "/todo", {"title": title, "deadline": deadline, "subject_id": subject}, "/todo")

    def titles(self, client):
        html = client.get("/todo").get_data(as_text=True)
        return re.findall(r'<span class="todo-text">(.*?)</span>', html, re.S)

    def test_sorted_by_deadline_with_done_last(self):
        client = self.session_for(*U2)
        self.add(client, "Third", "2026-12-30")
        self.add(client, "First", "2026-11-10")
        self.add(client, "Second", "2026-12-01", "1")
        self.assertEqual(self.titles(client), ["First", "Second", "Third"])
        first_id = self.rows("SELECT id FROM assignments WHERE title = 'First'")[0][0]
        self.send(client, f"/todo/{first_id}/status", {"status": "done"}, "/todo")
        self.assertEqual(self.titles(client), ["Second", "Third", "First"])   # выполненные уходят вниз
        html = client.get("/todo").get_data(as_text=True)
        self.assertIn("1 done", html)
        self.assertIn("Calculus", html)   # предмет показан

    def test_status_cycle_and_validation(self):
        client = self.session_for(*U2)
        self.add(client, "Lab report", "2026-12-01")
        aid = self.rows("SELECT id FROM assignments")[0][0]
        for status in ("doing", "done", "todo"):
            self.send(client, f"/todo/{aid}/status", {"status": status}, "/todo")
            self.assertEqual(self.rows("SELECT status FROM assignments WHERE id = ?", (aid,))[0][0], status)
        for bad in ("", "finished", "done'; DROP TABLE assignments;--", "DONE"):
            self.assertEqual(self.send(client, f"/todo/{aid}/status", {"status": bad}, "/todo").status_code, 400, bad)
        self.assertEqual(self.rows("SELECT status FROM assignments WHERE id = ?", (aid,))[0][0], "todo")

    def test_bad_input_is_rejected(self):
        client = self.session_for(*U2)
        bad = [("", "2026-12-01", ""), ("   ", "2026-12-01", ""), ("x" * 121, "2026-12-01", ""),
               ("Ok", "", ""), ("Ok", "2026-02-30", ""), ("Ok", "tomorrow", ""), ("Ok", "1999-01-01", ""),
               ("Ok", "2101-01-01", ""), ("Ok", "2026-12-01", "999"), ("Ok", "2026-12-01", "1 OR 1=1"),
               ("Ok", "2026-12-01", "abc"), ("bell\x07char", "2026-12-01", "")]
        for title, deadline, subject in bad:
            self.add(client, title, deadline, subject)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM assignments")[0][0], 0)
        self.assert_schema_intact()

    def test_title_is_escaped(self):
        client = self.session_for(*U2)
        self.add(client, "<script>alert(1)</script>", "2026-12-01")
        html = client.get("/todo").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", html)

    def test_users_see_and_change_only_their_own(self):
        owner, other = self.session_for(*U1), self.session_for(*U2)
        self.add(owner, "Secret plan", "2026-12-01")
        aid = self.rows("SELECT id FROM assignments")[0][0]
        self.assertNotIn("Secret plan", other.get("/todo").get_data(as_text=True))
        self.assertEqual(self.send(other, f"/todo/{aid}/status", {"status": "done"}, "/todo").status_code, 404)
        self.assertEqual(self.send(other, f"/todo/{aid}/delete", page="/todo").status_code, 404)
        self.assertEqual(self.rows("SELECT status, user_id FROM assignments WHERE id = ?", (aid,))[0], ("todo", 1))
        self.assertEqual(self.send(owner, f"/todo/{aid}/delete", page="/todo").status_code, 302)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM assignments")[0][0], 0)

    def test_requires_login_and_csrf(self):
        anon = self.app.test_client()
        self.assertEqual(anon.get("/todo").status_code, 302)
        client = self.session_for(*U2)
        self.add(client, "Mine", "2026-12-01")
        aid = self.rows("SELECT id FROM assignments")[0][0]
        for url in ("/todo", f"/todo/{aid}/status", f"/todo/{aid}/delete"):
            self.assertEqual(client.post(url, data={"title": "x", "deadline": "2026-12-01", "status": "done"}).status_code, 400, url)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM assignments")[0][0], 1)

    def test_overdue_and_due_labels(self):
        client = self.session_for(*U2)
        yesterday = (datetime.date.today() - datetime.timedelta(days=2)).isoformat()
        self.add(client, "Late one", yesterday)
        self.add(client, "Late but done", yesterday)
        did = self.rows("SELECT id FROM assignments WHERE title = 'Late but done'")[0][0]
        self.send(client, f"/todo/{did}/status", {"status": "done"}, "/todo")
        html = client.get("/todo").get_data(as_text=True)
        self.assertEqual(html.count("tag tag-warn"), 1)          # только невыполненное просрочено
        self.assertIn("overdue by", html)
        self.assertEqual(due_label(None), "")
        self.assertEqual(due_label(-1), "overdue by 1 day")
        self.assertEqual(due_label(-3), "overdue by 3 days")
        self.assertEqual((due_label(0), due_label(1), due_label(5)), ("due today", "due tomorrow", "in 5 days"))

    def test_assignment_limit(self):
        for i in range(MAX_ASSIGNMENTS):
            self.sql("INSERT INTO assignments (user_id, title, deadline) VALUES (2, ?, '2026-12-01')", (f"T{i}",))
        client = self.session_for(*U2)
        self.add(client, "Over the limit", "2026-12-01")
        self.assertEqual(self.rows("SELECT COUNT(*) FROM assignments WHERE user_id = 2")[0][0], MAX_ASSIGNMENTS)
        self.assertIn("up to", self.flashes(client, "/todo"))

    def test_database_rejects_bad_rows_even_without_the_app(self):
        con = sqlite3.connect(self.path)
        con.execute("PRAGMA foreign_keys = ON")
        for sql in ("INSERT INTO assignments (user_id, title, deadline) VALUES (2, '', '2026-12-01')",
                    "INSERT INTO assignments (user_id, title, deadline) VALUES (2, 'x', 'soon')",
                    "INSERT INTO assignments (user_id, title, deadline, status) VALUES (2, 'x', '2026-12-01', 'maybe')",
                    "INSERT INTO assignments (user_id, title, deadline) VALUES (9999, 'x', '2026-12-01')"):
            with self.assertRaises(sqlite3.IntegrityError, msg=sql):
                con.execute(sql)
        con.close()

    def test_deleting_user_removes_their_assignments(self):
        uid, email, pw = self.new_user(11)
        client = self.session_for(email, pw)
        self.add(client, "Gone soon", "2026-12-01")
        con = sqlite3.connect(self.path)
        con.execute("PRAGMA foreign_keys = ON")
        with con:
            con.execute("DELETE FROM users WHERE id = ?", (uid,))
        con.close()
        self.assertEqual(self.rows("SELECT COUNT(*) FROM assignments WHERE user_id = ?", (uid,))[0][0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
