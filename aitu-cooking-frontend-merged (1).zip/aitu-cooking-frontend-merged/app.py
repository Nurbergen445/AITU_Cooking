"""AITU Cooking — веб-приложение для учёта учебных сессий (Flask + SQLite).

Запуск:
    pip install -r requirements.txt
    python migrate_passwords.py      # один раз: захешировать пароли в базе
    export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
    python app.py                    # доступен по локальной сети (0.0.0.0:5000)
    HOST=127.0.0.1 python app.py     # только с этого компьютера
"""
import hmac
import hashlib
import json
import os
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, session, url_for

import analytics
import badges
import db
import presence
import security
import study_spaces
import throttle

XP_PER_MINUTES = 5  # 1 XP за каждые 5 минут сессии
HOT_STREAK_DAYS = 5  # серия от стольких дней показывается значком-огоньком на экране группы
MAX_GROUPS_CREATED = 10   # сколько групп может создать один пользователь
MAX_ASSIGNMENTS = 300     # заданий на пользователя
JOIN_FAIL_LIMIT = 10      # неверных кодов приглашения ...
JOIN_FAIL_WINDOW = 600    # ... за столько секунд, после чего вход по коду блокируется

# ORDER BY нельзя параметризовать через `?`, поэтому имя колонки берётся
# только из этого белого списка, а не из запроса пользователя.
LEADERBOARD_SORT = {"xp": "total_xp", "streak": "streak_days"}


def week_start_utc(tz_minutes: int) -> str:
    """Начало текущей недели (понедельник 00:00 по времени пользователя) в UTC, как хранится started_at."""
    local_now = datetime.now(timezone.utc) + timedelta(minutes=tz_minutes)
    monday = (local_now - timedelta(days=local_now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    return (monday - timedelta(minutes=tz_minutes)).strftime("%Y-%m-%d %H:%M:%S")


def due_label(days) -> str:
    """Подпись срока для списка заданий: «due today», «in 3 days», «overdue by 2 days»."""
    if days is None:
        return ""
    if days < 0:
        return f"overdue by {-days} day{'' if days == -1 else 's'}"
    if days == 0:
        return "due today"
    if days == 1:
        return "due tomorrow"
    return f"in {days} days"


def create_app(database: str | None = None) -> Flask:
    app = Flask(__name__)
    locations_json = os.environ.get("STUDY_SPACE_LOCATIONS")
    try:
        study_space_locations = json.loads(locations_json) if locations_json else study_spaces.DEFAULT_LOCATIONS
    except json.JSONDecodeError as exc:
        raise RuntimeError("STUDY_SPACE_LOCATIONS must be a JSON array") from exc

    def int_setting(name, default, minimum, maximum):
        value = os.environ.get(name)
        try:
            parsed = int(value) if value is not None else default
        except ValueError as exc:
            raise RuntimeError(f"{name} must be an integer") from exc
        if not minimum <= parsed <= maximum:
            raise RuntimeError(f"{name} must be between {minimum} and {maximum}")
        return parsed

    study_space_thresholds = {
        "occupancy_moderate": int_setting("STUDY_SPACE_OCCUPANCY_MODERATE_PERCENT", 40, 0, 98),
        "occupancy_high": int_setting("STUDY_SPACE_OCCUPANCY_HIGH_PERCENT", 70, 1, 99),
        "wifi_excellent": int_setting("STUDY_SPACE_WIFI_EXCELLENT_DBM", -50, -120, 0),
        "wifi_good": int_setting("STUDY_SPACE_WIFI_GOOD_DBM", -60, -120, 0),
        "wifi_average": int_setting("STUDY_SPACE_WIFI_AVERAGE_DBM", -75, -120, 0),
    }
    if (study_space_thresholds["occupancy_moderate"] >= study_space_thresholds["occupancy_high"]
            or not (study_space_thresholds["wifi_excellent"] >= study_space_thresholds["wifi_good"]
                    >= study_space_thresholds["wifi_average"])):
        raise RuntimeError("Smart Study Space status thresholds are not in ascending quality order")

    app.config.update(
        DATABASE=database or os.environ.get("DATABASE_PATH") or os.path.join(app.root_path, "aitucooking.sqlite"),
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",  # включить за HTTPS
        MAX_CONTENT_LENGTH=16 * 1024,
        STUDY_SPACE_LOCATIONS=study_space_locations,
        STUDY_SPACE_THRESHOLDS=study_space_thresholds,
        STUDY_SPACE_MAX_AGE_SECONDS=int_setting("STUDY_SPACE_MAX_AGE_SECONDS", 300, 30, 86400),
        STUDY_SPACE_FUTURE_TOLERANCE_SECONDS=int_setting("STUDY_SPACE_FUTURE_TOLERANCE_SECONDS", 300, 0, 3600),
    )
    app.teardown_appcontext(db.close_db)
    with app.app_context():
        db.ensure_schema(db.get_db())
        study_spaces.initialize(db.get_db(), app.config["STUDY_SPACE_LOCATIONS"])

    # ----------------------------------------------------------------- CSRF
    def csrf_token() -> str:
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(16)
        return session["csrf"]

    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["NICKNAME_HINT"] = security.NICKNAME_HINT
    app.jinja_env.globals["NICKNAME_HTML_PATTERN"] = security.NICKNAME_HTML_PATTERN
    app.jinja_env.globals["GROUP_NAME_HINT"] = security.GROUP_NAME_HINT
    app.jinja_env.globals["GROUP_NAME_HTML_PATTERN"] = security.GROUP_NAME_HTML_PATTERN
    join_throttle = throttle.Throttle(JOIN_FAIL_LIMIT, JOIN_FAIL_WINDOW)

    @app.template_filter("hms")
    def hms(seconds) -> str:
        """Секунды → H:MM:SS (как на макете)."""
        seconds = max(0, int(seconds or 0))
        return f"{seconds // 3600}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"

    def tz_offset_minutes() -> int:
        """Часовой пояс браузера (минуты к востоку от UTC) из cookie `tzoff`, её ставит app.js.

        Нужен только чтобы понять, что такое «сегодня» у пользователя. Значение проходит
        через parse_int, а в SQL уходит параметром, а не частью строки.
        """
        return security.parse_int(request.cookies.get("tzoff"), -840, 840) or 0

    @app.before_request
    def protect_post():
        if request.method == "POST":
            if request.endpoint in {"study_space_occupancy", "study_space_wifi"}:
                return
            expected = session.get("csrf")
            sent = request.form.get("csrf_token", "") or request.headers.get("X-CSRF-Token", "")
            if not expected or not hmac.compare_digest(sent.encode(), expected.encode()):
                abort(400, "Invalid CSRF token")

    # ------------------------------------------------------- текущий пользователь
    @app.before_request
    def load_user():
        g.user = None
        user_id = session.get("user_id")
        if user_id is not None:
            # пароль в g.user намеренно не попадает
            g.user = db.query_one(
                "SELECT id, email, nickname, total_xp, streak_days, role FROM users WHERE id = ?",
                (user_id,),
            )

    def login_required(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("login"))
            return view(*args, **kwargs)
        return wrapper

    def admin_required(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("login"))
            if g.user["role"] != "admin":
                abort(403)
            return view(*args, **kwargs)
        return wrapper

    # ------------------------------------------------- создание аккаунтов (общий код)
    def signup_error(email: str, nickname: str, password: str) -> str | None:
        """Текст ошибки для формы регистрации / создания админа или None, если всё верно."""
        if not security.valid_email(email):
            return "A university e-mail like name@astanait.edu.kz is required"
        if not security.valid_nickname(nickname):
            return f"Nickname: {security.NICKNAME_HINT}"
        if not security.valid_password(password):
            return f"Password: {security.PASSWORD_MIN} to {security.PASSWORD_MAX} characters"
        return None

    def create_user(email: str, nickname: str, password: str, role: str) -> str | None:
        """INSERT нового пользователя; возвращает текст ошибки или None."""
        if role not in security.ROLES:
            raise ValueError("unknown role")
        try:
            db.execute(
                "INSERT INTO users (email, password, nickname, role) VALUES (?, ?, ?, ?)",
                (email, security.hash_password(password), nickname, role),
            )
        except sqlite3.IntegrityError:
            return "An account with this e-mail already exists"
        return None

    # ------------------------------------------------------------ аутентификация
    @app.get("/")
    def index():
        return redirect(url_for("dashboard" if g.user else "login"))

    @app.route("/register", methods=["GET", "POST"])
    def register():
        next_url = security.safe_next(request.form.get("next") or request.args.get("next"))
        if request.method == "POST":
            email = security.normalize_email(request.form.get("email"))
            nickname = (request.form.get("nickname") or "").strip()
            password = request.form.get("password") or ""

            error = signup_error(email, nickname, password) or create_user(email, nickname, password, "student")
            if error:
                flash(error)
            else:
                flash("Account created, please log in")
                return redirect(url_for("login", next=next_url) if next_url else url_for("login"))
        return render_template("register.html", next_url=next_url)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        next_url = security.safe_next(request.form.get("next") or request.args.get("next"))
        if request.method == "POST":
            email = security.normalize_email(request.form.get("email"))
            password = (request.form.get("password") or "")[: security.PASSWORD_MAX]

            user = None
            if security.valid_email(email):
                user = db.query_one("SELECT id, password FROM users WHERE email = ?", (email,))

            # Если пользователя нет — всё равно считаем PBKDF2 (одинаковое время ответа).
            stored = user["password"] if user else security.DUMMY_HASH
            ok = security.verify_password(password, stored) and user is not None

            if ok:
                if security.needs_rehash(stored):  # подтянуть старые хеши до 200k итераций
                    db.execute("UPDATE users SET password = ? WHERE id = ?",
                               (security.hash_password(password), user["id"]))
                session.clear()  # новая сессия после входа (против session fixation)
                session["user_id"] = user["id"]
                return redirect(next_url or url_for("dashboard"))  # next_url — только /join/<код>
            flash("Wrong e-mail or password")  # одно и то же сообщение для обоих случаев
        return render_template("login.html", next_url=next_url)

    # ------------------------------------------------ сброс пароля (через администратора)
    # Почтового сервера в проекте нет, поэтому ссылку для сброса выдаёт администратор:
    # студент оставляет запрос, админ видит его на /admin/users и передаёт одноразовую ссылку.
    def open_reset_sql(extra: str = "") -> str:
        return ("used_at IS NULL AND (token_hash IS NULL OR expires_at > datetime('now'))" + extra)

    @app.route("/forgot-password", methods=["GET", "POST"])
    def forgot_password():
        if request.method == "POST":
            email = security.normalize_email(request.form.get("email"))
            user = db.query_one("SELECT id FROM users WHERE email = ?", (email,)) if security.valid_email(email) else None
            if user is not None:
                pending = db.query_one(
                    f"SELECT 1 FROM password_resets WHERE user_id = ? AND {open_reset_sql()}", (user["id"],)
                )
                if pending is None:  # не больше одного открытого запроса на пользователя
                    db.execute("INSERT INTO password_resets (user_id) VALUES (?)", (user["id"],))
            # одинаковый ответ для существующего и несуществующего адреса
            flash("If this e-mail is registered, an administrator will send you a password reset link.")
            return redirect(url_for("login"))
        return render_template("forgot_password.html")

    def find_reset(token: str):
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        return db.query_one(
            """SELECT id, user_id FROM password_resets
                WHERE token_hash = ? AND used_at IS NULL AND expires_at > datetime('now')""",
            (token_hash,),
        )

    def no_store(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["Referrer-Policy"] = "no-referrer"  # токен в адресе не уходит в Referer
        return response

    @app.route("/reset/<token>", methods=["GET", "POST"])
    def reset_password(token):
        reset = find_reset(token[:128])
        if reset is None:
            return no_store(app.make_response((render_template("reset_password.html", valid=False), 400)))
        if request.method == "POST":
            password = request.form.get("password") or ""
            confirm = request.form.get("confirm") or ""
            if not security.valid_password(password):
                flash(f"Password: {security.PASSWORD_MIN} to {security.PASSWORD_MAX} characters")
            elif password != confirm:
                flash("The two passwords do not match")
            else:
                with db.transaction() as con:
                    con.execute("UPDATE users SET password = ? WHERE id = ?",
                                (security.hash_password(password), reset["user_id"]))
                    con.execute("UPDATE password_resets SET used_at = datetime('now') "
                                "WHERE user_id = ? AND used_at IS NULL", (reset["user_id"],))
                session.clear()  # старые сессии этого браузера больше не нужны
                flash("Password changed, please log in")
                return redirect(url_for("login"))
        return no_store(app.make_response(render_template("reset_password.html", valid=True)))

    @app.post("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    # --------------------------------------------------------------- страницы
    @app.get("/dashboard")
    @login_required
    def dashboard():
        """Главный экран: таймеры по предметам. Время «за сегодня» берётся из sessions."""
        tz = tz_offset_minutes()
        modifier = f"{tz:+d} minutes"
        subjects = db.query_all(
            """SELECT sub.id, sub.name, sub.code, COALESCE(SUM(s.duration_min), 0) AS minutes
               FROM subjects sub
               LEFT JOIN sessions s ON s.subject_id = sub.id AND s.user_id = ? AND s.status = 'completed'
                    AND date(datetime(s.started_at, ?)) = date(datetime('now', ?))
               GROUP BY sub.id ORDER BY sub.name""",
            (g.user["id"], modifier, modifier),
        )
        return render_template("dashboard.html", subjects=subjects, tz_offset=tz)

    @app.get("/profile")
    @login_required
    def profile():
        """Бывшая страница /dashboard: профиль, ручная запись сессии, итоги и история."""
        recent = db.query_all(
            """SELECT s.started_at, s.duration_min, s.status, sub.name AS subject
               FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
               WHERE s.user_id = ?
               ORDER BY s.started_at DESC, s.id DESC LIMIT 10""",
            (g.user["id"],),
        )
        totals = db.query_all(
            """SELECT sub.name AS subject, SUM(s.duration_min) AS minutes
               FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
               WHERE s.user_id = ? AND s.status = 'completed'
               GROUP BY sub.id ORDER BY minutes DESC""",
            (g.user["id"],),
        )
        subjects = db.query_all("SELECT id, name, code FROM subjects ORDER BY name")
        stats = db.query_one(
            """SELECT COUNT(*) AS sessions, COALESCE(SUM(duration_min), 0) AS total_min,
                      COALESCE(MAX(duration_min), 0) AS longest_min
               FROM sessions WHERE user_id = ? AND status = 'completed'""",
            (g.user["id"],),
        )
        in_groups = db.query_one("SELECT COUNT(*) AS n FROM group_members WHERE user_id = ?", (g.user["id"],))["n"]
        user_badges = badges.compute_badges(
            dict(stats, streak_days=g.user["streak_days"], total_xp=g.user["total_xp"], groups=in_groups)
        )
        return render_template("profile.html", recent=recent, totals=totals, subjects=subjects, badges=user_badges)

    @app.post("/sessions")
    @login_required
    def add_session():
        # Таймер в браузере сохраняет время через fetch (заголовок X-Requested-With: fetch)
        # и ждёт JSON; обычная форма на странице профиля работает как раньше (flash + redirect).
        wants_json = request.headers.get("X-Requested-With") == "fetch"
        subject_id = security.parse_int(request.form.get("subject_id"), 1, 2**31)
        duration = security.parse_int(request.form.get("duration_min"), 1, 720)  # как CHECK в таблице
        error = None
        if subject_id is None or duration is None:
            error = "Choose a subject and enter a duration from 1 to 720 minutes"
        elif db.query_one("SELECT 1 FROM subjects WHERE id = ?", (subject_id,)) is None:
            error = "No such subject"
        if error:
            if wants_json:
                return jsonify(ok=False, error=error), 400
            flash(error)
        else:
            with db.transaction() as con:  # сессия и XP — одной транзакцией
                con.execute(
                    "INSERT INTO sessions (user_id, subject_id, duration_min) VALUES (?, ?, ?)",
                    (g.user["id"], subject_id, duration),
                )
                con.execute(
                    "UPDATE users SET total_xp = total_xp + ? WHERE id = ?",
                    (duration // XP_PER_MINUTES, g.user["id"]),
                )
            if wants_json:
                return jsonify(ok=True, minutes=duration, xp=duration // XP_PER_MINUTES)
            flash(f"Session saved: +{duration // XP_PER_MINUTES} XP")
        return redirect(url_for("profile"))

    @app.get("/leaderboard")
    @login_required
    def leaderboard():
        sort = request.args.get("sort", "xp")
        if sort == "week":  # «за неделю» считается по сессиям, а не по накопленному XP
            rows = db.query_all(
                """SELECT u.id, u.nickname, u.total_xp, u.streak_days,
                          COALESCE(SUM(s.duration_min), 0) AS week_min
                   FROM users u
                   LEFT JOIN sessions s ON s.user_id = u.id AND s.status = 'completed' AND s.started_at >= ?
                   GROUP BY u.id ORDER BY week_min DESC, u.total_xp DESC, u.id LIMIT 20""",
                (week_start_utc(tz_offset_minutes()),),
            )
            return render_template("leaderboard.html", rows=rows, sort="week")
        column = LEADERBOARD_SORT.get(sort, LEADERBOARD_SORT["xp"])  # неизвестное значение → по умолчанию
        sort = sort if sort in LEADERBOARD_SORT else "xp"
        # f-строка безопасна: `column` — одна из констант выше, а не ввод пользователя
        rows = db.query_all(
            f"SELECT id, nickname, total_xp, streak_days FROM users ORDER BY {column} DESC, id LIMIT 20"
        )
        return render_template("leaderboard.html", rows=rows, sort=sort)

    @app.get("/subjects")
    @login_required
    def subjects():
        q = request.args.get("q", "").strip()[:50]
        pattern = "%" + security.like_escape(q) + "%"
        rows = db.query_all(
            """SELECT name, code FROM subjects
               WHERE name LIKE ? ESCAPE '\\' OR code LIKE ? ESCAPE '\\'
               ORDER BY name""",
            (pattern, pattern),
        )
        return render_template("subjects.html", rows=rows, q=q)

    @app.get("/groups")
    @login_required
    def groups():
        rows = db.query_all(
            """SELECT g.id, g.name, g.invite_code, (g.created_by = ?) AS is_leader,
                      (SELECT COUNT(*) FROM group_members m2 WHERE m2.group_id = g.id) AS members
               FROM groups g JOIN group_members m ON m.group_id = g.id
               WHERE m.user_id = ? ORDER BY g.name""",
            (g.user["id"], g.user["id"]),
        )
        return render_template("groups.html", rows=rows)

    def my_group_or_404(group_id: int):
        """Группа, в которой состоит текущий пользователь; чужие группы не видны."""
        group = db.query_one(
            """SELECT g.id, g.name, g.invite_code, g.created_by FROM groups g
               JOIN group_members m ON m.group_id = g.id
               WHERE g.id = ? AND m.user_id = ?""",
            (group_id, g.user["id"]),
        )
        if group is None:
            abort(404)
        return group

    def group_payload(group_id: int, period: str) -> dict:
        """Участники группы с временем учёбы и признаком «занимается сейчас»."""
        tz = tz_offset_minutes()
        modifier = f"{tz:+d} minutes"
        # period приходит только из group_period(): today | week | all; в SQL он идёт параметром
        rows = db.query_all(
            """SELECT u.id, u.nickname, u.streak_days, (u.id = gr.created_by) AS leader,
                      COALESCE(SUM(s.duration_min), 0) AS minutes
               FROM group_members m
               JOIN groups gr ON gr.id = m.group_id
               JOIN users u ON u.id = m.user_id
               LEFT JOIN sessions s ON s.user_id = u.id AND s.status = 'completed'
                    AND (? = 'all'
                         OR (? = 'week' AND s.started_at >= ?)
                         OR (? = 'today' AND date(datetime(s.started_at, ?)) = date(datetime('now', ?))))
               WHERE m.group_id = ?
               GROUP BY u.id""",
            (period, period, week_start_utc(tz), period, modifier, modifier, group_id),
        )
        members = [
            {
                "id": r["id"],
                "name": r["nickname"],
                "streak": r["streak_days"],
                "seconds": r["minutes"] * 60,
                "studying": presence.is_studying(r["id"]),
                "you": r["id"] == g.user["id"],
                "leader": bool(r["leader"]),
            }
            for r in rows
        ]
        # сначала те, кто занимается сейчас, затем по времени, затем по имени
        members.sort(key=lambda m: (not m["studying"], -m["seconds"], m["name"].lower()))
        return {
            "period": period,
            "hot_streak": HOT_STREAK_DAYS,
            "studying": sum(1 for m in members if m["studying"]),
            "members": members,
        }

    def group_period() -> str:
        value = request.args.get("period")
        return value if value in ("week", "all") else "today"

    @app.get("/groups/<int:group_id>")
    @login_required
    def group_detail(group_id):
        group = my_group_or_404(group_id)
        period = group_period()
        is_leader = group["created_by"] == g.user["id"]
        manage_members = db.query_all(
            """SELECT u.id, u.nickname FROM group_members m JOIN users u ON u.id = m.user_id
               WHERE m.group_id = ? ORDER BY u.nickname COLLATE NOCASE, u.id""",
            (group_id,),
        ) if is_leader else []
        return render_template(
            "group.html", group=group, period=period, payload=group_payload(group_id, period),
            is_leader=is_leader, manage_members=manage_members,
            invite_link=url_for("join_link", code=group["invite_code"], _external=True),
        )

    @app.get("/groups/<int:group_id>/live")
    @login_required
    def group_live(group_id):
        my_group_or_404(group_id)
        response = jsonify(group_payload(group_id, group_period()))
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.post("/presence")
    @login_required
    def set_presence():
        if request.form.get("state") == "on":
            presence.beat(g.user["id"])
        else:
            presence.stop(g.user["id"])
        return "", 204

    # ------------------------------------------------------- задания (R7)
    @app.get("/todo")
    @login_required
    def todo():
        """Задания пользователя по сроку сдачи; выполненные — внизу."""
        today = (datetime.now(timezone.utc) + timedelta(minutes=tz_offset_minutes())).date()
        rows = db.query_all(
            """SELECT a.id, a.title, a.deadline, a.status, sub.name AS subject
               FROM assignments a LEFT JOIN subjects sub ON sub.id = a.subject_id
               WHERE a.user_id = ?
               ORDER BY (a.status = 'done'), a.deadline, a.id""",
            (g.user["id"],),
        )
        items = []
        for r in rows:
            try:
                days = (datetime.strptime(r["deadline"], "%Y-%m-%d").date() - today).days
            except ValueError:  # дату вручную испортили в БД — не роняем страницу
                days = None
            items.append({
                "id": r["id"], "title": r["title"], "deadline": r["deadline"], "status": r["status"],
                "subject": r["subject"], "due": due_label(days),
                "overdue": days is not None and days < 0 and r["status"] != "done",
            })
        subjects = db.query_all("SELECT id, name FROM subjects ORDER BY name")
        open_count = sum(1 for i in items if i["status"] != "done")
        return render_template("todo.html", items=items, subjects=subjects, today=today.isoformat(),
                               open_count=open_count)

    @app.post("/todo")
    @login_required
    def add_assignment():
        title = " ".join((request.form.get("title") or "").split())
        deadline = security.parse_iso_date(request.form.get("deadline"))
        raw_subject = (request.form.get("subject_id") or "").strip()
        subject_id = None
        error = None
        if not security.valid_assignment_title(title):
            error = f"Title: 1 to {security.ASSIGNMENT_TITLE_MAX} characters"
        elif deadline is None:
            error = "Choose a valid deadline date"
        elif raw_subject:
            subject_id = security.parse_int(raw_subject, 1, 2**31)
            if subject_id is None or db.query_one("SELECT 1 FROM subjects WHERE id = ?", (subject_id,)) is None:
                error = "No such subject"
        if error is None and db.query_one(
                "SELECT COUNT(*) AS n FROM assignments WHERE user_id = ?", (g.user["id"],))["n"] >= MAX_ASSIGNMENTS:
            error = f"You can keep up to {MAX_ASSIGNMENTS} assignments; delete some first"
        if error:
            flash(error)
        else:
            db.execute(
                "INSERT INTO assignments (user_id, subject_id, title, deadline) VALUES (?, ?, ?, ?)",
                (g.user["id"], subject_id, title, deadline.isoformat()),
            )
            flash("Assignment added")
        return redirect(url_for("todo"))

    @app.post("/todo/<int:assignment_id>/status")
    @login_required
    def set_assignment_status(assignment_id):
        status = request.form.get("status", "")
        if status not in security.ASSIGNMENT_STATUSES:
            abort(400, "Unknown status")
        # `AND user_id = ?` — чужое задание не меняется и не отличается от несуществующего (R10)
        changed = db.execute(
            "UPDATE assignments SET status = ? WHERE id = ? AND user_id = ?",
            (status, assignment_id, g.user["id"]),
        ).rowcount
        if not changed:
            abort(404)
        return redirect(url_for("todo"))

    @app.post("/todo/<int:assignment_id>/delete")
    @login_required
    def delete_assignment(assignment_id):
        changed = db.execute(
            "DELETE FROM assignments WHERE id = ? AND user_id = ?", (assignment_id, g.user["id"])
        ).rowcount
        if not changed:
            abort(404)
        flash("Assignment deleted")
        return redirect(url_for("todo"))

    @app.get("/settings")
    @login_required
    def settings():
        return render_template("settings.html")

    @app.get("/study-space")
    @login_required
    def study_space():
        return render_template("study_space.html")

    @app.get("/api/study-spaces")
    @login_required
    def study_space_overview():
        response = jsonify(study_spaces.get_overview(
            db.get_db(),
            app.config["STUDY_SPACE_MAX_AGE_SECONDS"],
            app.config["STUDY_SPACE_THRESHOLDS"],
        ))
        response.headers["Cache-Control"] = "no-store"
        return response

    def sensor_token():
        authorization = request.headers.get("Authorization", "")
        scheme, separator, value = authorization.partition(" ")
        if separator and scheme.lower() == "bearer" and value and len(value) <= 256:
            return value
        return None

    def ingest_sensor_reading(category):
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify(ok=False, error="A JSON object is required"), 400
        sensor_id = payload.get("sensor_id")
        room_id = payload.get("room_id")
        assigned_room = study_spaces.authenticate_sensor(db.get_db(), sensor_id, sensor_token())
        if assigned_room is None:
            return jsonify(ok=False, error="Sensor authentication failed"), 401
        if room_id != assigned_room:
            return jsonify(ok=False, error="Sensor is not authorized for this study space"), 403
        try:
            with db.transaction() as con:
                if category == "occupancy":
                    study_spaces.record_occupancy(
                        con, room_id, payload.get("occupancy_count"), sensor_id, payload.get("timestamp"),
                        future_tolerance_seconds=app.config["STUDY_SPACE_FUTURE_TOLERANCE_SECONDS"],
                    )
                else:
                    study_spaces.record_wifi(
                        con, room_id, payload.get("wifi_signal_dbm"), payload.get("download_speed_mbps"),
                        sensor_id, payload.get("timestamp"),
                        future_tolerance_seconds=app.config["STUDY_SPACE_FUTURE_TOLERANCE_SECONDS"],
                    )
        except ValueError as exc:
            return jsonify(ok=False, error=str(exc)), 400
        return jsonify(ok=True), 201

    @app.post("/api/study-spaces/occupancy")
    def study_space_occupancy():
        return ingest_sensor_reading("occupancy")

    @app.post("/api/study-spaces/wifi")
    def study_space_wifi():
        return ingest_sensor_reading("wifi")

    @app.post("/admin/study-spaces/sensors")
    @login_required
    @admin_required
    def create_study_space_sensor():
        payload = request.get_json(silent=True) if request.is_json else request.form
        payload = payload if isinstance(payload, dict) else {}
        sensor_id = payload.get("sensor_id")
        room_id = payload.get("room_id")
        token = secrets.token_urlsafe(32)
        try:
            with db.transaction() as con:
                study_spaces.register_sensor(
                    con, sensor_id, room_id, hashlib.sha256(token.encode("utf-8")).hexdigest()
                )
        except ValueError as exc:
            return jsonify(ok=False, error=str(exc)), 400
        except sqlite3.IntegrityError:
            return jsonify(ok=False, error="That sensor_id is already registered"), 409
        return jsonify(ok=True, sensor_id=sensor_id, room_id=room_id, token=token), 201

    @app.post("/admin/study-spaces/sensors/<sensor_id>/enabled")
    @login_required
    @admin_required
    def set_study_space_sensor_enabled(sensor_id):
        payload = request.get_json(silent=True) if request.is_json else request.form
        payload = payload if isinstance(payload, dict) else {}
        enabled = payload.get("enabled")
        if not (enabled is True or enabled is False or enabled == "true" or enabled == "false"
                or type(enabled) is int and enabled in (0, 1)):
            return jsonify(ok=False, error="enabled must be true or false"), 400
        enabled = int(enabled is True or enabled == "true" or enabled == 1)
        changed = db.execute(
            "UPDATE study_sensors SET enabled = ? WHERE sensor_id = ?", (enabled, sensor_id)
        ).rowcount
        if not changed:
            return jsonify(ok=False, error="Sensor not found"), 404
        return jsonify(ok=True, sensor_id=sensor_id, enabled=bool(enabled))

    @app.post("/admin/study-spaces/locations/<room_id>")
    @login_required
    @admin_required
    def update_study_space_capacity(room_id):
        payload = request.get_json(silent=True) if request.is_json else request.form
        payload = payload if isinstance(payload, dict) else {}
        capacity = security.parse_int(payload.get("capacity"), 1, 100000)
        if capacity is None:
            return jsonify(ok=False, error="capacity must be a positive integer"), 400
        latest = db.query_one(
            """SELECT occupancy_count FROM occupancy_readings
               WHERE room_id = ? ORDER BY observed_at DESC, id DESC LIMIT 1""",
            (room_id,),
        )
        if latest is not None and latest["occupancy_count"] > capacity:
            return jsonify(ok=False, error="capacity cannot be lower than the latest occupancy reading"), 400
        changed = db.execute(
            "UPDATE study_spaces SET capacity = ? WHERE id = ?", (capacity, room_id)
        ).rowcount
        if not changed:
            return jsonify(ok=False, error="Study space not found"), 404
        return jsonify(ok=True, room_id=room_id, capacity=capacity)

    # ------------------------------------------------------------ админ-раздел
    @app.get("/admin/stats")
    @admin_required
    def admin_stats():
        """Те же три запроса, что в отчёте (Part C), читаются из БД при каждом открытии."""
        return render_template("admin_stats.html", stats=analytics.get_stats(db.get_db()))

    @app.get("/admin/users")
    @admin_required
    def admin_users():
        rows = db.query_all(
            """SELECT u.id, u.email, u.nickname, u.role, u.created_at,
                       EXISTS(SELECT 1 FROM password_resets r WHERE r.user_id = u.id
                              AND r.used_at IS NULL AND r.token_hash IS NULL) AS reset_requested,
                       EXISTS(SELECT 1 FROM password_resets r WHERE r.user_id = u.id
                              AND r.used_at IS NULL AND r.token_hash IS NOT NULL
                              AND r.expires_at > datetime('now')) AS reset_issued
                FROM users u ORDER BY u.id"""
        )
        admins = [r for r in rows if r["role"] == "admin"]
        students = [r for r in rows if r["role"] != "admin"]
        return render_template("admin_users.html", admins=admins, students=students,
                               reset_link=session.pop("reset_link", None))

    @app.post("/admin/users")
    @admin_required
    def admin_create_admin():
        """Отдельный админ-аккаунт: создаётся сразу с ролью admin."""
        email = security.normalize_email(request.form.get("email"))
        nickname = (request.form.get("nickname") or "").strip()
        password = request.form.get("password") or ""
        error = signup_error(email, nickname, password) or create_user(email, nickname, password, "admin")
        flash(error or f"Admin account created for {email}")
        return redirect(url_for("admin_users"))

    @app.post("/admin/users/<int:user_id>/role")
    @admin_required
    def admin_set_role(user_id):
        """Назначить или снять роль администратора."""
        role = request.form.get("role", "")
        if role not in security.ROLES:
            abort(400, "Unknown role")
        if user_id == g.user["id"]:
            flash("You cannot change your own role")  # защита от потери доступа
            return redirect(url_for("admin_users"))
        with db.transaction() as con:
            target = con.execute("SELECT nickname, role FROM users WHERE id = ?", (user_id,)).fetchone()
            if target is None:
                abort(404)
            if target["role"] == role:
                message = f"{target['nickname']} is already {'an admin' if role == 'admin' else 'a student'}"
            elif role == "student" and con.execute(
                    "SELECT COUNT(*) FROM users WHERE role = 'admin'").fetchone()[0] <= 1:
                message = "The last administrator cannot be removed"
            else:
                con.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
                message = (f"{target['nickname']} is now an admin" if role == "admin"
                           else f"{target['nickname']} is now a student")
        flash(message)
        return redirect(url_for("admin_users"))

    @app.post("/admin/users/<int:user_id>/reset-link")
    @admin_required
    def admin_reset_link(user_id):
        """Выдать одноразовую ссылку сброса пароля (действует 24 часа); токен показывается один раз."""
        user = db.query_one("SELECT id, nickname FROM users WHERE id = ?", (user_id,))
        if user is None:
            abort(404)
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        with db.transaction() as con:
            open_row = con.execute(
                f"SELECT id FROM password_resets WHERE user_id = ? AND {open_reset_sql()} ORDER BY id DESC LIMIT 1",
                (user_id,),
            ).fetchone()
            if open_row:  # новая ссылка заменяет прежнюю
                con.execute("UPDATE password_resets SET token_hash = ?, expires_at = datetime('now', '+24 hours') "
                            "WHERE id = ?", (token_hash, open_row["id"]))
            else:
                con.execute("INSERT INTO password_resets (user_id, token_hash, expires_at) "
                            "VALUES (?, ?, datetime('now', '+24 hours'))", (user_id, token_hash))
        session["reset_link"] = {"nickname": user["nickname"],
                                 "url": url_for("reset_password", token=token, _external=True)}
        return redirect(url_for("admin_users"))

    # ------------------------------------------- создание групп и коды приглашения (R2)
    def find_group_by_code(code: str):
        """Группа по коду приглашения (регистр не важен) или None."""
        if not security.valid_invite_code(code):
            return None
        return db.query_one("SELECT id, name FROM groups WHERE invite_code = ?", (code,))

    def leader_group_or_error(group_id: int):
        """Группа, которую текущий пользователь создал; участник-не-лидер получает 403, посторонний — 404."""
        group = my_group_or_404(group_id)
        if group["created_by"] != g.user["id"]:
            abort(403)
        return group

    @app.post("/groups")
    @login_required
    def create_group():
        name = " ".join((request.form.get("name") or "").split())  # лишние пробелы → один
        if not security.valid_group_name(name):
            flash(f"Group name: {security.GROUP_NAME_HINT}")
            return redirect(url_for("groups"))
        created = db.query_one("SELECT COUNT(*) AS n FROM groups WHERE created_by = ?", (g.user["id"],))["n"]
        if created >= MAX_GROUPS_CREATED:
            flash(f"You can create up to {MAX_GROUPS_CREATED} groups")
            return redirect(url_for("groups"))
        with db.transaction() as con:  # группа и первый участник (создатель) — одной транзакцией
            for _ in range(5):  # UNIQUE на invite_code: при совпадении (почти невозможном) берём новый код
                code = security.generate_invite_code()
                try:
                    cur = con.execute(
                        "INSERT INTO groups (name, invite_code, created_by) VALUES (?, ?, ?)",
                        (name, code, g.user["id"]),
                    )
                    break
                except sqlite3.IntegrityError:
                    continue
            else:
                abort(500)
            group_id = cur.lastrowid
            con.execute("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)", (group_id, g.user["id"]))
        flash(f"Group “{name}” created. Share the invite code {code} or the invite link.")
        return redirect(url_for("group_detail", group_id=group_id))

    @app.post("/groups/join")
    @login_required
    def join_group():
        if join_throttle.blocked(g.user["id"]):
            flash("Too many wrong invite codes. Please try again in a few minutes.")
            return redirect(url_for("groups"))
        code = (request.form.get("invite_code") or "").strip().upper()
        group = find_group_by_code(code)
        if group is None:
            join_throttle.fail(g.user["id"])
            flash("Invalid invite code")
            return redirect(url_for("groups"))
        cur = db.execute(
            "INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)",
            (group["id"], g.user["id"]),
        )
        flash(f"You joined the group “{group['name']}”" if cur.rowcount
              else f"You are already in the group “{group['name']}”")
        return redirect(url_for("group_detail", group_id=group["id"]))

    @app.get("/join/<code>")
    def join_link(code):
        """Ссылка-приглашение: показывает группу и кнопку «Join». Само вступление — POST /groups/join."""
        code = code.strip().upper()
        if g.user is None:
            flash("Log in to join the group")
            return redirect(url_for("login", next=f"/join/{code}") if security.safe_next(f"/join/{code}")
                            else url_for("login"))
        if join_throttle.blocked(g.user["id"]):
            flash("Too many wrong invite codes. Please try again in a few minutes.")
            return redirect(url_for("groups"))
        group = find_group_by_code(code)
        if group is None:
            join_throttle.fail(g.user["id"])
            return render_template("join.html", group=None), 404
        if db.query_one("SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?",
                        (group["id"], g.user["id"])):
            flash(f"You are already in the group “{group['name']}”")
            return redirect(url_for("group_detail", group_id=group["id"]))
        members = db.query_one("SELECT COUNT(*) AS n FROM group_members WHERE group_id = ?", (group["id"],))["n"]
        return render_template("join.html", group=group, code=code, members=members)

    @app.post("/groups/<int:group_id>/regenerate-code")
    @login_required
    def regenerate_invite_code(group_id):
        """Лидер выпускает новый код; старый код и старая ссылка перестают работать."""
        group = leader_group_or_error(group_id)
        for _ in range(5):
            code = security.generate_invite_code()
            try:
                db.execute("UPDATE groups SET invite_code = ? WHERE id = ?", (code, group["id"]))
                break
            except sqlite3.IntegrityError:
                continue
        else:
            abort(500)
        flash(f"New invite code: {code}. The old code and link no longer work.")
        return redirect(url_for("group_detail", group_id=group["id"]))

    @app.post("/groups/<int:group_id>/members/<int:user_id>/remove")
    @login_required
    def remove_group_member(group_id, user_id):
        group = leader_group_or_error(group_id)
        if user_id == g.user["id"]:
            flash("You are the leader of this group. Delete the group instead of removing yourself.")
        else:
            member = db.query_one(
                """SELECT u.nickname FROM group_members m JOIN users u ON u.id = m.user_id
                   WHERE m.group_id = ? AND m.user_id = ?""",
                (group["id"], user_id),
            )
            if member is None:
                abort(404)
            db.execute("DELETE FROM group_members WHERE group_id = ? AND user_id = ?", (group["id"], user_id))
            flash(f"{member['nickname']} was removed from the group")
        return redirect(url_for("group_detail", group_id=group["id"]))

    @app.post("/groups/<int:group_id>/leave")
    @login_required
    def leave_group(group_id):
        group = my_group_or_404(group_id)
        if group["created_by"] == g.user["id"]:
            flash("You created this group, so you can’t leave it. Delete it instead.")
            return redirect(url_for("group_detail", group_id=group["id"]))
        db.execute("DELETE FROM group_members WHERE group_id = ? AND user_id = ?", (group["id"], g.user["id"]))
        flash(f"You left the group “{group['name']}”")
        return redirect(url_for("groups"))

    @app.post("/groups/<int:group_id>/delete")
    @login_required
    def delete_group(group_id):
        group = leader_group_or_error(group_id)
        db.execute("DELETE FROM groups WHERE id = ?", (group["id"],))  # group_members удаляются каскадом
        flash(f"Group “{group['name']}” was deleted")
        return redirect(url_for("groups"))

    return app


def _lan_ip() -> str | None:
    """IP компьютера в локальной сети (чтобы показать адрес для телефона/ноута)."""
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("10.255.255.255", 1))  # пакеты не отправляются, нужен только выбор интерфейса
        return sock.getsockname()[0]
    except OSError:
        return None
    finally:
        sock.close()


if __name__ == "__main__":
    # По умолчанию слушаем все интерфейсы (0.0.0.0), чтобы заходить с других устройств
    # в локальной сети. Только свой компьютер: HOST=127.0.0.1 python app.py
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "5000"))
    if host == "0.0.0.0":
        ip = _lan_ip()
        print(f"\n  On this computer:    http://127.0.0.1:{port}")
        if ip:
            print(f"  From other devices:  http://{ip}:{port}\n")
    # debug=False: интерактивный отладчик Werkzeug нельзя выставлять наружу
    create_app().run(host=host, port=port, debug=False)
