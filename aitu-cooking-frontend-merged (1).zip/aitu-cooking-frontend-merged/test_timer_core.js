// Юнит-тесты timer-core.js на поддельных часах.  Запуск:  node --test test_timer_core.js
const test = require('node:test');
const assert = require('node:assert/strict');
const AituTimer = require('./static/js/timer-core.js');

function memoryStorage(initial = {}) {
  const data = { ...initial };
  return { getItem: k => (k in data ? data[k] : null), setItem: (k, v) => { data[k] = String(v); }, data };
}

// Часы и таймеры, которыми управляет тест
function harness(opts = {}) {
  let t = 1_000_000;
  const timeouts = new Map();
  let nextHandle = 1, created = 0;
  const saves = [];
  const storage = opts.storage || memoryStorage();
  const timer = AituTimer.create({
    userId: 1, storage,
    now: () => t,
    setTimeout: (fn, ms) => { created++; timeouts.set(nextHandle, { fn, at: t + ms }); return nextHandle++; },
    clearTimeout: h => timeouts.delete(h),
    saveSession: opts.saveSession || (async (id, minutes) => { saves.push([id, minutes]); return true; }),
  });
  const events = [];
  timer.on((type, d) => events.push(type));
  return {
    timer, storage, saves, events,
    now: () => t,
    advance(ms) {                       // двигаем часы и срабатывают таймеры в порядке времени
      const end = t + ms;
      for (;;) {
        const due = [...timeouts.entries()].filter(([, v]) => v.at <= end).sort((a, b) => a[1].at - b[1].at)[0];
        if (!due) break;
        t = due[1].at; timeouts.delete(due[0]); due[1].fn();
      }
      t = end;
    },
    pending: () => timeouts.size,
    created: () => created,
  };
}
const S = (id, name = 'S' + id) => ({ id, name });

test('formatSeconds → H:MM:SS', () => {
  const f = AituTimer.formatSeconds;
  assert.equal(f(0), '0:00:00');
  assert.equal(f(5), '0:00:05');
  assert.equal(f(65), '0:01:05');
  assert.equal(f(3600), '1:00:00');
  assert.equal(f(11045), '3:04:05');
  assert.equal(f(-3), '0:00:00');
});

test('start → running, ticks once per second, pause stops accumulation', async () => {
  const h = harness();
  await h.timer.start(S(1));
  assert.equal(h.timer.isRunning(), true);
  h.advance(5000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 5);
  assert.equal(h.events.filter(e => e === 'tick').length, 5);
  await h.timer.pause();
  assert.equal(h.timer.isRunning(), false);
  assert.equal(h.pending(), 0);
  h.advance(60000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 5);   // на паузе не растёт
});

test('resume continues accumulated time instead of resetting', async () => {
  const h = harness();
  await h.timer.start(S(1)); h.advance(10_000); await h.timer.pause();
  h.advance(5000);
  await h.timer.start(S(1)); h.advance(7000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 17);
});

test('only one ticker exists, even after repeated start/pause/switch', async () => {
  const h = harness();
  assert.equal(h.timer.tickerCount(), 0);
  for (let i = 0; i < 20; i++) {
    await h.timer.start(S(1)); assert.equal(h.pending(), 1);
    await h.timer.start(S(1)); assert.equal(h.pending(), 1);   // повторный старт того же — без дубликата
    await h.timer.start(S(2)); assert.equal(h.pending(), 1);   // переключение — по-прежнему один
    await h.timer.pause();     assert.equal(h.pending(), 0);
  }
  assert.equal(h.timer.tickerCount(), 0);
});

test('subjects accumulate independently and switching banks the previous one', async () => {
  const h = harness();
  await h.timer.start(S(1)); h.advance(30_000);
  await h.timer.start(S(2)); h.advance(12_000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 30);
  assert.equal(Math.floor(h.timer.unsavedMs(2) / 1000), 12);
  assert.equal(h.timer.runningInfo().id, '2');
  h.advance(1000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 30);   // первый не растёт
});

test('ticks stay aligned: exactly 60 ticks in 60 s, no drift', async () => {
  const h = harness();
  await h.timer.start(S(1));
  h.advance(60_000);
  assert.equal(h.events.filter(e => e === 'tick').length, 60);
  assert.equal(h.timer.unsavedMs(1), 60_000);
});

test('pause saves whole minutes only and keeps the remainder', async () => {
  const h = harness();
  await h.timer.start(S(3)); h.advance(150_000);   // 2:30
  await h.timer.pause();
  assert.deepEqual(h.saves, [['3', 2]]);
  assert.equal(Math.floor(h.timer.unsavedMs(3) / 1000), 30);  // остаток 30 с остался
  await h.timer.start(S(3)); h.advance(40_000);
  await h.timer.pause();                                      // 30+40 = 70 с → ещё минута
  assert.deepEqual(h.saves, [['3', 2], ['3', 1]]);
  assert.equal(Math.floor(h.timer.unsavedMs(3) / 1000), 10);
});

test('under one minute is never sent', async () => {
  const h = harness();
  await h.timer.start(S(1)); h.advance(59_000); await h.timer.pause();
  assert.deepEqual(h.saves, []);
});

test('switching subject saves the previous subject, not the new one', async () => {
  const h = harness();
  await h.timer.start(S(1)); h.advance(61_000);
  await h.timer.start(S(2));
  assert.deepEqual(h.saves, [['1', 1]]);
});

test('checkpoint saves while the timer keeps running (autosave)', async () => {
  const h = harness();
  await h.timer.start(S(1)); h.advance(5 * 60_000 + 20_000);
  await h.timer.checkpoint(1);
  assert.deepEqual(h.saves, [['1', 5]]);
  assert.equal(h.timer.isRunning(), true);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 20);
  h.advance(10_000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 30);
});

test('a failed save returns the minutes and nothing is lost or double counted', async () => {
  let ok = false; const attempts = [];
  const h = harness({ saveSession: async (id, m) => { attempts.push(m); return ok; } });
  await h.timer.start(S(1)); h.advance(120_000);
  const res = await h.timer.pause();
  assert.equal(res.error, true);
  assert.ok(h.events.includes('error'));
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 120);  // всё на месте
  ok = true;
  await h.timer.flushAll();
  assert.deepEqual(attempts, [2, 2]);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 0);
  await h.timer.flushAll();
  assert.deepEqual(attempts, [2, 2]);                          // повторной отправки нет
});

test('a rejected save promise is treated as failure', async () => {
  const h = harness({ saveSession: async () => { throw new Error('network'); } });
  await h.timer.start(S(1)); h.advance(60_000);
  const res = await h.timer.pause();
  assert.equal(res.error, true);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 60);
});

test('time does not dip on screen while a save is in flight', async () => {
  let release; const gate = new Promise(r => { release = r; });
  const h = harness({ saveSession: () => gate.then(() => true) });
  await h.timer.start(S(1)); h.advance(120_000);
  const p = h.timer.pause();
  await Promise.resolve();
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 120);  // ещё «в пути», но видно
  release(); await p;
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 0);    // подтверждено: в «unsaved» ничего
});

test('saves are sequential, never parallel', async () => {
  let active = 0, maxActive = 0;
  const h = harness({ saveSession: async () => { active++; maxActive = Math.max(maxActive, active); await new Promise(r => setImmediate(r)); active--; return true; } });
  await h.timer.start(S(1)); h.advance(60_000);
  await h.timer.start(S(2)); h.advance(60_000);
  await h.timer.start(S(3)); h.advance(60_000);
  await h.timer.pause();
  assert.equal(maxActive, 1);
});

test('state survives a page reload (new instance, same storage)', async () => {
  const h = harness();
  await h.timer.start(S(1, 'Calculus')); h.advance(90_000);
  // «переход на другую страницу»: новый экземпляр читает тот же storage
  let t = h.now() + 30_000;
  const t2 = AituTimer.create({ userId: 1, storage: h.storage, now: () => t, saveSession: async () => true,
    setTimeout: () => 1, clearTimeout: () => {} });
  assert.equal(t2.isRunning(), true);
  assert.deepEqual(t2.runningInfo(), { id: '1', name: 'Calculus', since: 1_000_000 });
  assert.equal(Math.floor(t2.unsavedMs(1) / 1000), 120);       // 90 + 30 с, пока страницы не было
});

test('state is per user', async () => {
  const storage = memoryStorage();
  const a = AituTimer.create({ userId: 1, storage, now: Date.now, saveSession: async () => true });
  const b = AituTimer.create({ userId: 2, storage, now: Date.now, saveSession: async () => true });
  await a.start(S(1));
  assert.equal(b.isRunning(), false);
  await a.pause();
});

test('corrupt or hostile storage is ignored', () => {
  for (const raw of ['not json', '{"running":{"id":"x","startedAt":"y"}}', '{"carry":{"1":-5,"abc":10,"2":"NaN"}}', 'null', '[]']) {
    const storage = memoryStorage({ 'aitu.timer.v1.1': raw });
    const t = AituTimer.create({ userId: 1, storage, now: Date.now, saveSession: async () => true });
    assert.equal(t.isRunning(), false, raw);
    assert.equal(t.totalUnsavedMs(), 0, raw);
  }
});

test('a timer forgotten for >12h is capped at 12h', () => {
  const start = 1_000_000;
  const storage = memoryStorage({ 'aitu.timer.v1.1': JSON.stringify({ running: { id: '1', name: 'X', startedAt: start }, carry: {} }) });
  const t = AituTimer.create({ userId: 1, storage, now: () => start + 30 * 3600_000, saveSession: async () => true });
  assert.equal(t.isRunning(), false);
  assert.equal(t.unsavedMs(1), AituTimer.STALE_MS);
  assert.equal(t.wasCapped(), true);
  assert.equal(t.wasCapped(), false);
});

test('a single save never exceeds 720 minutes', async () => {
  const storage = memoryStorage({ 'aitu.timer.v1.1': JSON.stringify({ running: null, carry: { 1: 800 * 60_000 } }) });
  const saves = [];
  const t = AituTimer.create({ userId: 1, storage, now: Date.now, saveSession: async (id, m) => { saves.push(m); return true; } });
  await t.flushAll();
  assert.deepEqual(saves, [720]);
  await t.flushAll();
  assert.deepEqual(saves, [720, 80]);
});

test('discard drops unsaved time and restarts the running segment', async () => {
  const h = harness();
  await h.timer.start(S(1)); h.advance(45_000);
  h.timer.discard(1);
  assert.equal(h.timer.unsavedMs(1), 0);
  assert.equal(h.timer.isRunning(), true);
  h.advance(3000);
  assert.equal(Math.floor(h.timer.unsavedMs(1) / 1000), 3);
});

test('works without localStorage (in-memory only)', async () => {
  const saves = [];
  const t = AituTimer.create({ userId: 1, storage: null, now: (() => { let n = 0; return () => (n += 1000); })(), saveSession: async (i, m) => { saves.push(m); return true; },
    setTimeout: () => 1, clearTimeout: () => {} });
  await t.start(S(1));
  assert.equal(t.isRunning(), true);
  await t.pause();
  assert.equal(t.isRunning(), false);
});

test('listener errors do not break the timer; unsubscribe works', async () => {
  const h = harness();
  const origError = console.error; console.error = () => {};
  h.timer.on(() => { throw new Error('boom'); });
  let calls = 0; const off = h.timer.on(() => { calls++; });
  await h.timer.start(S(1));
  assert.ok(calls > 0);
  off(); const seen = calls; h.advance(3000);
  assert.equal(calls, seen);
  assert.equal(h.timer.isRunning(), true);
  console.error = origError;
});

test('since marks the start of a continuous run and survives checkpoints', async () => {
  const h = harness();
  await h.timer.start(S(1));
  const since = h.timer.runningInfo().since;
  h.advance(5 * 60_000 + 1000);
  await h.timer.checkpoint(1);
  assert.equal(h.timer.runningInfo().since, since);
});
