from datetime import datetime, timedelta, timezone

from test_app import Base


class StudySpaceTests(Base):
    def setUp(self):
        super().setUp()
        self.login()

    def api_post(self, url, payload, token=None):
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        return self.client.post(url, json=payload, headers=headers)

    def register_sensor(self, sensor_id="test-sensor", room_id="room-301"):
        response = self.post(
            "/admin/study-spaces/sensors",
            {"sensor_id": sensor_id, "room_id": room_id},
            "/dashboard",
        )
        return response, response.get_json()

    def admin_login(self):
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        self.login("240103@astanait.edu.kz", "aa1234bb")

    def test_page_and_aggregate_api_require_login_and_render_all_locations(self):
        page = self.client.get("/study-space")
        self.assertEqual(page.status_code, 200)
        self.assertIn("Smart Study Space", page.get_data(as_text=True))
        self.assertRegex(page.get_data(as_text=True), r'class="dock-item active" href="/study-space"')
        data = self.client.get("/api/study-spaces").get_json()
        self.assertEqual([space["id"] for space in data["spaces"]],
                         ["library", "open-space", "room-301", "room-302", "room-303"])
        self.assertTrue(all(space["occupancy"] is None and space["wifi"] is None for space in data["spaces"]))
        self.assertFalse(data["has_simulated_data"])

    def test_sensor_submission_authentication_validation_and_aggregation(self):
        self.admin_login()
        response, sensor = self.register_sensor()
        self.assertEqual(response.status_code, 201)
        token = sensor["token"]
        now = datetime.now(timezone.utc).isoformat()
        occupancy = {"room_id": "room-301", "occupancy_count": 12, "timestamp": now, "sensor_id": "test-sensor"}
        wifi = {"room_id": "room-301", "wifi_signal_dbm": -55, "download_speed_mbps": 42.4,
                "timestamp": now, "sensor_id": "test-sensor"}

        self.assertEqual(self.api_post("/api/study-spaces/occupancy", occupancy).status_code, 401)
        self.assertEqual(self.api_post("/api/study-spaces/occupancy", occupancy, "wrong-token").status_code, 401)
        self.assertEqual(self.api_post("/api/study-spaces/occupancy", occupancy, token).status_code, 201)
        self.assertEqual(self.api_post("/api/study-spaces/wifi", wifi, token).status_code, 201)

        data = self.client.get("/api/study-spaces").get_json()
        room = next(space for space in data["spaces"] if space["id"] == "room-301")
        self.assertEqual(room["occupancy"]["count"], 12)
        self.assertEqual(room["occupancy"]["capacity"], 25)
        self.assertEqual(room["occupancy"]["percent"], 48)
        self.assertEqual(room["occupancy"]["status"], "Moderate")
        self.assertEqual(room["wifi"]["signal_dbm"], -55)
        self.assertEqual(room["wifi"]["download_speed_mbps"], 42.4)
        self.assertEqual(room["wifi"]["status"], "Good")
        self.assertFalse(room["occupancy"]["stale"])

    def test_invalid_sensor_data_and_room_scope_are_rejected(self):
        self.admin_login()
        response, sensor = self.register_sensor()
        self.assertEqual(response.status_code, 201)
        token = sensor["token"]
        base = {"room_id": "room-301", "sensor_id": "test-sensor",
                "timestamp": datetime.now(timezone.utc).isoformat()}
        for count, timestamp in ((-1, base["timestamp"]), (26, base["timestamp"]),
                                 (1, "not-a-date"), (1, "2024-01-01T10:00:00")):
            payload = dict(base, occupancy_count=count, timestamp=timestamp)
            self.assertEqual(self.api_post("/api/study-spaces/occupancy", payload, token).status_code, 400)
        wrong_room = dict(base, room_id="library", occupancy_count=1)
        self.assertEqual(self.api_post("/api/study-spaces/occupancy", wrong_room, token).status_code, 403)
        bad_wifi = dict(base, wifi_signal_dbm=-130, download_speed_mbps=1)
        self.assertEqual(self.api_post("/api/study-spaces/wifi", bad_wifi, token).status_code, 400)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM occupancy_readings")[0][0], 0)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM wifi_readings")[0][0], 0)

    def test_admin_controls_and_sensor_revocation(self):
        response, _ = self.register_sensor()
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.post("/admin/study-spaces/locations/room-301", {"capacity": "35"}).status_code, 403)

        self.admin_login()
        response, sensor = self.register_sensor()
        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.post(
            "/admin/study-spaces/locations/room-301", {"capacity": "35"}, "/dashboard"
        ).status_code, 200)

        disabled = self.post(
            "/admin/study-spaces/sensors/test-sensor/enabled",
            {"enabled": "false"},
            "/dashboard",
        )
        self.assertEqual(disabled.status_code, 200)
        payload = {"room_id": "room-301", "occupancy_count": 2, "sensor_id": "test-sensor",
                   "timestamp": datetime.now(timezone.utc).isoformat()}
        self.assertEqual(self.api_post("/api/study-spaces/occupancy", payload, sensor["token"]).status_code, 401)

    def test_stale_readings_are_marked_unavailable(self):
        self.admin_login()
        response, sensor = self.register_sensor()
        self.assertEqual(response.status_code, 201)
        timestamp = (datetime.now(timezone.utc) - timedelta(minutes=10)).isoformat()
        payload = {"room_id": "room-301", "occupancy_count": 5, "sensor_id": "test-sensor", "timestamp": timestamp}
        self.assertEqual(self.api_post("/api/study-spaces/occupancy", payload, sensor["token"]).status_code, 201)
        with self.app.app_context():
            self.app.config["STUDY_SPACE_MAX_AGE_SECONDS"] = 60
        room = next(space for space in self.client.get("/api/study-spaces").get_json()["spaces"]
                    if space["id"] == "room-301")
        self.assertTrue(room["occupancy"]["stale"])
        self.assertEqual(room["occupancy"]["status"], "Data unavailable")

    def test_simulation_source_is_explicit_and_separate(self):
        with self.app.app_context():
            import db
            import study_spaces
            timestamp = datetime.now(timezone.utc).isoformat()
            with db.transaction() as con:
                study_spaces.record_occupancy(con, "library", 10, "simulation", timestamp, source="simulated")
        data = self.client.get("/api/study-spaces").get_json()
        library = next(space for space in data["spaces"] if space["id"] == "library")
        self.assertEqual(library["occupancy"]["source"], "simulated")
        self.assertTrue(data["has_simulated_data"])


if __name__ == "__main__":
    import unittest
    unittest.main(verbosity=2)
