"""Кто сейчас занимается — только в памяти процесса, БД не затрагивается.

Клиент, пока у него идёт таймер, раз в ~20 секунд шлёт POST /presence (state=on).
Пользователь считается «занимающимся», если последний сигнал был не позже TTL секунд назад.
При паузе клиент шлёт state=off. После перезапуска сервера состояние пустое — это нормально:
таймеры в открытых вкладках отправят сигнал снова.

Ограничение: словарь живёт в одном процессе. При запуске в несколько воркеров
(gunicorn -w N) нужно заменить это хранилище на общее (Redis и т.п.).
"""
import threading
import time

TTL_SECONDS = 45

_lock = threading.Lock()
_last_seen: dict[int, float] = {}


def beat(user_id: int) -> None:
    with _lock:
        _last_seen[user_id] = time.monotonic()


def stop(user_id: int) -> None:
    with _lock:
        _last_seen.pop(user_id, None)


def is_studying(user_id: int) -> bool:
    with _lock:
        seen = _last_seen.get(user_id)
        if seen is None:
            return False
        if time.monotonic() - seen > TTL_SECONDS:
            del _last_seen[user_id]
            return False
        return True
