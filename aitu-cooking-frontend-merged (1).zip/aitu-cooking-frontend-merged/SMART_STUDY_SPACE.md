# Smart Study Space

The feature uses the application's existing Flask + SQLite database. On startup,
`create_app()` creates the feature tables with `IF NOT EXISTS` and inserts the
default spaces only when their IDs are absent. Existing capacities are not
overwritten. The page and aggregate API require a signed-in account; only room
counts and Wi-Fi measurements are returned to ordinary users.

## Configuration

Optional environment settings:

| Variable | Default | Purpose |
| --- | --- | --- |
| `STUDY_SPACE_LOCATIONS` | Built-in five locations | JSON array of initial location objects (`id`, `name`, `location_type`, `capacity`) |
| `STUDY_SPACE_MAX_AGE_SECONDS` | `300` | Age after which a reading is unavailable (30–86400) |
| `STUDY_SPACE_FUTURE_TOLERANCE_SECONDS` | `300` | Allowed sensor clock skew into the future (0–3600) |
| `STUDY_SPACE_OCCUPANCY_MODERATE_PERCENT` | `40` | Upper bound of Low occupancy |
| `STUDY_SPACE_OCCUPANCY_HIGH_PERCENT` | `70` | Upper bound of Moderate occupancy |
| `STUDY_SPACE_WIFI_EXCELLENT_DBM` | `-50` | Minimum signal for Excellent |
| `STUDY_SPACE_WIFI_GOOD_DBM` | `-60` | Minimum signal for Good |
| `STUDY_SPACE_WIFI_AVERAGE_DBM` | `-75` | Minimum signal for Average |

Location IDs must be lowercase letters, numbers, and hyphens; types are
`library`, `open_space`, or `classroom`. Example:

```sh
export STUDY_SPACE_LOCATIONS='[{"id":"library","name":"Library","location_type":"library","capacity":60}]'
```

Default location definitions are used only to seed missing IDs. Admins can
change a capacity with `POST /admin/study-spaces/locations/<room_id>` and the
form field `capacity`. Admins can also register a sensor by posting
`sensor_id` and `room_id` to `POST /admin/study-spaces/sensors`. Both endpoints
require an authenticated admin session and the app's CSRF token. The sensor
registration response contains a newly generated bearer token once; store it
securely on the device. `POST /admin/study-spaces/sensors/<sensor_id>/enabled`
with `enabled=false` revokes a sensor.

## Sensor API

Use HTTPS in production. Send JSON and the sensor's bearer token in the
`Authorization` header. Sensors are assigned to one room, and a request for a
different room is rejected.

`POST /api/study-spaces/occupancy`:

```json
{
  "room_id": "room-301",
  "occupancy_count": 12,
  "timestamp": "2026-11-01T21:30:00Z",
  "sensor_id": "room-301-counter"
}
```

`POST /api/study-spaces/wifi`:

```json
{
  "room_id": "room-301",
  "wifi_signal_dbm": -55,
  "download_speed_mbps": 42.4,
  "timestamp": "2026-11-01T21:30:00Z",
  "sensor_id": "room-301-network-monitor"
}
```

Signal is constrained to -120 through 0 dBm and download speed to 0 through
10000 Mbps. Occupancy must be a non-negative integer no greater than the
configured capacity. Timestamps must be ISO 8601 and include a timezone.
Sensor credentials are stored as SHA-256 hashes and never appear in the
frontend or aggregate API.

`GET /api/study-spaces` returns the latest reading in each category for each
location, status labels, freshness flags, and a simulated-data marker. It does
not return sensor IDs or credentials. The frontend polls every 30 seconds.

## Simulation

No simulation starts with the web application. To write one clearly marked
batch to the configured database:

```sh
python simulate_study_spaces.py --enable-simulation --once
```

To keep generating demo readings, explicitly opt in and set the interval:

```sh
python simulate_study_spaces.py --enable-simulation --interval 30
```

Simulation is refused when `APP_ENV=production`. Simulated records are stored
separately with source `simulated`, tagged in the UI, and never replace sensor
records. The script uses the same validation and storage functions as the
sensor API.
