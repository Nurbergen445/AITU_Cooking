"""Проверки админ-раздела: /admin/stats, назначение админов, сброс пароля, английские сообщения.

Запуск:  python test_admin.py
Работает на временной копии базы (см. Base в test_app.py).
"""
import re
import sqlite3
import unittest

import analytics
import create_admin
import security
from test_app import Base

ADMIN = ("240103@astanait.edu.kz", "aa1234bb")     # id 3, роль admin
STUDENT = ("240101@astanait.edu.kz", "qwertyuiop")  # id 1, роль student


def has_cyrillic(text: str) -> bool:
    return re.search(r"[\u0400-\u04FF]", text) is not None


class AdminBase(Base):
    def login_admin(self):
        self.login(*ADMIN)

    def role_of(self, email):
        return self.rows("SELECT role FROM users WHERE email = ?", (email,))[0][0]

    def flashes(self, url="/admin/users"):
        return " ".join(re.findall(r'class="flash">([^<]*)<', self.client.get(url).get_data(as_text=True)))


class AdminStatsTests(AdminBase):
    def test_access_rules(self):
        self.assertEqual(self.client.get("/admin/stats").status_code, 302)          # гость → /login
        self.assertIn("/login", self.client.get("/admin/stats").headers["Location"])
        self.login(*STUDENT)
        self.assertEqual(self.client.get("/admin/stats").status_code, 403)          # студент → 403
        self.assertEqual(self.client.get("/admin/users").status_code, 403)

    def test_admin_sees_page_with_report_numbers(self):
        self.login_admin()
        r = self.client.get("/admin/stats")
        self.assertEqual(r.status_code, 200)
        html = r.get_data(as_text=True)
        for text in ("Study statistics", "Study time by subject", "Session length", "Activity per account",
                     "Calculus", "ICT", "Physics", "under 30 min", "90+ min", "User #3"):
            self.assertIn(text, html)

    def test_numbers_match_the_three_report_queries(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        stats = analytics.get_stats(con)
        expected_total = con.execute("SELECT COUNT(*) FROM sessions WHERE status = 'completed'").fetchone()[0]
        self.assertEqual(stats["completed_sessions"], expected_total)
        self.assertEqual(sum(b["sessions"] for b in stats["lengths"]), expected_total)
        self.assertEqual(stats["accounts_total"], self.users_before)  # LEFT JOIN: аккаунты без сессий остаются
        self.assertEqual([s["total_min"] for s in stats["subjects"]],
                         sorted((s["total_min"] for s in stats["subjects"]), reverse=True))
        con.close()

    def test_menu_link_only_for_admins(self):
        self.login(*STUDENT)
        self.assertNotIn("Admin statistics", self.client.get("/dashboard").get_data(as_text=True))
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        self.login_admin()
        html = self.client.get("/dashboard").get_data(as_text=True)
        self.assertIn("Admin statistics", html)
        self.assertIn("Users &amp; admins", html)


class AdminAccountTests(AdminBase):
    def test_promote_and_demote(self):
        self.login_admin()
        self.post("/admin/users/1/role", {"role": "admin"}, "/admin/users")
        self.assertEqual(self.role_of(STUDENT[0]), "admin")
        self.post("/admin/users/1/role", {"role": "student"}, "/admin/users")
        self.assertEqual(self.role_of(STUDENT[0]), "student")

    def test_new_admin_gets_access_immediately(self):
        self.login_admin()
        self.post("/admin/users/1/role", {"role": "admin"}, "/admin/users")
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        self.login(*STUDENT)
        self.assertEqual(self.client.get("/admin/stats").status_code, 200)

    def test_student_cannot_assign_roles(self):
        self.login(*STUDENT)
        r = self.post("/admin/users/1/role", {"role": "admin"}, "/dashboard")
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.role_of(STUDENT[0]), "student")
        r = self.post("/admin/users", {"email": "x@astanait.edu.kz", "nickname": "Evil", "password": "longenough1"}, "/dashboard")
        self.assertEqual(r.status_code, 403)

    def test_role_change_requires_csrf_and_valid_role(self):
        self.login_admin()
        self.assertEqual(self.client.post("/admin/users/1/role", data={"role": "admin"}).status_code, 400)
        self.assertEqual(self.post("/admin/users/1/role", {"role": "superuser"}, "/admin/users").status_code, 400)
        self.assertEqual(self.post("/admin/users/999/role", {"role": "admin"}, "/admin/users").status_code, 404)
        self.assertEqual(self.role_of(STUDENT[0]), "student")

    def test_cannot_change_own_role_or_remove_last_admin(self):
        self.login_admin()
        self.post("/admin/users/3/role", {"role": "student"}, "/admin/users")
        self.assertEqual(self.role_of(ADMIN[0]), "admin")
        self.assertIn("cannot change your own role", self.flashes())
        # второй админ снимает первого, пока остаётся ещё один — можно; последнего — нельзя
        self.post("/admin/users/1/role", {"role": "admin"}, "/admin/users")
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        self.login(*STUDENT)
        self.post("/admin/users/3/role", {"role": "student"}, "/admin/users")
        self.assertEqual(self.role_of(ADMIN[0]), "student")
        self.post("/admin/users/3/role", {"role": "admin"}, "/admin/users")  # вернуть
        self.assertEqual(self.role_of(ADMIN[0]), "admin")

    def test_last_admin_guard_in_cli_and_web(self):
        con = sqlite3.connect(self.path)
        self.assertIn("last administrator", create_admin.set_role(con, ADMIN[0], "student"))
        self.assertEqual(self.role_of(ADMIN[0]), "admin")
        con.close()

    def test_create_separate_admin_account(self):
        self.login_admin()
        email = "admin.two@astanait.edu.kz"
        self.post("/admin/users", {"email": email, "nickname": "Admin Two", "password": "longenough1"}, "/admin/users")
        self.assertEqual(self.role_of(email), "admin")
        stored = self.rows("SELECT password FROM users WHERE email = ?", (email,))[0][0]
        self.assertTrue(stored.startswith("pbkdf2_sha256$200000$"))
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        self.assertEqual(self.login(email, "longenough1").status_code, 302)
        self.assertEqual(self.client.get("/admin/stats").status_code, 200)

    def test_create_admin_validation(self):
        self.login_admin()
        for data in ({"email": "a@gmail.com", "nickname": "Okay", "password": "longenough1"},
                     {"email": "ok1@astanait.edu.kz", "nickname": "x", "password": "longenough1"},
                     {"email": "ok2@astanait.edu.kz", "nickname": "Okay", "password": "short"},
                     {"email": STUDENT[0], "nickname": "Dup", "password": "longenough1"}):
            self.post("/admin/users", data, "/admin/users")
        self.assertEqual(self.rows("SELECT COUNT(*) FROM users")[0][0], self.users_before)
        self.assertEqual(self.role_of(STUDENT[0]), "student")

    def test_registration_never_creates_admins(self):
        self.post("/register", {"email": "250001@astanait.edu.kz", "nickname": "Newbie", "password": "longenough1",
                                "role": "admin"}, "/register")
        self.assertEqual(self.role_of("250001@astanait.edu.kz"), "student")

    def test_users_page_separates_admins_and_students(self):
        self.login_admin()
        html = self.client.get("/admin/users").get_data(as_text=True)
        self.assertLess(html.index("Admin accounts"), html.index("Student accounts"))
        self.assertNotIn("pbkdf2", html)

    def test_cli_create_and_promote(self):
        con = sqlite3.connect(self.path)
        self.assertIn("created", create_admin.create_admin(con, "cli.admin@astanait.edu.kz", "Cli Admin", "longenough1"))
        self.assertIn("already exists", create_admin.create_admin(con, "cli.admin@astanait.edu.kz", "Cli Admin", "longenough1"))
        self.assertIn("now has", create_admin.set_role(con, STUDENT[0], "admin"))
        con.close()
        self.assertEqual(self.role_of("cli.admin@astanait.edu.kz"), "admin")
        self.assertEqual(self.role_of(STUDENT[0]), "admin")


class PasswordResetTests(AdminBase):
    def request_reset(self, email=STUDENT[0]):
        return self.post("/forgot-password", {"email": email}, "/forgot-password")

    def issue_link(self, user_id=1):
        self.login_admin()
        self.post(f"/admin/users/{user_id}/reset-link", {}, "/admin/users")
        html = self.client.get("/admin/users").get_data(as_text=True)
        url = re.search(r'value="http://localhost(/reset/[^"]+)"', html).group(1)
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        return url

    def test_login_page_links_to_forgot_password(self):
        self.assertIn("/forgot-password", self.client.get("/login").get_data(as_text=True))
        self.assertEqual(self.client.get("/forgot-password").status_code, 200)

    def test_request_is_the_same_for_known_and_unknown_email(self):
        known = self.request_reset(STUDENT[0])
        unknown = self.request_reset("nobody@astanait.edu.kz")
        self.assertEqual((known.status_code, known.headers["Location"]), (unknown.status_code, unknown.headers["Location"]))
        self.assertEqual(self.rows("SELECT COUNT(*) FROM password_resets")[0][0], 1)
        self.request_reset(STUDENT[0])  # повтор не создаёт второй открытый запрос
        self.assertEqual(self.rows("SELECT COUNT(*) FROM password_resets")[0][0], 1)

    def test_admin_sees_request_and_full_flow(self):
        self.request_reset()
        self.login_admin()
        self.assertIn("reset requested", self.client.get("/admin/users").get_data(as_text=True))
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        url = self.issue_link()

        page = self.client.get(url)
        self.assertEqual(page.status_code, 200)
        self.assertEqual(page.headers["Referrer-Policy"], "no-referrer")
        self.post(url, {"password": "brand-new-pass", "confirm": "brand-new-pass"}, url)
        self.assertEqual(self.login(STUDENT[0], "brand-new-pass").status_code, 302)
        self.assertEqual(self.client.get("/dashboard").status_code, 200)
        self.client.post("/logout", data={"csrf_token": self.token("/dashboard")})
        self.login(*STUDENT)  # старый пароль больше не подходит
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

        # ссылка одноразовая
        self.assertEqual(self.client.get(url).status_code, 400)
        stored = self.rows("SELECT token_hash FROM password_resets")[0][0]
        self.assertNotIn(url.rsplit("/", 1)[1], stored)  # в базе только SHA-256, не сам токен

    def test_bad_inputs_do_not_change_password(self):
        url = self.issue_link()
        before = self.rows("SELECT password FROM users WHERE id = 1")[0][0]
        self.post(url, {"password": "short", "confirm": "short"}, url)
        self.post(url, {"password": "long-enough-1", "confirm": "different-2"}, url)
        self.assertEqual(self.rows("SELECT password FROM users WHERE id = 1")[0][0], before)
        self.assertEqual(self.client.get("/reset/not-a-real-token").status_code, 400)

    def test_expired_link_is_refused(self):
        url = self.issue_link()
        con = sqlite3.connect(self.path)
        with con:
            con.execute("UPDATE password_resets SET expires_at = datetime('now', '-1 minute')")
        con.close()
        self.assertEqual(self.client.get(url).status_code, 400)

    def test_new_link_replaces_old_one(self):
        first = self.issue_link()
        second = self.issue_link()
        self.assertNotEqual(first, second)
        self.assertEqual(self.client.get(first).status_code, 400)
        self.assertEqual(self.client.get(second).status_code, 200)

    def test_student_cannot_issue_links(self):
        self.login(*STUDENT)
        self.assertEqual(self.post("/admin/users/3/reset-link", {}, "/dashboard").status_code, 403)
        self.assertEqual(self.rows("SELECT COUNT(*) FROM password_resets")[0][0], 0)


class UsabilityFixTests(AdminBase):
    """Три проблемы из Part B2."""

    def test_server_messages_are_english(self):
        def shown(resp):  # ошибки входа и регистрации показываются прямо в ответе на POST
            return " ".join(re.findall(r'class="flash">([^<]*)<', resp.get_data(as_text=True)))

        self.assertIn("Wrong e-mail or password", shown(self.login(password="nope-nope")))
        reg = lambda **kw: shown(self.post("/register", dict({"email": "250002@astanait.edu.kz", "nickname": "Nick",
                                                             "password": "longenough1"}, **kw), "/register"))
        self.assertIn("university e-mail", reg(email="a@gmail.com"))
        self.assertIn("Nickname: " + security.NICKNAME_HINT, reg(nickname="x"))
        self.assertIn("Password: 8 to 128 characters", reg(password="short"))
        self.assertIn("already exists", reg(email=STUDENT[0], nickname="Dup"))

        self.login(*STUDENT)
        # здесь после POST идёт redirect, поэтому сообщение читаем со следующей страницы
        self.post("/sessions", {"subject_id": "1", "duration_min": "30"}, "/dashboard")
        self.assertIn("Session saved", self.flashes("/profile"))
        self.post("/sessions", {"subject_id": "999", "duration_min": "30"}, "/dashboard")
        self.assertIn("No such subject", self.flashes("/profile"))
        self.post("/groups/join", {"invite_code": "NOPE1234"}, "/groups")
        self.assertIn("Invalid invite code", self.flashes("/groups"))
        self.post("/groups/join", {"invite_code": "ict2026"}, "/groups")
        # админ уже состоит в этой группе: с версии с создателем групп сообщение другое, но тоже английское
        self.assertIn("You are already in the group", self.flashes("/groups"))

        r = self.client.post("/login", data={"email": "x", "password": "y"})  # без CSRF-токена
        self.assertEqual(r.status_code, 400)
        self.assertIn("Invalid CSRF token", r.get_data(as_text=True))

    def test_no_cyrillic_on_any_page(self):
        pages = ["/login", "/register", "/forgot-password", "/reset/bad"]
        for url in pages:
            self.assertFalse(has_cyrillic(self.client.get(url).get_data(as_text=True)), url)
        self.login_admin()
        for url in ("/dashboard", "/profile", "/leaderboard", "/groups", "/study-space", "/todo",
                    "/settings", "/subjects", "/admin/stats", "/admin/users"):
            self.assertFalse(has_cyrillic(self.client.get(url).get_data(as_text=True)), url)

    def test_nickname_rule_is_shown_under_the_field(self):
        html = self.client.get("/register").get_data(as_text=True)
        self.assertIn(security.NICKNAME_HINT, html)
        self.assertIn('aria-describedby="nickname-hint"', html)
        self.assertIn('pattern="[\\p{L}\\p{N}_ .\\-]{2,32}"', html)

    def test_html_pattern_agrees_with_server_rule(self):
        server_ok = ["Nick", "Ab", "a b", "a_b", "a.b", "a-b", "Нурбергеен", "Beknur senpai", "x" * 32]
        server_bad = ["x", "x" * 33, "a;b", "a<b>", "a'b", "a/b", "a$b", ""]
        for value in server_ok:
            self.assertTrue(security.valid_nickname(value), value)
        for value in server_bad:
            self.assertFalse(security.valid_nickname(value), value)
        # то же правило, переписанное для браузера (\p{L}\p{N}); Python-проверка — по эквиваленту
        pattern = re.compile(r"^[A-Za-z\u0400-\u04FF0-9_ .\-]{2,32}$")
        for value in server_ok:
            self.assertTrue(pattern.fullmatch(value), value)
        for value in server_bad:
            self.assertFalse(pattern.fullmatch(value), value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
