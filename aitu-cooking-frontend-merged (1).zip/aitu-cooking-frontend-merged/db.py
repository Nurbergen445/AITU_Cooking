"""Подключение к SQLite для Flask.

Главное правило защиты от SQL-инъекций: SQL — это всегда константная строка,
а все значения от пользователя передаются отдельно, через `?`-плейсхолдеры.
Драйвер sqlite3 никогда не подставляет их в текст запроса, поэтому
`' OR '1'='1` остаётся просто строкой.
"""
import sqlite3
from contextlib import contextmanager

from flask import current_app, g


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        con = sqlite3.connect(current_app.config["DATABASE"])
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")  # в SQLite внешние ключи по умолчанию выключены
        g.db = con
    return g.db


def close_db(_exc=None) -> None:
    con = g.pop("db", None)
    if con is not None:
        con.close()


def _check_params(params) -> None:
    # Строка вместо кортежа — типичная ошибка: ("abc") это str, а не кортеж.
    if not isinstance(params, (tuple, list, dict)):
        raise TypeError("params must be a tuple, list or dict, not " + type(params).__name__)


def query_all(sql: str, params=()):
    _check_params(params)
    return get_db().execute(sql, params).fetchall()


def query_one(sql: str, params=()):
    _check_params(params)
    return get_db().execute(sql, params).fetchone()


def execute(sql: str, params=()):
    _check_params(params)
    con = get_db()
    cur = con.execute(sql, params)
    con.commit()
    return cur


@contextmanager
def transaction():
    """Несколько запросов как одна операция: либо все выполнятся, либо ни один."""
    con = get_db()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise


def ensure_schema(con: sqlite3.Connection) -> None:
    """Таблицы и индексы, добавленные после первой версии базы (CREATE ... IF NOT EXISTS — безопасно повторять).

    password_resets: строка с token_hash IS NULL — это запрос пользователя «забыл пароль»,
    который ждёт администратора; после выдачи ссылки в строке лежит SHA-256 токена
    (сам токен нигде не хранится) и срок действия; used_at ставится после смены пароля.
    """
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS password_resets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            token_hash TEXT UNIQUE,
            requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            expires_at TEXT,
            used_at TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        -- Задания пользователя (R7). Каждая строка принадлежит одному user_id,
        -- все запросы к ней обязаны содержать `AND user_id = ?` (R10).
        CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            subject_id INTEGER,
            title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 120),
            deadline TEXT NOT NULL CHECK (deadline GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
            status TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo', 'doing', 'done')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_assignments_user_deadline ON assignments (user_id, deadline);

        -- «Мои группы» ищет по user_id, а первичный ключ group_members начинается с group_id.
        CREATE INDEX IF NOT EXISTS idx_group_members_user ON group_members (user_id);
        """
    )
    con.commit()
