"""Создать админ-аккаунт или назначить админом существующий (первый админ — отсюда).

Дальше админы назначаются из веб-интерфейса: меню профиля → Users & admins.

Запуск:
    python create_admin.py admin.name@astanait.edu.kz "Admin Name"   # новый аккаунт, пароль спросит
    python create_admin.py --promote 240101@astanait.edu.kz          # сделать админом существующего
    python create_admin.py --demote  240101@astanait.edu.kz          # снять роль (последнего админа снять нельзя)
    python create_admin.py ... --db путь/к/базе.sqlite
"""
import argparse
import getpass
import os
import sqlite3
import sys

import security


def set_role(con: sqlite3.Connection, email: str, role: str) -> str:
    row = con.execute("SELECT id, role FROM users WHERE email = ?", (email,)).fetchone()
    if row is None:
        return f"No account with e-mail {email}"
    if row[1] == role:
        return f"{email} already has the role {role}"
    if role == "student" and con.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'").fetchone()[0] <= 1:
        return "The last administrator cannot be removed"
    with con:
        con.execute("UPDATE users SET role = ? WHERE id = ?", (role, row[0]))
    return f"{email} now has the role {role}"


def create_admin(con: sqlite3.Connection, email: str, nickname: str, password: str) -> str:
    if not security.valid_email(email):
        return "A university e-mail like name@astanait.edu.kz is required"
    if not security.valid_nickname(nickname):
        return f"Nickname: {security.NICKNAME_HINT}"
    if not security.valid_password(password):
        return f"Password: {security.PASSWORD_MIN} to {security.PASSWORD_MAX} characters"
    try:
        with con:
            con.execute("INSERT INTO users (email, password, nickname, role) VALUES (?, ?, ?, 'admin')",
                        (email, security.hash_password(password), nickname))
    except sqlite3.IntegrityError:
        return "An account with this e-mail already exists (use --promote)"
    return f"Admin account created: {email}"


def main(argv=None) -> int:
    default_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), "aitucooking.sqlite")
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("email")
    parser.add_argument("nickname", nargs="?")
    parser.add_argument("--promote", action="store_true", help="give an existing account the admin role")
    parser.add_argument("--demote", action="store_true", help="turn an admin back into a student")
    parser.add_argument("--db", default=default_db)
    args = parser.parse_args(argv)
    email = security.normalize_email(args.email)

    con = sqlite3.connect(args.db)
    con.execute("PRAGMA foreign_keys = ON")
    try:
        if args.promote or args.demote:
            message = set_role(con, email, "admin" if args.promote else "student")
        else:
            if not args.nickname:
                parser.error("a nickname is required to create a new account")
            password = os.environ.get("ADMIN_PASSWORD") or getpass.getpass("Password: ")
            if not os.environ.get("ADMIN_PASSWORD") and getpass.getpass("Repeat password: ") != password:
                print("The passwords do not match")
                return 1
            message = create_admin(con, email, args.nickname.strip(), password)
    finally:
        con.close()
    print(message)
    return 0 if ("created" in message or "now has" in message or "already has" in message) else 1


if __name__ == "__main__":
    sys.exit(main())
