/* app.js — общее для всех страниц: таймер, сохранение сессий, присутствие, меню, уведомления.
 *
 * Единственный экземпляр таймера создаётся здесь и доступен как window.Aitu.timer,
 * поэтому таймер продолжает работать (и автосохраняться), даже если открыта не главная страница.
 */
(function () {
  'use strict';
  if (window.Aitu) return;

  var body = document.body;
  var userId = body.dataset.userId || '';
  var AUTOSAVE_MS = 5 * 60 * 1000;
  var HEARTBEAT_MS = 20 * 1000;

  // ---- часовой пояс для «сегодня» на сервере (см. tz_offset_minutes в app.py)
  try {
    document.cookie = 'tzoff=' + (-new Date().getTimezoneOffset()) + '; path=/; max-age=31536000; SameSite=Lax';
  } catch (e) { /* cookie недоступны */ }

  function csrf() {
    var m = document.querySelector('meta[name="csrf-token"]');
    return m ? m.content : '';
  }

  function icon(name, cls) {
    return '<svg class="ico ' + (cls || '') + '"><use href="#i-' + name + '"/></svg>';
  }

  // ---- уведомления
  function toast(message, kind) {
    var box = document.getElementById('toasts');
    if (!box) return;
    var el = document.createElement('div');
    el.className = 'toast' + (kind ? ' toast-' + kind : '');
    el.textContent = message;
    box.appendChild(el);
    setTimeout(function () { el.classList.add('out'); }, 3800);
    setTimeout(function () { el.remove(); }, 4300);
  }

  var Aitu = { csrf: csrf, icon: icon, toast: toast, sound: window.AituSound, fmt: window.AituTimer.formatSeconds, timer: null };
  window.Aitu = Aitu;

  // ---- выпадающие меню (профиль, строки предметов)
  function closeMenus(except) {
    document.querySelectorAll('[data-menu-toggle][aria-expanded="true"]').forEach(function (btn) {
      if (btn === except) return;
      btn.setAttribute('aria-expanded', 'false');
      var menu = btn.parentElement.querySelector('.menu');
      if (menu) menu.hidden = true;
    });
  }

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-menu-toggle]');
    if (btn) {
      var menu = btn.parentElement.querySelector('.menu');
      var open = btn.getAttribute('aria-expanded') !== 'true';
      closeMenus(btn);
      btn.setAttribute('aria-expanded', String(open));
      if (menu) menu.hidden = !open;
      return;
    }
    if (!e.target.closest('.menu')) closeMenus(null);
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeMenus(null);
  });

  if (!userId) return;  // дальше — только для вошедших пользователей

  // ---- сохранение сессии через существующий POST /sessions
  function saveSession(subjectId, minutes) {
    var form = new URLSearchParams();
    form.set('csrf_token', csrf());
    form.set('subject_id', subjectId);
    form.set('duration_min', minutes);
    return fetch(body.dataset.sessionsUrl, {
      method: 'POST',
      body: form,
      credentials: 'same-origin',
      keepalive: true,
      headers: { 'X-Requested-With': 'fetch', 'Accept': 'application/json' }
    }).then(function (res) {
      var json = (res.headers.get('content-type') || '').indexOf('json') !== -1;
      if (!res.ok || !json) return false;   // редирект на /login и т.п. — не считается успехом
      return res.json().then(function (d) { return d.ok === true; });
    });
  }

  // ---- присутствие («занимается сейчас»)
  function sendPresence(on) {
    var form = new URLSearchParams();
    form.set('csrf_token', csrf());
    form.set('state', on ? 'on' : 'off');
    fetch(body.dataset.presenceUrl, {
      method: 'POST', body: form, credentials: 'same-origin', keepalive: true,
      headers: { 'X-Requested-With': 'fetch' }
    }).catch(function () { /* офлайн — не страшно */ });
  }

  var timer = window.AituTimer.create({ userId: userId, saveSession: saveSession });
  Aitu.timer = timer;

  // ---- мини-индикатор и заголовок вкладки, пока таймер идёт
  var pill = document.getElementById('now-pill');
  var pillName = document.getElementById('now-name');
  var pillTime = document.getElementById('now-time');
  var baseTitle = document.title;
  var onHome = body.dataset.page === 'dashboard';

  function updateChrome() {
    var info = timer.runningInfo();
    if (!info) {
      document.title = baseTitle;
      if (pill) pill.hidden = true;
      return;
    }
    var text = Aitu.fmt(Math.max(0, Date.now() - info.since) / 1000);   // «идёт уже…», не сбрасывается автосохранением
    document.title = '▶ ' + text + ' · ' + baseTitle;
    if (pill) {
      pill.hidden = onHome;
      pillName.textContent = info.name;
      pillTime.textContent = text;
    }
  }

  timer.on(function (type) {
    if (type === 'start') sendPresence(true);
    if (type === 'pause') sendPresence(false);
    updateChrome();
  });

  // автосохранение целых минут, пока таймер идёт; heartbeat раз в 20 секунд
  setInterval(function () {
    var info = timer.runningInfo();
    if (info) timer.checkpoint(info.id);
  }, AUTOSAVE_MS);

  setInterval(function () { if (timer.isRunning()) sendPresence(true); }, HEARTBEAT_MS);

  // изменения из другой вкладки
  window.addEventListener('storage', function (e) {
    if (e.key === timer.storageKey) timer.sync();
  });

  // вернулась сеть — повторить неотправленные минуты
  window.addEventListener('online', function () { timer.flushAll(); });

  // старт страницы: подхватить идущий таймер и дослать то, что не ушло раньше
  timer.resume();
  if (timer.isRunning()) sendPresence(true);
  updateChrome();
  timer.flushAll();
})();
