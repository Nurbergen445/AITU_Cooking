(() => {
  const grid = document.getElementById("study-space-grid");
  if (!grid) return;

  const apiUrl = "/api/study-spaces";
  const refreshLabel = document.getElementById("space-refresh");
  const emptyLabel = document.getElementById("space-empty");
  const errorLabel = document.getElementById("space-error");
  const simulationLabel = document.getElementById("space-simulation");
  let loading = false;
  let hasLoaded = false;

  const element = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  const statusClass = (status) => ({
    Low: "low",
    Moderate: "moderate",
    High: "high",
    Full: "full",
    Excellent: "excellent",
    Good: "good",
    Average: "average",
    Poor: "poor",
  }[status] || "unavailable");

  const updatedTime = (value) => {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "unknown time" : date.toLocaleString();
  };

  function renderMetric(label, reading, kind) {
    const block = element("section", `space-metric ${kind}`);
    block.append(element("h3", "space-metric-title", label));
    if (!reading || reading.stale) {
      block.append(element("p", "space-unavailable", "Data unavailable"));
      if (reading?.last_updated_at) {
        block.append(element("p", "space-updated", `Last reading: ${updatedTime(reading.last_updated_at)}`));
      }
      return block;
    }

    if (kind === "occupancy") {
      const head = element("div", "space-metric-head");
      head.append(
        element("strong", "space-value", `${reading.count} / ${reading.capacity}`),
        element("span", `space-status ${statusClass(reading.status)}`, reading.status),
      );
      block.append(head);
      block.append(element(
        "p",
        "space-detail",
        `${reading.capacity - reading.count} available · ${reading.percent}% occupied`,
      ));
      const progress = element("div", "space-progress");
      progress.setAttribute("role", "progressbar");
      progress.setAttribute("aria-label", `${label}: ${reading.percent}% occupied`);
      progress.setAttribute("aria-valuemin", "0");
      progress.setAttribute("aria-valuemax", "100");
      progress.setAttribute("aria-valuenow", String(reading.percent));
      const fill = element("span", `space-progress-fill ${statusClass(reading.status)}`);
      fill.style.width = `${reading.percent}%`;
      progress.append(fill);
      block.append(progress);
    } else {
      const details = element("div", "space-wifi-details");
      details.append(
        element("span", `space-status ${statusClass(reading.status)}`, reading.status),
        element("span", "space-value", `${reading.signal_dbm} dBm`),
        element("span", "space-value", `${reading.download_speed_mbps} Mbps`),
      );
      block.append(details);
      block.append(element("p", "space-detail", "Signal · Download speed"));
    }
    block.append(element("p", "space-updated", `Updated ${updatedTime(reading.last_updated_at)}`));
    return block;
  }

  function renderSpace(space) {
    const card = element("article", "study-space-card");
    const header = element("header", "space-card-header");
    const type = {
      library: "Library",
      open_space: "Open space",
      classroom: "Classroom",
    }[space.location_type] || "Study space";
    header.append(
      element("div", "space-card-title", space.name),
      element("span", "space-type", type),
    );
    card.append(header);
    card.append(renderMetric("Occupancy", space.occupancy, "occupancy"));
    card.append(renderMetric("Wi-Fi", space.wifi, "wifi"));
    if (space.occupancy?.source === "simulated" || space.wifi?.source === "simulated") {
      card.append(element("span", "space-simulated-badge", "Simulated"));
    }
    return card;
  }

  async function refresh() {
    if (loading) return;
    loading = true;
    if (!hasLoaded) refreshLabel.textContent = "Loading study spaces…";
    try {
      const response = await fetch(apiUrl, {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (!response.ok) throw new Error(`Request failed (${response.status})`);
      const data = await response.json();
      if (!Array.isArray(data.spaces)) throw new Error("The server returned an invalid response");

      const cards = document.createDocumentFragment();
      for (const space of data.spaces) cards.append(renderSpace(space));
      grid.replaceChildren(cards);
      emptyLabel.hidden = data.spaces.length === 0 || data.spaces.some(
        (space) => space.occupancy || space.wifi,
      );
      simulationLabel.hidden = !data.has_simulated_data;
      errorLabel.hidden = true;
      refreshLabel.textContent = data.updated_at
        ? `Last updated ${updatedTime(data.updated_at)}`
        : "Waiting for sensor readings";
      hasLoaded = true;
    } catch (error) {
      errorLabel.textContent = hasLoaded
        ? `Could not refresh data. Displayed readings may be outdated. (${error.message})`
        : `Could not load study spaces. Please try again. (${error.message})`;
      errorLabel.hidden = false;
      refreshLabel.textContent = "Update failed";
      if (!hasLoaded) grid.replaceChildren(element("div", "space-loading", "Study space data could not be loaded."));
    } finally {
      loading = false;
    }
  }

  refresh();
  window.setInterval(refresh, 30000);
})();
