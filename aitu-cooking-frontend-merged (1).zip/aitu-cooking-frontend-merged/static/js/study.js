/* study.js — главный экран: список предметов с play/pause и общий таймер.
 * Вся логика времени — в timer-core.js (window.Aitu.timer); здесь только отображение и клики.
 */
(function () {
  'use strict';
  var A = window.Aitu;
  var list = document.getElementById('subject-list');
  if (!A || !A.timer || !list) return;
  var timer = A.timer;

  // «Сегодня» считает сервер по часовому поясу из cookie. Если cookie только что появилась
  // и сервер посчитал по UTC — один раз перезагружаем страницу уже с правильным поясом.
  try {
    var browserTz = String(-new Date().getTimezoneOffset());
    if (browserTz !== list.dataset.tzUsed && !sessionStorage.getItem('aitu.tzreload')) {
      sessionStorage.setItem('aitu.tzreload', '1');
      location.reload();
      return;
    }
  } catch (e) { /* sessionStorage недоступен — остаёмся с тем, что есть */ }

  var rows = Array.prototype.map.call(list.querySelectorAll('.subject-row'), function (el) {
    return {
      el: el,
      id: el.dataset.subjectId,
      name: el.dataset.subjectName,
      saved: Number(el.dataset.todaySec) || 0,       // секунды, уже записанные на сервере
      timeEl: el.querySelector('.row-time'),
      btn: el.querySelector('.play-btn'),
      shown: null,
      running: null
    };
  });
  var byId = {};
  rows.forEach(function (r) { byId[r.id] = r; });

  var totalEl = document.getElementById('total-timer');
  var captionEl = document.getElementById('timer-caption');
  var shownTotal = null;

  function render() {
    var info = timer.runningInfo();
    var total = 0;
    rows.forEach(function (r) {
      var seconds = r.saved + Math.floor(timer.unsavedMs(r.id) / 1000);
      total += seconds;
      if (seconds !== r.shown) {
        r.shown = seconds;
        r.timeEl.textContent = A.fmt(seconds);
        r.timeEl.dataset.zero = seconds === 0 ? 'true' : 'false';
      }
      var isRunning = !!info && info.id === r.id;
      if (isRunning !== r.running) {
        r.running = isRunning;
        r.el.classList.toggle('is-running', isRunning);
        r.btn.setAttribute('aria-pressed', String(isRunning));
        r.btn.setAttribute('aria-label', (isRunning ? 'Pause timer: ' : 'Start timer: ') + r.name);
      }
    });
    if (total !== shownTotal) {
      shownTotal = total;
      totalEl.textContent = A.fmt(total);
    }
    captionEl.textContent = info ? 'Studying: ' + info.name : 'Today';
    captionEl.classList.toggle('is-live', !!info);
  }

  timer.on(function (type, detail) {
    if (type === 'saved' && byId[detail.id]) {
      byId[detail.id].saved += detail.minutes * 60;
      A.toast('Saved ' + detail.minutes + ' min · ' + byId[detail.id].name);
    }
    if (type === 'error') {
      A.toast('Couldn’t save ' + detail.minutes + ' min — will retry automatically', 'error');
    }
    render();
  });

  // ---- клики: play/pause и меню строки
  list.addEventListener('click', function (e) {
    var btn = e.target.closest('.play-btn');
    if (btn) {
      var row = byId[btn.closest('.subject-row').dataset.subjectId];
      var info = timer.runningInfo();
      if (info && info.id === row.id) {
        timer.pause();
      } else {
        A.sound.playStart();                 // прямо из клика — так звук не блокируется
        timer.start({ id: row.id, name: row.name });
      }
      return;
    }

    var action = e.target.closest('[data-action]');
    if (!action) return;
    var target = byId[action.closest('.subject-row').dataset.subjectId];
    var menuBtn = action.closest('.row-menu').querySelector('[data-menu-toggle]');
    menuBtn.click();                         // закрыть меню

    if (action.dataset.action === 'save') {
      timer.checkpoint(target.id).then(function (res) {
        if (!res.saved && !res.error) A.toast('Less than a minute so far — nothing to save yet');
      });
    } else if (action.dataset.action === 'discard') {
      var seconds = Math.floor(timer.unsavedMs(target.id) / 1000);
      if (seconds === 0) { A.toast('No unsaved time for ' + target.name); return; }
      if (window.confirm('Discard ' + A.fmt(seconds) + ' of unsaved time for "' + target.name + '"?')) {
        timer.discard(target.id);
      }
    }
  });

  if (timer.wasCapped()) {
    A.toast('A timer was left running for over 12 hours — only 12 hours were counted', 'error');
  }

  render();
})();
