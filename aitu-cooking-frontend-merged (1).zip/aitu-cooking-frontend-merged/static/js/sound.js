/* sound.js — тихий сигнал при старте таймера (Web Audio API, без файлов и библиотек).
 *
 * playStart() нужно вызывать прямо из обработчика клика — тогда браузер разрешает звук.
 * Если звук недоступен или заблокирован, ничего не происходит, таймер работает как обычно.
 */
(function (root) {
  'use strict';

  var KEY = 'aitu.sound';
  var PEAK_GAIN = 0.1;   // тихо: ~ −20 dBFS
  var ctx = null;

  function isEnabled() {
    try { return localStorage.getItem(KEY) !== 'off'; } catch (e) { return true; }
  }

  function setEnabled(on) {
    try { localStorage.setItem(KEY, on ? 'on' : 'off'); } catch (e) { /* ignore */ }
  }

  function context() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  function tone(c, when, freq, duration) {
    var osc = c.createOscillator();
    var gain = c.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(PEAK_GAIN, when + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(when);
    osc.stop(when + duration + 0.03);
  }

  // Два коротких восходящих тона (~0.25 с).
  function playStart(force) {
    if (!force && !isEnabled()) return false;
    try {
      var c = context();
      if (!c) return false;
      if (c.state === 'suspended' && c.resume) c.resume().catch(function () { /* заблокировано */ });
      var t = c.currentTime + 0.01;
      tone(c, t, 659.25, 0.1);        // E5
      tone(c, t + 0.09, 880, 0.16);   // A5
      return true;
    } catch (e) {
      return false;
    }
  }

  root.AituSound = { playStart: playStart, isEnabled: isEnabled, setEnabled: setEnabled };
})(typeof self !== 'undefined' ? self : this);
