/* timer-core.js — логика учебных таймеров. Здесь нет DOM: только время, хранилище и сохранение.
 *
 * Модель
 *   • Одновременно идёт не более одного таймера (running = {id, name, startedAt}).
 *   • Время считается по меткам Date.now(), а не по числу «тиков», поэтому оно не «плывёт»
 *     в фоновых вкладках и переживает переходы между страницами (состояние лежит в localStorage).
 *   • carry[id] — накопленные, но ещё не отправленные на сервер миллисекунды предмета.
 *   • Сервер хранит целые минуты (sessions.duration_min >= 1), поэтому при паузе/переключении/автосохранении
 *     отправляются только целые минуты, а остаток секунд остаётся в carry до следующего раза.
 *   • Один setTimeout на секундную границу: дубликаты тикеров невозможны (см. tickerCount()).
 *
 * Использование:  const t = AituTimer.create({ userId, saveSession });
 *   saveSession(subjectId, minutes) → Promise<boolean> (true — сервер записал сессию).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AituTimer = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MINUTE = 60000;
  var MAX_SAVE_MIN = 720;                 // как CHECK в таблице sessions
  var STALE_MS = 12 * 60 * 60 * 1000;     // «забытый» таймер: считаем не больше 12 часов подряд

  function formatSeconds(total) {
    total = Math.max(0, Math.floor(total || 0));
    var h = Math.floor(total / 3600);
    var m = Math.floor((total % 3600) / 60);
    var s = total % 60;
    return h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  function create(opts) {
    var now = opts.now || Date.now;
    var store = opts.storage === undefined ? safeLocalStorage() : opts.storage;
    var saveSession = opts.saveSession;
    var setT = opts.setTimeout || function (fn, ms) { return setTimeout(fn, ms); };
    var clearT = opts.clearTimeout || function (h) { clearTimeout(h); };
    var key = 'aitu.timer.v1.' + opts.userId;

    var listeners = [];
    var inflight = {};          // миллисекунды, отправленные, но ещё не подтверждённые (только в памяти)
    var tickHandle = null;
    var queue = Promise.resolve();
    var capped = false;
    var state = { running: null, carry: {} };
    reload();

    // ---------------------------------------------------------------- хранилище
    function safeLocalStorage() {
      try { return typeof localStorage !== 'undefined' ? localStorage : null; } catch (e) { return null; }
    }

    function reload() {
      if (!store) return;                          // без localStorage состояние живёт только в памяти страницы
      var s = { running: null, carry: {} };
      try {
        var raw = store && store.getItem(key);
        var p = raw ? JSON.parse(raw) : null;
        if (p && typeof p === 'object') {
          if (p.carry && typeof p.carry === 'object') {
            Object.keys(p.carry).forEach(function (id) {
              var v = Number(p.carry[id]);
              if (/^\d+$/.test(id) && isFinite(v) && v > 0) s.carry[id] = Math.floor(v);
            });
          }
          var r = p.running;
          if (r && /^\d+$/.test(String(r.id)) && isFinite(Number(r.startedAt))) {
            s.running = { id: String(r.id), name: String(r.name || '').slice(0, 80), startedAt: Number(r.startedAt),
                          since: isFinite(Number(r.since)) ? Number(r.since) : Number(r.startedAt) };
          }
        }
      } catch (e) { /* повреждённое значение — начинаем с чистого состояния */ }
      state = s;

      if (state.running) {
        var elapsed = now() - state.running.startedAt;
        if (elapsed < 0) {                       // часы переведены назад
          state.running.startedAt = now();
        } else if (elapsed > STALE_MS) {         // таймер «забыли» — засчитываем максимум 12 часов
          state.carry[state.running.id] = (state.carry[state.running.id] || 0) + STALE_MS;
          state.running = null;
          capped = true;
          persist();
        }
      }
    }

    function persist() {
      try { if (store) store.setItem(key, JSON.stringify(state)); } catch (e) { /* хранилище недоступно */ }
    }

    // ---------------------------------------------------------------- время
    function segMs() {
      var r = state.running;
      return r ? Math.max(0, Math.min(now() - r.startedAt, STALE_MS)) : 0;
    }

    function unsavedMs(id) {
      id = String(id);
      var r = state.running;
      return (state.carry[id] || 0) + (inflight[id] || 0) + (r && r.id === id ? segMs() : 0);
    }

    function totalUnsavedMs() {
      var total = segMs();
      Object.keys(state.carry).forEach(function (id) { total += state.carry[id]; });
      Object.keys(inflight).forEach(function (id) { total += inflight[id]; });
      return total;
    }

    // ---------------------------------------------------------------- события и тикер
    function emit(type, detail) {
      listeners.slice().forEach(function (fn) {
        try { fn(type, detail || {}); } catch (e) { if (typeof console !== 'undefined') console.error(e); }
      });
    }

    function schedule() {
      if (tickHandle !== null) { clearT(tickHandle); tickHandle = null; }
      if (!state.running) return;
      var delay = 1000 - (segMs() % 1000);
      tickHandle = setT(function () {
        tickHandle = null;
        emit('tick');
        schedule();
      }, delay);
    }

    // ---------------------------------------------------------------- действия
    function bank() {                                   // перенести текущий отрезок в carry
      var r = state.running;
      if (!r) return;
      state.carry[r.id] = (state.carry[r.id] || 0) + segMs();
      state.running = null;
    }

    function start(subject) {
      reload();
      var id = String(subject.id);
      if (state.running && state.running.id === id) return Promise.resolve({ saved: 0 });
      var previous = null;
      if (state.running) { previous = state.running.id; bank(); }
      state.running = { id: id, name: String(subject.name || '').slice(0, 80), startedAt: now(), since: now() };  // since — начало непрерывного запуска (для мини-индикатора)
      persist();
      schedule();
      emit('start', { id: id });
      return previous !== null ? flush(previous) : Promise.resolve({ saved: 0 });
    }

    function pause() {
      reload();
      if (!state.running) return Promise.resolve({ saved: 0 });
      var id = state.running.id;
      bank();
      persist();
      schedule();
      emit('pause', { id: id });
      return flush(id);
    }

    function toggle(subject) {
      return state.running && state.running.id === String(subject.id) ? pause() : start(subject);
    }

    // Зафиксировать накопленное, не останавливая таймер (автосохранение и «Save now»).
    function checkpoint(id) {
      reload();
      id = String(id);
      if (state.running && state.running.id === id) {
        state.carry[id] = (state.carry[id] || 0) + segMs();
        state.running.startedAt = now();
        persist();
      }
      return flush(id);
    }

    function discard(id) {
      reload();
      id = String(id);
      delete state.carry[id];
      if (state.running && state.running.id === id) state.running.startedAt = now();
      persist();
      emit('change');
    }

    function flush(id) {                                // отправки идут строго по очереди
      id = String(id);
      queue = queue.then(function () { return doFlush(id); });
      return queue;
    }

    function flushAll() {
      reload();
      return Promise.all(Object.keys(state.carry).map(flush));
    }

    function doFlush(id) {
      reload();
      var have = state.carry[id] || 0;
      var minutes = Math.min(MAX_SAVE_MIN, Math.floor(have / MINUTE));
      if (minutes < 1) return { saved: 0 };

      var chunk = minutes * MINUTE;
      state.carry[id] = have - chunk;
      if (state.carry[id] <= 0) delete state.carry[id];
      inflight[id] = (inflight[id] || 0) + chunk;      // пока ждём сервер, время не «пропадает» с экрана
      persist();
      emit('change');

      return Promise.resolve()
        .then(function () { return saveSession(id, minutes); })
        .then(function (ok) { return ok === true; }, function () { return false; })
        .then(function (ok) {
          inflight[id] -= chunk;
          if (inflight[id] <= 0) delete inflight[id];
          if (!ok) {                                   // не получилось — возвращаем минуты, повторим позже
            reload();
            state.carry[id] = (state.carry[id] || 0) + chunk;
            persist();
            emit('error', { id: id, minutes: minutes });
            return { saved: 0, error: true };
          }
          emit('saved', { id: id, minutes: minutes });
          return { saved: minutes };
        });
    }

    // ---------------------------------------------------------------- публичный API
    return {
      start: start,
      pause: pause,
      toggle: toggle,
      checkpoint: checkpoint,
      flush: flush,
      flushAll: flushAll,
      discard: discard,
      unsavedMs: unsavedMs,
      totalUnsavedMs: totalUnsavedMs,
      isRunning: function () { return !!state.running; },
      runningInfo: function () { return state.running ? { id: state.running.id, name: state.running.name, since: state.running.since } : null; },
      wasCapped: function () { var c = capped; capped = false; return c; },
      tickerCount: function () { return tickHandle === null ? 0 : 1; },
      storageKey: key,
      // подхватить изменения, сделанные в другой вкладке
      sync: function () { reload(); schedule(); emit('change'); },
      // подписка; возвращает функцию отписки
      on: function (fn) {
        listeners.push(fn);
        return function () { listeners = listeners.filter(function (f) { return f !== fn; }); };
      },
      // запуск тикера после восстановления состояния
      resume: function () { schedule(); }
    };
  }

  return { create: create, formatSeconds: formatSeconds, MAX_SAVE_MIN: MAX_SAVE_MIN, STALE_MS: STALE_MS };
});
