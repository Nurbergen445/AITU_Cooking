/* groups.js — экран группы: сетка участников и панель лидеров.
 * Данные приходят от сервера (встроены в страницу и обновляются через /groups/<id>/live).
 * Свою плитку и порядок лидеров пересчитываем локально каждую секунду, пока идёт собственный таймер.
 */
(function () {
  'use strict';
  var A = window.Aitu;
  var screen = document.querySelector('.group-screen');
  if (!A || !screen) return;

  var POLL_MS = 15000;
  var PALETTE = ['#8250ff', '#2f8f4f', '#3b82d6', '#d6603b', '#c13b8f', '#2aa6a6'];
  var grid = document.getElementById('member-grid');
  var leaders = document.getElementById('leader-list');
  var line = document.getElementById('studying-line');
  var status = document.getElementById('live-status');
  var data = JSON.parse(document.getElementById('group-data').textContent);

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function svg(name, cls) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('class', 'ico ' + (cls || ''));
    s.setAttribute('aria-hidden', 'true');
    var u = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    u.setAttribute('href', '#i-' + name);
    s.appendChild(u);
    return s;
  }

  function initials(name) {
    var parts = name.trim().split(/\s+/);
    var text = parts.length > 1 ? parts[0][0] + parts[1][0] : name.trim().slice(0, 2);
    return text.toUpperCase();
  }

  // Участники с учётом локального таймера: для себя берём «live»-значения.
  function view() {
    var running = A.timer.isRunning();
    var extra = Math.floor(A.timer.totalUnsavedMs() / 1000);
    var members = data.members.map(function (m) {
      return {
        id: m.id, name: m.name, streak: m.streak, you: m.you, leader: m.leader,
        seconds: m.seconds + (m.you ? extra : 0),
        studying: m.you ? running : m.studying
      };
    });
    members.sort(function (a, b) {
      if (a.studying !== b.studying) return a.studying ? -1 : 1;
      if (a.seconds !== b.seconds) return b.seconds - a.seconds;
      return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1;
    });
    return members;
  }

  function render() {
    var members = view();
    var n = members.filter(function (m) { return m.studying; }).length;

    line.textContent = '';
    if (n === 0) {
      line.textContent = 'Nobody is studying right now';
    } else {
      line.appendChild(el('span', 'accent', n + (n === 1 ? ' member' : ' members')));
      line.appendChild(document.createTextNode(n === 1 ? ' is studying' : ' are studying'));
    }

    grid.textContent = '';
    members.forEach(function (m) {
      var li = el('li', 'member' + (m.studying ? ' is-studying' : ''));
      var av = el('div', 'member-avatar');
      av.appendChild(svg('monitor'));
      if (m.streak >= data.hot_streak) {
        var flame = el('span', 'flame');
        flame.title = m.streak + '-day streak';
        flame.appendChild(svg('flame'));
        av.appendChild(flame);
      }
      li.appendChild(av);
      li.appendChild(el('div', 'member-name', m.name + (m.you ? ' (you)' : '')));
      li.appendChild(el('div', 'member-time', A.fmt(m.seconds)));
      if (m.leader) li.appendChild(el('div', 'member-role', 'Leader'));
      grid.appendChild(li);
    });

    leaders.textContent = '';
    members.slice().sort(function (a, b) { return b.seconds - a.seconds || (a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1); })
      .slice(0, 5).forEach(function (m, i) {
        var li = el('li', 'leader');
        var av = el('div', 'avatar avatar-md', initials(m.name));
        av.style.background = PALETTE[m.id % PALETTE.length];
        if (i === 0 && m.seconds > 0) {
          var crown = el('span', 'crown');
          crown.appendChild(svg('crown'));
          av.appendChild(crown);
        }
        li.appendChild(av);
        var text = el('div', 'leader-text');
        text.appendChild(el('div', 'leader-time', A.fmt(m.seconds)));
        text.appendChild(el('div', 'leader-name', m.name));
        li.appendChild(text);
        leaders.appendChild(li);
      });
  }

  function refresh() {
    var url = screen.dataset.liveUrl + '?period=' + encodeURIComponent(screen.dataset.period);
    return fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
      .then(function (res) {
        if (!res.ok || (res.headers.get('content-type') || '').indexOf('json') === -1) throw new Error('bad response');
        return res.json();
      })
      .then(function (json) {
        data = json;
        status.textContent = 'Live status updates every 15 seconds.';
        status.classList.remove('is-error');
        render();
      })
      .catch(function () {
        status.textContent = 'Can’t reach the server — showing the last known data, retrying…';
        status.classList.add('is-error');
      });
  }

  // копирование (Clipboard API → запасной вариант через textarea → показать текст)
  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;opacity:0;top:0';
    document.body.appendChild(ta); ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    ta.remove();
    return ok;
  }
  // кнопки «код» и «ссылка» копируют то, что лежит в data-copy
  Array.prototype.forEach.call(document.querySelectorAll('[data-copy]'), function (btn) {
    btn.addEventListener('click', function () {
      var text = btn.dataset.copy;
      var ok = function () { A.toast(btn.dataset.copied || 'Copied'); };
      var fallback = function () {
        if (legacyCopy(text)) ok(); else A.toast('Couldn\u2019t copy automatically \u2014 it is ' + text, 'error');
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok, fallback);
      else fallback();
    });
  });

  // поле со ссылкой выделяется целиком по клику — удобно скопировать вручную
  var linkField = document.querySelector('.invite-link');
  if (linkField) linkField.addEventListener('focus', function () { linkField.select(); });

  A.timer.on(function (type, detail) {
    if (type === 'saved') {   // минуты ушли на сервер: переносим их из «несохранённых» в данные страницы
      data.members.forEach(function (m) { if (m.you) m.seconds += detail.minutes * 60; });
    }
    if (type === 'tick' || type === 'start' || type === 'pause' || type === 'saved' || type === 'change') render();
  });
  setInterval(refresh, POLL_MS);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });

  render();
  if (A.timer.isRunning()) refresh();   // подтвердить своё присутствие на сервере
})();
