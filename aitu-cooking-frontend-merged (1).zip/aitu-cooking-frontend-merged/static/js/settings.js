/* settings.js — переключатель звука старта таймера (хранится в localStorage этого браузера). */
(function () {
  'use strict';
  var toggle = document.getElementById('sound-toggle');
  var test = document.getElementById('sound-test');
  var sound = window.AituSound;
  if (!toggle || !sound) return;

  toggle.checked = sound.isEnabled();
  toggle.addEventListener('change', function () {
    sound.setEnabled(toggle.checked);
    if (toggle.checked) sound.playStart(true);   // это клик пользователя, поэтому звук разрешён
  });
  test.addEventListener('click', function () {
    if (!sound.playStart(true)) window.Aitu.toast('Audio is not available in this browser', 'error');
  });
})();
