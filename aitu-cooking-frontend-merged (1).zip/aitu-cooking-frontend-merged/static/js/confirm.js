/* confirm.js — подтверждение для опасных форм: <form data-confirm="Текст вопроса">.
 * Без JavaScript форма просто отправится (сервер всё равно проверяет права), поэтому это удобство, а не защита.
 */
(function () {
  'use strict';
  document.addEventListener('submit', function (e) {
    var message = e.target && e.target.getAttribute && e.target.getAttribute('data-confirm');
    if (message && !window.confirm(message)) e.preventDefault();
  });
})();
