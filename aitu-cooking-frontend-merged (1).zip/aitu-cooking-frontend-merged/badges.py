"""Значки (R6). Не хранятся в базе: считаются из данных, которые уже есть (XP, серия, сессии).

Так значок нельзя «выдать» отдельным запросом, и он всегда совпадает с реальными цифрами.
"""

# (id, название, условие для подсказки, функция-проверка от словаря stats)
BADGES = (
    ("first-session", "First step", "Finish your first study session", lambda s: s["sessions"] >= 1),
    ("one-hour", "One hour", "Study 60 minutes in total", lambda s: s["total_min"] >= 60),
    ("ten-hours", "Ten hours", "Study 600 minutes in total", lambda s: s["total_min"] >= 600),
    ("deep-focus", "Deep focus", "Finish one session of 90+ minutes", lambda s: s["longest_min"] >= 90),
    ("streak-3", "3-day streak", "Reach a 3-day streak", lambda s: s["streak_days"] >= 3),
    ("streak-7", "Week streak", "Reach a 7-day streak", lambda s: s["streak_days"] >= 7),
    ("xp-100", "100 XP", "Earn 100 XP", lambda s: s["total_xp"] >= 100),
    ("xp-500", "500 XP", "Earn 500 XP", lambda s: s["total_xp"] >= 500),
    ("team-player", "Team player", "Join or create a study group", lambda s: s["groups"] >= 1),
)


def compute_badges(stats: dict) -> list[dict]:
    """stats: sessions, total_min, longest_min, streak_days, total_xp, groups → список значков с признаком earned."""
    return [
        {"id": badge_id, "name": name, "hint": hint, "earned": bool(check(stats))}
        for badge_id, name, hint, check in BADGES
    ]
